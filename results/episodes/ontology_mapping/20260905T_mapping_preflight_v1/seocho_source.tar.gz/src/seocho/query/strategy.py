"""
Prompt strategies — ontology-driven prompt generation for extraction,
querying, and entity linking.

Each strategy takes an :class:`~seocho.ontology.Ontology` and produces
ready-to-use system/user prompts for the respective LLM call.

The strategies are designed to be composable::

    from seocho import Ontology
    from seocho.prompt_strategy import ExtractionStrategy, QueryStrategy

    onto = Ontology.from_yaml("schema.yaml")

    ext = ExtractionStrategy(onto)
    system, user = ext.render("텍스트를 분석해주세요")

    qs = QueryStrategy(onto, schema_info={"node_count": 1200})
    system, user = qs.render("이재용은 어디에서 일하나요?")
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from seocho.ontology import Ontology


def _sanitize_prompt_value(value: Any) -> str:
    """Sanitize a user-provided value before inserting into a prompt.

    Strips control characters and truncates to prevent prompt injection.
    """
    text = str(value)
    text = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", text)
    if len(text) > 2000:
        text = text[:2000] + "... (truncated)"
    return text


# ---------------------------------------------------------------------------
# PromptTemplate — user-customizable prompt structure
# ---------------------------------------------------------------------------


@dataclass
class PromptTemplate:
    """User-defined prompt template with Jinja2-style ``{{variable}}`` placeholders.

    Available variables (auto-injected from ontology):

    - ``{{ontology_name}}`` — ontology name
    - ``{{entity_types}}`` — formatted list of node types + properties
    - ``{{relationship_types}}`` — formatted relationship listing
    - ``{{constraints_summary}}`` — property constraints
    - ``{{graph_schema}}`` — full schema block (query mode)
    - ``{{query_hints}}`` — constraint-derived hints (query mode)
    - ``{{text}}`` — input text (user prompt)

    Example::

        custom = PromptTemplate(
            system="You are a FIBO expert. Extract financial entities.\\n{{entity_types}}",
            user="Document:\\n{{text}}",
        )
        s = Seocho(ontology=onto, graph_store=store, llm=llm,
                   extraction_prompt=custom)
    """

    system: str
    user: str = "{{text}}"

    def render(self, context: Dict[str, str], text: str) -> tuple[str, str]:
        """Render template with context variables."""
        system = self.system
        user = self.user
        for key, value in context.items():
            system = system.replace("{{" + key + "}}", str(value))
            user = user.replace("{{" + key + "}}", str(value))
        system = system.replace("{{text}}", text)
        user = user.replace("{{text}}", text)
        return system, user


# ---------------------------------------------------------------------------
# Preset prompts for common domains
# ---------------------------------------------------------------------------

PRESET_PROMPTS: Dict[str, PromptTemplate] = {
    "general": PromptTemplate(
        system=(
            "You are an expert entity extraction system.\n"
            'You are working with the "{{ontology_name}}" ontology.\n\n'
            "Extract entities of the following types:\n{{entity_types}}\n\n"
            "Extract relationships of the following types:\n{{relationship_types}}\n\n"
            "{{constraints_summary}}\n\n"
            'Return JSON with "nodes" and "relationships" keys.\n'
            'Nodes: {"id": "unique_id", "label": "EntityType", "properties": {"name": "..."}}\n'
            'Relationships: {"source": "id", "target": "id", "type": "TYPE", "properties": {}}'
        ),
        user="Text to extract:\n{{text}}",
    ),
    "finance": PromptTemplate(
        system=(
            "You are a financial domain expert specializing in the Financial Industry Business Ontology (FIBO).\n"
            'Working with the "{{ontology_name}}" ontology.\n\n'
            "Extract financial entities of these types:\n{{entity_types}}\n\n"
            "Extract financial relationships:\n{{relationship_types}}\n\n"
            "Pay special attention to:\n"
            "- Company names, tickers, and legal entity identifiers\n"
            "- Financial metrics (revenue, assets, liabilities) with exact values\n"
            "- Regulatory references (GAAP, IFRS, SEC filings)\n"
            "- Temporal context (fiscal year, quarter, date)\n\n"
            "Important financial extraction rules:\n"
            "- Preserve business-segment or line-item metrics as separate FinancialMetric nodes.\n"
            "- Do not collapse segment metrics into a total revenue metric.\n"
            "- When the same metric appears for multiple periods, create one metric node per period.\n"
            '- Include the period in the metric node name when needed, for example "Data and access solutions revenue 2023".\n'
            "- Keep exact numeric values and their matching year/period together.\n\n"
            "{{constraints_summary}}\n\n"
            'Return JSON with "nodes" and "relationships" keys.'
        ),
        user="Financial document:\n{{text}}",
    ),
    "legal": PromptTemplate(
        system=(
            "You are a legal domain expert.\n"
            'Working with the "{{ontology_name}}" ontology.\n\n'
            "Extract legal entities:\n{{entity_types}}\n\n"
            "Extract legal relationships:\n{{relationship_types}}\n\n"
            "Pay special attention to:\n"
            "- Parties (plaintiff, defendant, counsel)\n"
            "- Statutes, regulations, and case citations\n"
            "- Contractual obligations and clauses\n"
            "- Dates, deadlines, and jurisdictions\n\n"
            "{{constraints_summary}}\n\n"
            'Return JSON with "nodes" and "relationships" keys.'
        ),
        user="Legal document:\n{{text}}",
    ),
    "medical": PromptTemplate(
        system=(
            "You are a medical domain expert.\n"
            'Working with the "{{ontology_name}}" ontology.\n\n'
            "Extract medical entities:\n{{entity_types}}\n\n"
            "Extract medical relationships:\n{{relationship_types}}\n\n"
            "Pay special attention to:\n"
            "- Drug names (generic and brand)\n"
            "- Symptoms, conditions, and diagnoses\n"
            "- Dosages, interactions, and contraindications\n"
            "- Clinical trial identifiers and outcomes\n\n"
            "{{constraints_summary}}\n\n"
            'Return JSON with "nodes" and "relationships" keys.'
        ),
        user="Medical document:\n{{text}}",
    ),
    "research": PromptTemplate(
        system=(
            "You are an academic research extraction expert.\n"
            'Working with the "{{ontology_name}}" ontology.\n\n'
            "Extract research entities:\n{{entity_types}}\n\n"
            "Extract relationships:\n{{relationship_types}}\n\n"
            "Pay special attention to:\n"
            "- Authors, affiliations, and institutions\n"
            "- Methods, algorithms, and techniques\n"
            "- Datasets, benchmarks, and metrics with values\n"
            "- Citations and cross-references\n\n"
            "{{constraints_summary}}\n\n"
            'Return JSON with "nodes" and "relationships" keys.'
        ),
        user="Research paper:\n{{text}}",
    ),

    # --- RDF-aware presets ---

    "rdf_general": PromptTemplate(
        system=(
            "You are an RDF knowledge graph extraction expert.\n"
            'Working with the "{{ontology_name}}" ontology.\n\n'
            "Extract entities as RDF resources. Every entity MUST have a URI.\n"
            "Use the namespace prefix for URIs when possible.\n\n"
            "Known entity types:\n{{entity_types}}\n\n"
            "Known relationship types:\n{{relationship_types}}\n\n"
            "Return JSON with TWO keys:\n"
            '  "nodes": [{"id": "uri:...", "label": "Type", "properties": {"uri": "...", "name": "..."}}]\n'
            '  "triples": [{"subject": "uri:...", "predicate": "rdf:type", "object": "schema:Type"},\n'
            '              {"subject": "uri:...", "predicate": "schema:name", "object": "literal value"}]\n\n'
            "Rules for RDF extraction:\n"
            "- Every entity gets a URI (use urn:entity:<normalized_name> if no standard URI)\n"
            "- Properties become separate triples (subject, predicate=property_name, object=value)\n"
            "- Relationships become triples (subject=source_uri, predicate=rel_type, object=target_uri)\n"
            "- Include rdf:type triples for all entities\n"
            "- Use sameAs property to link to standard vocabulary URIs where known\n"
        ),
        user="Text to extract as RDF triples:\n{{text}}",
    ),

    "rdf_fibo": PromptTemplate(
        system=(
            "You are a FIBO (Financial Industry Business Ontology) RDF extraction expert.\n"
            'Working with the "{{ontology_name}}" ontology.\n\n'
            "Extract financial entities as RDF resources following FIBO conventions.\n\n"
            "Known entity types:\n{{entity_types}}\n\n"
            "Known relationship types:\n{{relationship_types}}\n\n"
            "FIBO conventions:\n"
            "- Use FIBO namespace prefixes (fibo-fnd:, fibo-be:, fibo-sec:)\n"
            "- Organizations get LEI or FIGI identifiers as URIs when available\n"
            "- Financial instruments reference SEC/ISIN identifiers\n"
            "- Regulatory references link to specific regulation URIs\n\n"
            "Important financial extraction rules:\n"
            "- Preserve business-segment or line-item metrics as separate FinancialMetric resources.\n"
            "- Do not collapse segment metrics into a total revenue resource.\n"
            "- When the same metric appears for multiple periods, create one resource per period.\n"
            '- Include the period in the resource name when needed, for example "Data and access solutions revenue 2023".\n'
            "- Keep exact numeric values aligned with their period.\n\n"
            "Return JSON with:\n"
            '  "nodes": [{"id": "uri", "label": "Type", "properties": {"uri": "...", "name": "..."}}]\n'
            '  "triples": [{"subject": "uri", "predicate": "predicate", "object": "uri_or_literal"}]\n'
        ),
        user="Financial document (extract as FIBO RDF):\n{{text}}",
    ),

    # --- Filing-domain category-specific presets ---

    "filing_overview": PromptTemplate(
        system=(
            'You are extracting company overview information from SEC 10-K filings.\n'
            'Working with the "{{ontology_name}}" ontology.\n\n'
            "Entity types:\n{{entity_types}}\nRelationships:\n{{relationship_types}}\n\n"
            "Focus on: company structure, business segments, headquarters, subsidiaries, employee count.\n"
            '{{constraints_summary}}\nReturn JSON with "nodes" and "relationships" keys.'
        ),
        user="SEC 10-K Company Overview section:\n{{text}}",
    ),
    "filing_financials": PromptTemplate(
        system=(
            'You are extracting financial metrics from SEC 10-K filings.\n'
            'Working with the "{{ontology_name}}" ontology.\n\n'
            "Entity types:\n{{entity_types}}\nRelationships:\n{{relationship_types}}\n\n"
            "Focus on: revenue, net income, operating income, growth rates, YoY comparisons, margins.\n"
            "Extract exact numerical values with year/period context.\n"
            "Preserve segment line items such as business-unit revenue as separate metrics.\n"
            "Do not replace a segment metric with Total Revenues.\n"
            'When one metric appears in multiple years, create one metric node per year and include the year in the metric name when needed.\n'
            '{{constraints_summary}}\nReturn JSON with "nodes" and "relationships" keys.'
        ),
        user="SEC 10-K Financial data:\n{{text}}",
    ),
    "filing_financials_rdf": PromptTemplate(
        system=(
            'You are extracting SEC 10-K financial metrics as RDF resources.\n'
            'Working with the "{{ontology_name}}" ontology.\n\n'
            "Entity types:\n{{entity_types}}\nRelationships:\n{{relationship_types}}\n\n"
            "Focus on: revenue, segment revenue, net income, operating income, margins, and YoY comparisons.\n"
            "Extract exact numerical values with year/period context.\n"
            "Preserve segment line items such as business-unit revenue as separate FinancialMetric resources.\n"
            "Do not replace a segment metric with Total Revenues.\n"
            'When one metric appears in multiple years, create one metric resource per year and include the year in the metric name when needed.\n'
            '{{constraints_summary}}\nReturn JSON with "nodes" and "triples" keys.'
        ),
        user="SEC 10-K Financial data (RDF):\n{{text}}",
    ),
    "filing_footnotes": PromptTemplate(
        system=(
            'You are extracting accounting footnote details from SEC 10-K filings.\n'
            'Working with the "{{ontology_name}}" ontology.\n\n'
            "Entity types:\n{{entity_types}}\nRelationships:\n{{relationship_types}}\n\n"
            "Focus on: accounting policies, detailed disclosures, estimates, contingencies.\n"
            '{{constraints_summary}}\nReturn JSON with "nodes" and "relationships" keys.'
        ),
        user="SEC 10-K Footnotes:\n{{text}}",
    ),
    "filing_governance": PromptTemplate(
        system=(
            'You are extracting corporate governance information from SEC 10-K filings.\n'
            'Working with the "{{ontology_name}}" ontology.\n\n'
            "Entity types:\n{{entity_types}}\nRelationships:\n{{relationship_types}}\n\n"
            "Focus on: executives (name+title), board members, compensation, ownership structure.\n"
            '{{constraints_summary}}\nReturn JSON with "nodes" and "relationships" keys.'
        ),
        user="SEC 10-K Governance section:\n{{text}}",
    ),
    "filing_accounting": PromptTemplate(
        system=(
            'You are extracting accounting standards and policies from SEC 10-K filings.\n'
            'Working with the "{{ontology_name}}" ontology.\n\n'
            "Entity types:\n{{entity_types}}\nRelationships:\n{{relationship_types}}\n\n"
            "Focus on: ASC/IFRS standards, depreciation methods, capitalization policies, goodwill, impairment.\n"
            '{{constraints_summary}}\nReturn JSON with "nodes" and "relationships" keys.'
        ),
        user="SEC 10-K Accounting policies:\n{{text}}",
    ),
    "filing_legal": PromptTemplate(
        system=(
            'You are extracting legal proceedings from SEC 10-K filings.\n'
            'Working with the "{{ontology_name}}" ontology.\n\n'
            "Entity types:\n{{entity_types}}\nRelationships:\n{{relationship_types}}\n\n"
            "Focus on: lawsuits, regulatory investigations, settlements, antitrust, patent claims.\n"
            '{{constraints_summary}}\nReturn JSON with "nodes" and "relationships" keys.'
        ),
        user="SEC 10-K Legal proceedings:\n{{text}}",
    ),
    "filing_risk": PromptTemplate(
        system=(
            'You are extracting risk factors from SEC 10-K filings.\n'
            'Working with the "{{ontology_name}}" ontology.\n\n'
            "Entity types:\n{{entity_types}}\nRelationships:\n{{relationship_types}}\n\n"
            "Focus on: market risk, operational risk, regulatory risk, cybersecurity, competition.\n"
            '{{constraints_summary}}\nReturn JSON with "nodes" and "relationships" keys.'
        ),
        user="SEC 10-K Risk factors:\n{{text}}",
    ),
    "filing_shareholder": PromptTemplate(
        system=(
            'You are extracting shareholder return data from SEC 10-K filings.\n'
            'Working with the "{{ontology_name}}" ontology.\n\n'
            "Entity types:\n{{entity_types}}\nRelationships:\n{{relationship_types}}\n\n"
            "Focus on: dividends, share repurchases/buybacks, total shareholder return, stock performance.\n"
            '{{constraints_summary}}\nReturn JSON with "nodes" and "relationships" keys.'
        ),
        user="SEC 10-K Shareholder return data:\n{{text}}",
    ),
}

# Category → prompt auto-selection map
CATEGORY_PROMPT_MAP: Dict[str, str] = {
    "Company Overview": "filing_overview",
    "Financials": "filing_financials",
    "Footnotes": "filing_footnotes",
    "Governance": "filing_governance",
    "Accounting": "filing_accounting",
    "Legal": "filing_legal",
    "Risk": "filing_risk",
    "Shareholder Return": "filing_shareholder",
}


# ---------------------------------------------------------------------------
# Base
# ---------------------------------------------------------------------------


class PromptStrategy:
    """Base class for ontology-driven prompt strategies."""

    def __init__(self, ontology: Ontology) -> None:
        self.ontology = ontology

    def render(self, text: str, **kwargs: Any) -> tuple[str, str]:
        """Return (system_prompt, user_prompt)."""
        raise NotImplementedError


# ---------------------------------------------------------------------------
# Extraction
# ---------------------------------------------------------------------------


class ExtractionStrategy(PromptStrategy):
    """Generates prompts for entity/relationship extraction (graph indexing).

    Accepts an optional ``prompt_template`` for full customization::

        from seocho.query import ExtractionStrategy, PromptTemplate, PRESET_PROMPTS

        # Custom template
        ext = ExtractionStrategy(ontology, prompt_template=PromptTemplate(
            system="You are a FIBO expert.\\n{{entity_types}}",
        ))

        # Domain preset
        ext = ExtractionStrategy(ontology, prompt_template=PRESET_PROMPTS["finance"])

    If no template is provided, the default general-purpose prompt is used.
    """

    def __init__(
        self,
        ontology: Ontology,
        *,
        category: str = "general",
        shacl_constraints: Optional[str] = None,
        vocabulary_terms: Optional[str] = None,
        developer_instructions: Optional[str] = None,
        prompt_template: Optional[PromptTemplate] = None,
        extraction_prompt: Optional[PromptTemplate] = None,
    ) -> None:
        super().__init__(ontology)
        self.category = category
        self.shacl_constraints = shacl_constraints
        self.vocabulary_terms = vocabulary_terms
        self.developer_instructions = developer_instructions
        # Accept both names — extraction_prompt is the public API name
        self.prompt_template = extraction_prompt or prompt_template

    def render(self, text: str, **kwargs: Any) -> tuple[str, str]:
        ctx = self.ontology.to_extraction_context()

        # Prefer a per-call category so concurrent add() calls on a shared
        # strategy do not race on instance state; fall back to the constructor
        # default (issue #134).
        category = kwargs.get("category") or self.category

        # If user provided a custom template, use it
        if self.prompt_template is not None:
            return self.prompt_template.render(ctx, text)

        # Auto-select category-specific prompt if available
        if category in CATEGORY_PROMPT_MAP:
            auto_template = PRESET_PROMPTS.get(CATEGORY_PROMPT_MAP[category])
            if auto_template is not None:
                return auto_template.render(ctx, text)

        # Build system prompt — the ontology-derived prefix is stable across
        # chunks, maximizing provider-side prompt cache hits.
        metadata = kwargs.get("metadata")
        cache_key = (
            category,
            self.shacl_constraints,
            self.vocabulary_terms,
            self.developer_instructions,
            repr(metadata) if metadata else None,
        )
        if not hasattr(self, "_system_prompt_cache"):
            self._system_prompt_cache: Dict[Any, str] = {}
        cached = self._system_prompt_cache.get(cache_key)
        if cached is not None:
            return cached, f"Text to extract:\n{text}"

        parts: List[str] = []

        parts.append("You are an expert entity extraction system.")
        parts.append("")
        parts.append("Task:")
        parts.append("- Extract ontology-grounded entities and relationships from the user text.")
        parts.append("")
        parts.append("Context:")
        parts.append(f'- Ontology: "{ctx["ontology_name"]}".')
        parts.append("")
        parts.append("- Allowed entity types:")
        parts.append(ctx["entity_types"])

        # T2.3 — hierarchical label selection rule. Always emitted so the LLM
        # cannot silently fall back to a generic ``Entity`` label when a
        # domain-specific subclass exists. Strengthened when the ontology
        # exposes many classes (≥10) because Kimi's empirical fallback rate
        # spikes there.
        domain_node_count = sum(1 for _ in (getattr(self.ontology, "nodes", {}) or {}))
        parts.append("")
        parts.append("Label selection rules (MANDATORY):")
        parts.append(
            "  1. Use the MOST-SPECIFIC class that matches each entity. "
            "If both an abstract base (e.g. FinancialMetric) and a concrete "
            "subclass (Revenue, OperatingIncome, NetIncome, EPS, GrossProfit, "
            "OperatingMargin) are listed, pick the subclass."
        )
        parts.append(
            "  2. Never default to a generic 'Entity' label when ANY domain "
            "class above matches. 'Entity' is a last-resort fallback only."
        )
        parts.append(
            "  3. Use canonical class names exactly as listed above (e.g. "
            "'LegalEntity' not 'Company'; 'Revenue' not 'Sales')."
        )
        if domain_node_count >= 10:
            parts.append(
                "  4. NOTE: This ontology defines many classes — read the "
                "entity_types list above carefully before emitting any label."
            )

        parts.append("")
        parts.append("- Allowed relationship types:")
        parts.append(ctx["relationship_types"])

        parts.append("")
        parts.append("Constraints:")
        parts.append("- Use only labels and relationship types supported by the ontology when the text grounds them.")
        parts.append("- Preserve exact names, dates, quantities, and other literal values from the text.")
        parts.append("- Do not invent facts that are not explicitly supported by the text.")

        if ctx.get("constraints_summary"):
            parts.append("")
            parts.append("- Property constraints to respect:")
            parts.append(ctx["constraints_summary"])

        if self.shacl_constraints:
            parts.append("")
            parts.append("- SHACL-like constraint hints:")
            parts.append(self.shacl_constraints)

        if self.vocabulary_terms:
            parts.append("")
            parts.append("- Vocabulary / SKOS term hints for canonicalization:")
            parts.append(self.vocabulary_terms)

        if self.developer_instructions:
            parts.append("")
            parts.append("- Developer instructions:")
            parts.append(self.developer_instructions)

        if metadata:
            parts.append("")
            parts.append(f"- Source metadata: {_sanitize_prompt_value(metadata)}")

        parts.append("")
        parts.append("Output format:")
        parts.append('- Return exactly one valid json object with keys "nodes" and "relationships".')
        parts.append('  Example node: {"id": "unique_id", "label": "EntityType", "properties": {"name": "Entity Name"}}')
        parts.append('  Example relationship: {"source": "source_id", "target": "target_id", "type": "RELATIONSHIP_TYPE", "properties": {}}')
        parts.append("")
        parts.append("Verification:")
        parts.append("- Before finalizing, check that the json is valid.")
        parts.append("- Check that every node label and relationship type is allowed by the ontology.")
        parts.append("- Check that relationship source/target ids reference emitted nodes.")

        system = "\n".join(parts)
        self._system_prompt_cache[cache_key] = system
        user = f'Text to extract:\n"""\n{text}\n"""'
        return system, user


# ---------------------------------------------------------------------------
# Query — the critical new capability
# ---------------------------------------------------------------------------


class QueryStrategy(PromptStrategy):
    """Generates prompts for ontology-aware graph querying.

    This is the **key missing piece** in the current architecture.  The LLM
    generating Cypher or answering natural-language questions now receives:

    - Full graph schema (node types, relationship types, property types)
    - Cardinality information (ONE_TO_MANY, etc.)
    - Constraint hints (UNIQUE → use exact match)
    - Optional live schema stats (node counts, etc.)

    This dramatically reduces hallucinated labels, wrong relationship
    directions, and invalid property access in generated Cypher.
    """

    def __init__(
        self,
        ontology: Ontology,
        *,
        schema_info: Optional[Dict[str, Any]] = None,
        vocabulary_terms: Optional[str] = None,
    ) -> None:
        super().__init__(ontology)
        self.schema_info = schema_info or {}
        self.vocabulary_terms = vocabulary_terms

    def render(self, question: str, **kwargs: Any) -> tuple[str, str]:
        # Cache the system prompt — it only changes when schema_info or
        # vocabulary changes, not per question.  Maximizes provider-side
        # prompt cache hits (OpenAI auto-caches identical prefixes ≥1024 tokens).
        cache_key = (repr(self.schema_info), self.vocabulary_terms)
        if not hasattr(self, "_system_prompt_cache"):
            self._system_prompt_cache: Dict[Any, str] = {}
        cached = self._system_prompt_cache.get(cache_key)
        if cached is not None:
            return cached, f"Question: {question}"

        ctx = self.ontology.to_query_context()
        parts: List[str] = []

        parts.append("You are a knowledge graph query agent.")
        parts.append("")
        parts.append("Task:")
        parts.append("- Generate a read-only Cypher plan that answers the user question.")
        parts.append("")
        parts.append("Context:")
        parts.append(
            "- Only use node labels, relationship types, and properties defined in the schema below."
        )
        parts.append("")
        parts.append("--- Graph Schema ---")
        parts.append(ctx["graph_schema"])

        if ctx.get("ontology_profile"):
            parts.append("")
            parts.append("--- Ontology Query Profile ---")
            parts.append(ctx["ontology_profile"])

        if ctx.get("query_hints"):
            parts.append("")
            parts.append("--- Query Hints ---")
            parts.append(ctx["query_hints"])

        if self.schema_info:
            parts.append("")
            parts.append("--- Live Schema Stats ---")
            for k, v in self.schema_info.items():
                parts.append(f"- {_sanitize_prompt_value(k)}: {_sanitize_prompt_value(v)}")

        if self.vocabulary_terms:
            parts.append("")
            parts.append("--- Vocabulary Aliases ---")
            parts.append(self.vocabulary_terms)

        parts.append("")
        parts.append("Constraints:")
        parts.append("- Generate read-only Cypher only.")
        parts.append("- Prefer ontology-grounded matches over broad guesses.")
        parts.append("- Keep literal values in params and use $param syntax inside Cypher.")
        parts.append("- If the schema does not support a requested field or relation, leave it out instead of inventing it.")
        parts.append("")
        parts.append("Output format:")
        parts.append('- Return exactly one valid json object with keys "cypher", "params", and "explanation".')
        parts.append("")
        parts.append("Verification:")
        parts.append("- Before finalizing, check that every referenced label, relationship, and property appears in the schema.")
        parts.append("- Check that params is a json object and every $param used in Cypher exists in params.")

        system = "\n".join(parts)
        self._system_prompt_cache[cache_key] = system
        user = f'Question:\n"""\n{question}\n"""'
        return system, user

    def render_answer(self, question: str, cypher_result: Any, **kwargs: Any) -> tuple[str, str]:
        """Generate a prompt for synthesizing a natural-language answer
        from Cypher query results.

        Parameters
        ----------
        question:
            The original user question.
        cypher_result:
            The result set from executing the generated Cypher query.
        """
        ctx = self.ontology.to_query_context()
        parts: List[str] = []

        parts.append("You are a knowledge graph answer synthesis agent.")
        parts.append(f'Working with the "{ctx["ontology_name"]}" graph.')
        if ctx.get("ontology_profile"):
            parts.append("Ontology profile: " + ctx["ontology_profile"])
        parts.append("")
        parts.append("Available node types: " + ctx["node_types"])
        parts.append("Available relationships: " + ctx["relationship_types"])
        parts.append("")
        parts.append(
            "Given the user's question and the query results below, "
            "produce a clear, factual answer. Only state facts supported "
            "by the query results. If the results are empty, say so."
        )
        parts.append("")
        parts.append("Verification: Check that every answer claim is grounded in the provided query results.")

        system = "\n".join(parts)
        user = (
            f'Question:\n"""\n{question}\n"""\n\n'
            f"Query results:\n{cypher_result}"
        )
        return system, user


# ---------------------------------------------------------------------------
# RDF Query — n10s Cypher generation
# ---------------------------------------------------------------------------


class RDFQueryStrategy(PromptStrategy):
    """Generates n10s-aware Cypher for RDF mode queries.

    When the ontology uses ``graph_model="rdf"``, this strategy generates
    Cypher that works with n10s (neosemantics) prefixed relationships
    and URI-based node lookups.

    n10s stores RDF triples as:
    - Nodes with ``uri`` property and label = RDF class
    - Relationships with prefixed names (e.g. ``schema__worksFor``)
    """

    def __init__(
        self,
        ontology: Ontology,
        *,
        schema_info: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(ontology)
        self.schema_info = schema_info or {}

    def render(self, question: str, **kwargs: Any) -> tuple[str, str]:
        ctx = self.ontology.to_query_context()
        ns = self.ontology.namespace or "https://schema.org/"

        parts: List[str] = []
        parts.append("You are an RDF knowledge graph query agent using Neo4j + n10s (neosemantics).")
        parts.append("")
        parts.append("IMPORTANT n10s conventions:")
        parts.append(f"- Namespace: {ns}")
        parts.append("- Nodes have a `uri` property (globally unique identifier)")
        parts.append("- RDF classes become Neo4j labels (e.g. schema:Person → :Person)")
        parts.append("- RDF properties become Neo4j relationship types with prefix")
        parts.append("  (e.g. schema:worksFor → :schema__worksFor)")
        parts.append("- Literal properties are stored directly on nodes")
        parts.append("- Use `n10s.rdf.getNodeByUri($uri)` to look up by URI")
        parts.append("")
        parts.append("--- Graph Schema ---")
        parts.append(ctx["graph_schema"])

        if ctx.get("ontology_profile"):
            parts.append("")
            parts.append("--- Ontology Query Profile ---")
            parts.append(ctx["ontology_profile"])

        if ctx.get("query_hints"):
            parts.append("")
            parts.append("--- Query Hints ---")
            parts.append(ctx["query_hints"])

        if self.schema_info:
            parts.append("")
            parts.append("--- Live Schema Stats ---")
            for k, v in self.schema_info.items():
                parts.append(f"- {_sanitize_prompt_value(k)}: {_sanitize_prompt_value(v)}")

        parts.append("")
        parts.append(
            "Generate n10s-compatible Cypher. Use uri-based lookups where possible.\n"
            "For relationship matching, use the prefixed form (namespace__property).\n\n"
            "Return JSON:\n"
            '  "cypher": the Cypher query string\n'
            '  "params": dict of parameters\n'
            '  "explanation": brief explanation'
        )

        system = "\n".join(parts)
        user = f"Question: {question}"
        return system, user

    def render_answer(self, question: str, cypher_result: Any, **kwargs: Any) -> tuple[str, str]:
        ctx = self.ontology.to_query_context()
        parts: List[str] = []
        parts.append("You are an RDF knowledge graph answer agent.")
        parts.append(f'Working with the "{ctx["ontology_name"]}" RDF graph.')
        if ctx.get("ontology_profile"):
            parts.append("Ontology profile: " + ctx["ontology_profile"])
        parts.append("Node types: " + ctx["node_types"])
        parts.append("Produce a clear factual answer from the query results.")

        system = "\n".join(parts)
        user = f"Question: {question}\n\nQuery results:\n{cypher_result}"
        return system, user


# ---------------------------------------------------------------------------
# Linking
# ---------------------------------------------------------------------------


class LinkingStrategy(PromptStrategy):
    """Generates prompts for entity deduplication and canonical ID assignment."""

    def __init__(
        self,
        ontology: Ontology,
        *,
        category: str = "general",
        vocabulary_terms: Optional[str] = None,
        developer_instructions: Optional[str] = None,
    ) -> None:
        super().__init__(ontology)
        self.category = category
        self.vocabulary_terms = vocabulary_terms
        self.developer_instructions = developer_instructions

    def render(self, entities_json: str, **kwargs: Any) -> tuple[str, str]:
        ctx = self.ontology.to_linking_context()
        parts: List[str] = []

        parts.append(
            "You are an expert entity linking system. Your goal is to "
            "identify duplicate entities and link them to a canonical ID."
        )
        parts.append("")
        parts.append(
            f"You will be provided with a list of extracted entities "
            f"from a document in the category: {self.category}."
        )
        parts.append("")
        parts.append("Task:")
        parts.append("1. Analyze entities for semantic similarity and potential duplicates.")
        parts.append('2. Assign a "linked_id" (standardized URN for well-known entities, '
                      "normalized ID for local duplicates).")
        parts.append('3. Return JSON with the same structure but with "linked_id" added.')

        if ctx.get("ontology_name"):
            parts.append("")
            parts.append(f'Ontology: {ctx["ontology_name"]}')

        if ctx.get("entity_types"):
            parts.append("")
            parts.append("Known entity types:")
            parts.append(ctx["entity_types"])

        if ctx.get("relationship_types"):
            parts.append("")
            parts.append("Relationship hints:")
            parts.append(ctx["relationship_types"])

        if self.vocabulary_terms:
            parts.append("")
            parts.append("Vocabulary hints:")
            parts.append(self.vocabulary_terms)

        if self.developer_instructions:
            parts.append("")
            parts.append("Developer instructions:")
            parts.append(self.developer_instructions)

        system = "\n".join(parts)
        user = f"Input Entities:\n{entities_json}"
        return system, user
