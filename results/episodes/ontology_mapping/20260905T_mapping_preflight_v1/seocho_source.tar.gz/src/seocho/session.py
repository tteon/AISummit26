"""
Session — agent-level SDK interface with context and tracing.

A Session maintains conversation state across ``add()`` and ``ask()`` calls.
Instead of independent chat completions, each operation runs through an
agent with tool use, with explicit fallback to the canonical local engine
when the agent path is unavailable. All operations within a session roll up
into a single parent trace.

Usage::

    from seocho import Seocho, Ontology
    from seocho.store import Neo4jGraphStore, OpenAIBackend

    s = Seocho(ontology=onto, graph_store=store, llm=llm)

    # Agent-level session (recommended)
    session = s.session("finance_analysis")
    session.add("NVIDIA revenue was $26.9B in 2024...")
    session.add("Apple CEO Tim Cook announced...")
    answer = session.ask("Compare NVIDIA and Apple revenue")
    session.close()

    # Session as context manager
    with s.session("research") as session:
        session.add("...")
        answer = session.ask("...")
"""

from __future__ import annotations

import asyncio
import json
import logging
import queue
import threading
import time
import uuid
from typing import Any, Coroutine, Dict, List, Optional, Sequence, TypeVar

from .agent.context import SessionContext
from .agent.contracts import normalize_execution_mode
from .agent.factory import (
    create_indexing_agent,
    create_query_agent,
    create_supervisor_agent,
)

logger = logging.getLogger(__name__)


_T = TypeVar("_T")


def _run_sync(
    coro: "Coroutine[Any, Any, _T]",
    *,
    timeout: Optional[float] = None,
) -> _T:
    """Run *coro* to completion from a synchronous context.

    ``asyncio.run()`` raises ``RuntimeError`` when invoked from a thread
    that already has a running loop (Jupyter cells, FastAPI request
    handlers, ``pytest-asyncio`` fixtures). When that happens we hand the
    coroutine to a worker thread that owns its own loop, so the caller's
    loop is undisturbed and no monkey-patching (e.g. ``nest_asyncio``) is
    required. In the simple "plain script" case there is no running loop
    and we use ``asyncio.run`` directly — same behaviour as before.

    seocho-hnf9: ``timeout`` (seconds) optionally bounds how long the
    caller waits for the worker thread. On timeout, raise
    ``asyncio.TimeoutError``; the daemon worker is left running but will
    exit with the process. The caller's KeyboardInterrupt during
    ``worker.join()`` propagates immediately rather than blocking
    indefinitely on a stuck coroutine.
    """
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)

    box: Dict[str, Any] = {}

    def _runner() -> None:
        # The worker owns its own loop; any task cleanup happens inside
        # asyncio.run which cancels pending tasks on shutdown.
        try:
            box["value"] = asyncio.run(coro)
        except BaseException as exc:  # noqa: BLE001
            box["error"] = exc

    worker = threading.Thread(target=_runner, name="seocho-run-sync", daemon=True)
    worker.start()
    try:
        worker.join(timeout=timeout)
    except KeyboardInterrupt:
        # Caller pressed Ctrl-C / kernel interrupt. Don't wait further;
        # the daemon worker will be cleaned up on process exit.
        raise
    if worker.is_alive():
        # Hit the timeout — coroutine is still executing in the worker.
        raise asyncio.TimeoutError(
            f"_run_sync coroutine did not complete within {timeout}s"
        )
    if "error" in box:
        raise box["error"]
    return box["value"]


def _stream_async_in_thread(make_agen):
    """Drive an async generator from synchronous code, yielding items as they arrive.

    Like :func:`_run_sync`, the work runs in a worker thread that owns its own event
    loop, so this is safe to call from a thread that already has a running loop
    (Jupyter, FastAPI, ``pytest-asyncio``) instead of crashing on a nested
    ``loop.run_until_complete``. Items stream through a queue in real time; iterator
    cleanup (``aclose`` + task cancellation on loop shutdown) happens in the worker.

    ``make_agen`` is a zero-arg factory that returns the async generator; it is
    invoked inside the worker's loop so loop-bound setup runs on the right loop.
    """
    items: "queue.Queue" = queue.Queue()

    def _runner() -> None:
        async def _drive() -> None:
            agen = make_agen()
            try:
                async for item in agen:
                    items.put(("item", item))
            finally:
                aclose = getattr(agen, "aclose", None)
                if aclose is not None:
                    try:
                        await aclose()
                    except Exception:  # noqa: BLE001
                        pass

        try:
            asyncio.run(_drive())
        except BaseException as exc:  # noqa: BLE001
            items.put(("error", exc))
        finally:
            items.put(("done", None))

    worker = threading.Thread(target=_runner, name="seocho-stream", daemon=True)
    worker.start()
    while True:
        kind, payload = items.get()
        if kind == "item":
            yield payload
        elif kind == "error":
            raise payload
        else:
            return


class Session:
    """Agent-level session with context persistence and tracing.

    Each call to ``add()`` runs an IndexingAgent that decides how to
    extract, validate, and write. Each call to ``ask()`` runs a
    QueryAgent that builds and executes queries. When the agent path
    fails, the session falls back to the canonical local engine used by
    ``Seocho`` and records the degraded path in trace/context metadata.

    Parameters
    ----------
    name:
        Session name for identification and tracing.
    ontology:
        The Ontology driving extraction and querying.
    graph_store:
        GraphStore for Neo4j/DozerDB.
    llm:
        LLMBackend for agent reasoning.
    vector_store:
        Optional VectorStore for similarity search.
    database:
        Default target database.
    extraction_prompt:
        Optional custom PromptTemplate.
    agent_config:
        Optional AgentConfig for quality thresholds.
    """

    def __init__(
        self,
        *,
        name: str = "",
        ontology: Any,
        graph_store: Any,
        llm: Any,
        vector_store: Any = None,
        database: str = "neo4j",
        extraction_prompt: Any = None,
        agent_config: Any = None,
        workspace_id: str = "default",
        ontology_profile: str = "default",
        user_id: Optional[str] = None,
    ) -> None:
        self.session_id = str(uuid.uuid4())[:12]
        self.name = name or f"session-{self.session_id}"
        self.ontology = ontology
        self.graph_store = graph_store
        self.llm = llm
        self.vector_store = vector_store
        self.database = database
        self.extraction_prompt = extraction_prompt
        self.agent_config = agent_config
        self.workspace_id = workspace_id
        self.ontology_profile = str(ontology_profile or "default")
        self.user_id = user_id

        self.context = SessionContext()
        # seocho-jdg: opt-in persistent cross-process answer cache. None (default)
        # = OFF, behaves exactly as before. Set SEOCHO_RESPONSE_CACHE_PATH to
        # enable; survives restarts/parallel workers, keyed by the same
        # (workspace, database, ontology_hash, question) tuple as the in-memory cache.
        from .response_cache import make_response_cache_key, response_cache_from_env

        self._response_cache = response_cache_from_env()
        self._make_response_cache_key = make_response_cache_key
        from .ontology_context import OntologyContextCache

        self._ontology_context_cache = OntologyContextCache(max_size=8)
        self._ontology_context = self._ontology_context_cache.get(
            ontology,
            workspace_id=workspace_id,
            profile=self.ontology_profile,
        )
        self._trace = None
        self._closed = False

        # Operating-layer handles, attached by ``Seocho.session()`` so this one
        # Session object is the whole OS surface: memory (add/ask/resolve),
        # scheduling+isolation (query), execution (agent), resources (budget).
        # None until attached — the OS methods raise a clear error otherwise.
        self._os = None            # the SeochoOS instance (shared admission pool)
        self._os_session = None    # this session's OSSession handle
        self.priority = "normal"
        self.sdk_session = None
        self.hooks = None
        self.budget = None

        # Start session trace
        try:
            from .tracing import begin_session, is_tracing_enabled
            if is_tracing_enabled():
                self._trace = begin_session(self.session_id, self.name)
        except Exception:
            pass

        # Lazy agent creation
        self._indexing_agent = None
        self._query_agent = None
        self._pipeline_engine = None

    def _get_indexing_agent(self) -> Any:
        """Create or return the indexing agent."""
        if self._indexing_agent is None:
            self._indexing_agent = create_indexing_agent(
                ontology=self.ontology,
                graph_store=self.graph_store,
                llm=self.llm,
                extraction_prompt=self.extraction_prompt,
                ontology_context=self._ontology_context,
                workspace_id=self.workspace_id,
            )
        return self._indexing_agent

    def _get_query_agent(self) -> Any:
        """Create or return the query agent."""
        if self._query_agent is None:
            self._query_agent = create_query_agent(
                ontology=self.ontology,
                graph_store=self.graph_store,
                llm=self.llm,
                vector_store=self.vector_store,
                ontology_context=self._ontology_context,
                workspace_id=self.workspace_id,
            )
        return self._query_agent

    def _get_pipeline_engine(self) -> Any:
        """Create or return the canonical local engine fallback."""
        if self._pipeline_engine is None:
            from .client import _LocalEngine

            self._pipeline_engine = _LocalEngine(
                ontology=self.ontology,
                graph_store=self.graph_store,
                llm=self.llm,
                vector_store=self.vector_store,
                workspace_id=self.workspace_id,
                extraction_prompt=self.extraction_prompt,
                agent_config=self.agent_config,
                ontology_profile=self.ontology_profile,
            )
        return self._pipeline_engine

    @property
    def _execution_mode(self) -> str:
        """Resolve execution mode from agent_config."""
        if self.agent_config is not None:
            return normalize_execution_mode(getattr(self.agent_config, 'execution_mode', 'pipeline'))
        return "pipeline"

    def _stamp_observability_health(self, result: Dict[str, Any]) -> None:
        """Stamp degraded_observability=True on result when traces are silently dropped.

        Closes seocho-qr74 (depends-on seocho-8k1h). When a tracing backend (any
        future backend) initialises but its underlying client fails, every
        ``log_span`` call becomes a no-op. The Session result needs to carry
        a flag so callers can fail fast when observability is required —
        otherwise the run looks healthy while traces evaporate.
        """
        try:
            from .tracing import tracing_degraded_reasons
        except Exception:
            return
        reasons = tracing_degraded_reasons()
        if reasons:
            result["degraded_observability"] = True
            result["observability_degradation_reasons"] = reasons

    def add(
        self,
        content: str,
        *,
        database: Optional[str] = None,
        category: str = "general",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Index content into the knowledge graph.

        Execution depends on ``agent_config.execution_mode``:

        - ``"pipeline"`` (default) — deterministic pipeline, no LLM reasoning about flow
        - ``"agent"`` — LLM agent with tool use (extract/validate/score/write)
        - ``"supervisor"`` — supervisor routes automatically

        Parameters
        ----------
        content:
            The text to index.
        database:
            Target database (defaults to session default).
        category:
            Document category for prompt selection.
        metadata:
            Additional metadata.

        Returns
        -------
        Dict with source_id, nodes_created, relationships_created, etc.
        """
        if self._closed:
            raise RuntimeError("Session is closed")

        db = database or self.database
        start = time.time()

        mode = self._execution_mode
        if mode == "agent":
            result = self._add_via_agent(content, db, category, metadata)
        else:
            # "pipeline" and "supervisor" both use deterministic pipeline for add()
            result = self._add_via_pipeline(content, db, category, metadata)

        # seocho-qr74: stamp degraded_observability if any tracing backend
        # is silently dropping spans (e.g. a backend that failed to initialise).
        self._stamp_observability_health(result)

        elapsed = time.time() - start

        # Update context
        source_id = result.get("source_id", "")
        nodes = result.get("nodes_created", 0)
        rels = result.get("relationships_created", 0)
        self.context.add_indexing(
            source_id,
            nodes,
            rels,
            content,
            mode=str(result.get("mode", "agent") or "agent"),
            degraded=bool(result.get("degraded", False)),
            fallback_from=str(result.get("fallback_from", "")),
            fallback_reason=str(result.get("fallback_reason", "")),
        )

        # Register extracted entities/relationships in structured cache
        if "extracted_nodes" in result:
            self.context.register_entities(result["extracted_nodes"], source_id, db)
        if "extracted_relationships" in result:
            self.context.register_relationships(result["extracted_relationships"], source_id)

        # Trace
        if self._trace:
            from .tracing import capture_text
            trace_input = {"database": db, "category": category}
            preview = capture_text(content[:200])
            if preview is not None:
                trace_input["text_preview"] = preview
            self._trace.log_span(
                "session.add",
                input_data=trace_input,
                output_data={
                    "source_id": source_id,
                    "nodes": nodes,
                    "relationships": rels,
                    "mode": str(result.get("mode", "agent") or "agent"),
                },
                metadata={
                    "elapsed_seconds": round(elapsed, 2),
                    "degraded": bool(result.get("degraded", False)),
                    "fallback_from": str(result.get("fallback_from", "")),
                    "fallback_reason": str(result.get("fallback_reason", "")),
                    "user_id": self.user_id,
                    "workspace_id": self.workspace_id,
                    "degraded_observability": bool(result.get("degraded_observability", False)),
                    "observability_degradation_reasons": list(result.get("observability_degradation_reasons", [])),
                    "ontology_context": result.get(
                        "ontology_context",
                        self._ontology_context.metadata(usage="agent_indexing"),
                    ),
                },
                tags=["indexing"],
            )

        return result

    def run(
        self,
        message: str,
        *,
        database: Optional[str] = None,
    ) -> str:
        """Send a message through the supervisor agent (hand-off mode).

        Requires ``execution_mode="supervisor"`` and ``handoff=True``
        in :class:`~seocho.agent_config.AgentConfig`.  The supervisor
        routes to IndexingAgent or QueryAgent based on the message.

        Parameters
        ----------
        message:
            Any natural-language message.
        database:
            Target database.

        Raises
        ------
        RuntimeError
            If handoff is not enabled in the agent config.

        Example::

            config = AgentConfig(execution_mode="supervisor", handoff=True)
            s = Seocho(ontology=onto, graph_store=store, llm=llm, agent_config=config)

            with s.session("analysis") as sess:
                sess.run("Samsung CEO is Jay Y. Lee")  # → IndexingAgent
                answer = sess.run("Who is Samsung's CEO?")  # → QueryAgent
        """
        if self._closed:
            raise RuntimeError("Session is closed")

        # Explicit check — handoff must be opted in
        cfg = self.agent_config
        handoff_enabled = (
            cfg is not None
            and normalize_execution_mode(getattr(cfg, 'execution_mode', 'pipeline')) == 'supervisor'
            and getattr(cfg, 'handoff', False)
        )
        if not handoff_enabled:
            raise RuntimeError(
                "run() requires explicit opt-in: "
                "AgentConfig(execution_mode='supervisor', handoff=True). "
                "Use add() for indexing and ask() for querying, "
                "or set the 'supervisor' preset."
            )

        db = database or self.database
        start = time.time()

        # Pass structured context (entities/relationships), not full history
        agent_ctx = self.context.to_agent_context(ontology=self.ontology)
        agent_ctx = "\n\n".join(
            item for item in [self._ontology_context.agent_context, agent_ctx] if item
        )
        context_block = f"\n\n{agent_ctx}" if agent_ctx else ""

        full_message = f"{message}{context_block}\n[Target database: {db}]"
        result_text = self._run_via_supervisor(full_message, db)

        elapsed = time.time() - start

        if self._trace:
            try:
                from .tracing import tracing_degraded_reasons
                obs_reasons = tracing_degraded_reasons()
            except Exception:
                obs_reasons = []
            self._trace.log_span(
                "session.run",
                input_data={"message": message[:200], "database": db},
                output_data={"response_preview": result_text[:300]},
                metadata={
                    "elapsed_seconds": round(elapsed, 2),
                    "user_id": self.user_id,
                    "workspace_id": self.workspace_id,
                    "degraded_observability": bool(obs_reasons),
                    "observability_degradation_reasons": obs_reasons,
                    "ontology_context": self._ontology_context.metadata(usage="agent"),
                },
                tags=["supervisor", "handoff"],
            )

        return result_text

    def _run_via_supervisor(self, message: str, database: str) -> str:
        """Run through supervisor agent with hand-off."""
        from .agents_runtime import get_agents_runtime

        supervisor = self._get_supervisor_agent()
        result = _run_sync(get_agents_runtime().run(agent=supervisor, input=message))
        return result.final_output or "No response from agent."

    def _get_supervisor_agent(self) -> Any:
        """Create or return the supervisor agent."""
        if not hasattr(self, '_supervisor_agent') or self._supervisor_agent is None:
            policy = getattr(self.agent_config, 'routing_policy', None) if self.agent_config else None
            self._supervisor_agent = create_supervisor_agent(
                ontology=self.ontology,
                graph_store=self.graph_store,
                llm=self.llm,
                vector_store=self.vector_store,
                extraction_prompt=self.extraction_prompt,
                routing_policy=policy,
                ontology_context=self._ontology_context,
                workspace_id=self.workspace_id,
            )
        return self._supervisor_agent

    def ask(
        self,
        question: str,
        *,
        database: Optional[str] = None,
        reasoning_mode: bool = True,
    ) -> str:
        """Ask a question through the query agent.

        The agent builds intent, calls text2cypher, executes, and
        synthesizes an answer. If results are empty, the agent retries
        with broader queries.

        Parameters
        ----------
        question:
            Natural-language question.
        database:
            Target database.
        reasoning_mode:
            Enable automatic query repair.
        Returns
        -------
        The synthesized answer string.
        """
        if self._closed:
            raise RuntimeError("Session is closed")

        db = database or self.database

        # seocho-9gdm: scope cache lookup by (workspace_id, database, ontology_hash)
        identity_hash = getattr(self._ontology_context.descriptor, "context_hash", "") or ""
        cached = self.context.get_cached_answer(
            question,
            workspace_id=self.workspace_id,
            database=db,
            ontology_identity_hash=identity_hash,
        )
        if cached is not None:
            self.context.add_query(question, cached, mode="cache")
            return cached

        # seocho-jdg: persistent cross-process cache (opt-in, OFF by default).
        # On hit, warm the in-memory cache so the rest of the session is fast too.
        persistent_key = None
        if self._response_cache is not None:
            persistent_key = self._make_response_cache_key(
                question,
                workspace_id=self.workspace_id,
                database=db,
                ontology_identity_hash=identity_hash,
            )
            hit = self._response_cache.get(persistent_key)
            if hit is not None:
                self.context.cache_query(
                    question, hit.answer,
                    workspace_id=self.workspace_id, database=db,
                    ontology_identity_hash=identity_hash,
                )
                self.context.add_query(question, hit.answer, mode="cache_persistent")
                return hit.answer

        start = time.time()

        # Pass structured context (entities, not history)
        agent_ctx = self.context.to_agent_context(ontology=self.ontology)
        agent_ctx = "\n\n".join(
            item for item in [self._ontology_context.agent_context, agent_ctx] if item
        )

        # ADR-0091: opt-in QueryEnrichmentRouter pre-stage. The thin slice
        # only stamps the augmentation into the agent context; full fan-out
        # arrives with the integration milestone.
        try:
            from seocho.agent.enrichment_router import enrichment_router_enabled

            if enrichment_router_enabled():
                from seocho.agent.enrichment_router import QueryEnrichmentRouter
                from seocho.routing import RoutingPolicy

                router = QueryEnrichmentRouter(policy=RoutingPolicy.default())
                augmentation = router.augment(question, workspace_id=self.workspace_id)
                intent_label = augmentation["intent"].get("intent", "lookup")
                entities = ", ".join(augmentation.get("entities", []) or [])
                aug_lines = [f"[Enrichment intent: {intent_label}]"]
                if entities:
                    aug_lines.append(f"[Enrichment entities: {entities}]")
                agent_ctx = "\n".join([*aug_lines, agent_ctx]) if agent_ctx else "\n".join(aug_lines)
        except Exception:
            # Enrichment is opt-in and must never break Session.ask().
            pass

        context_msg = f"\n\n{agent_ctx}\n[Target database: {db}]" if agent_ctx else ""

        mode = self._execution_mode
        if mode == "agent":
            query_result = self._ask_via_agent(question + context_msg, db)
        else:
            query_result = self._ask_via_pipeline(question, db, reasoning_mode)

        # seocho-qr74: stamp observability health on the local result dict
        # so the trace span below carries it.
        self._stamp_observability_health(query_result)

        answer = str(query_result.get("answer", "") or "")

        elapsed = time.time() - start
        self.context.add_query(
            question,
            answer,
            mode=str(query_result.get("mode", "agent") or "agent"),
            degraded=bool(query_result.get("degraded", False)),
            fallback_from=str(query_result.get("fallback_from", "")),
            fallback_reason=str(query_result.get("fallback_reason", "")),
        )
        # seocho-9gdm: scope cache write with the same identity tuple
        self.context.cache_query(
            question,
            answer,
            workspace_id=self.workspace_id,
            database=db,
            ontology_identity_hash=identity_hash,
        )
        # seocho-jdg: persist for cross-process reuse (opt-in). Only cache real
        # answers — never an empty/degraded result.
        if self._response_cache is not None and persistent_key is not None and answer.strip():
            if not bool(query_result.get("degraded", False)):
                self._response_cache.put(
                    persistent_key, answer,
                    metadata={"database": db, "mode": str(query_result.get("mode", "") or "")},
                )

        # Trace
        if self._trace:
            self._trace.log_span(
                "session.ask",
                input_data={"question": question, "database": db},
                output_data={
                    "answer_preview": answer[:300],
                    "mode": str(query_result.get("mode", "agent") or "agent"),
                },
                metadata={
                    "elapsed_seconds": round(elapsed, 2),
                    "degraded": bool(query_result.get("degraded", False)),
                    "fallback_from": str(query_result.get("fallback_from", "")),
                    "fallback_reason": str(query_result.get("fallback_reason", "")),
                    "user_id": self.user_id,
                    "workspace_id": self.workspace_id,
                    "degraded_observability": bool(query_result.get("degraded_observability", False)),
                    "observability_degradation_reasons": list(query_result.get("observability_degradation_reasons", [])),
                    "ontology_context": self._ontology_context.metadata(usage="agent_query"),
                },
                tags=["query"],
            )

        return answer

    def _add_via_agent(
        self,
        content: str,
        database: str,
        category: str,
        metadata: Optional[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """Run indexing through the agent with tool use."""
        from .agents_runtime import get_agents_runtime

        agent = self._get_indexing_agent()
        user_msg = (
            f"Index this text into database '{database}' with category '{category}'.\n\n"
            f"Text:\n{content}"
        )
        if metadata:
            user_msg += f"\n\nMetadata: {json.dumps(metadata, default=str)}"
        user_msg += f"\n\n{self._ontology_context.agent_context}"

        try:
            result = _run_sync(get_agents_runtime().run(agent=agent, input=user_msg))
            # Parse agent's final output for structured result
            parsed = self._parse_indexing_result(result.final_output, content)
            parsed["ontology_context"] = self._ontology_context.metadata(usage="agent_indexing")
            return parsed
        except Exception as exc:
            # seocho-lrvn (depends-on seocho-1zck): caller can opt into loud errors.
            on_failure = getattr(self.agent_config, "on_agent_failure", "fallback")
            if str(on_failure).lower() == "raise":
                logger.warning("Agent indexing failed and on_agent_failure='raise': %s", exc)
                raise
            logger.warning("Agent indexing failed, falling back to pipeline: %s", exc)
            fallback = self._add_via_pipeline(content, database, category, metadata)
            fallback["degraded"] = True
            fallback["fallback_from"] = "agent"
            fallback["fallback_reason"] = str(exc)
            return fallback

    def _ask_via_agent(self, question: str, database: str) -> Dict[str, Any]:
        """Run query through the agent with tool use."""
        from .agents_runtime import get_agents_runtime

        agent = self._get_query_agent()
        user_msg = (
            f"Answer this question using database '{database}':\n\n"
            f"{question}"
        )

        try:
            result = _run_sync(get_agents_runtime().run(agent=agent, input=user_msg))
            return {
                "answer": result.final_output or "No answer could be generated.",
                "mode": "agent",
                "degraded": False,
                "fallback_from": "",
                "fallback_reason": "",
                "ontology_context": self._ontology_context.metadata(usage="agent_query"),
            }
        except Exception as exc:
            # seocho-lrvn (depends-on seocho-1zck): same loud-error opt-in for query path.
            on_failure = getattr(self.agent_config, "on_agent_failure", "fallback")
            if str(on_failure).lower() == "raise":
                logger.warning("Agent query failed and on_agent_failure='raise': %s", exc)
                raise
            logger.warning("Agent query failed, falling back to pipeline: %s", exc)
            fallback = self._ask_via_pipeline(question, database, True)
            fallback["degraded"] = True
            fallback["fallback_from"] = "agent"
            fallback["fallback_reason"] = str(exc)
            return fallback

    def _add_via_pipeline(
        self,
        content: str,
        database: str,
        category: str,
        metadata: Optional[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """Direct pipeline fallback (no agent reasoning)."""
        pipeline = self._get_pipeline_engine()

        # Single add() call — no separate extract() to avoid double LLM calls
        memory = pipeline.add(
            content,
            database=database,
            category=category,
            metadata=metadata,
        )

        # For context cache: query what was actually written to the graph
        extracted_nodes: List[Dict] = []
        extracted_rels: List[Dict] = []
        if memory.status == "active" and self.graph_store is not None:
            try:
                sid = memory.memory_id
                rows = self.graph_store.query(
                    "MATCH (n) WHERE n._source_id = $sid "
                    "RETURN labels(n)[0] AS label, n.name AS name, properties(n) AS props",
                    params={"sid": sid}, database=database,
                )
                for row in rows:
                    extracted_nodes.append({
                        "label": row.get("label", ""),
                        "properties": {k: v for k, v in (row.get("props") or {}).items()
                                       if not k.startswith("_") and k != "id"},
                    })
            except Exception:
                pass

        return {
            "source_id": memory.memory_id,
            "nodes_created": int(memory.metadata.get("nodes_created", 0) or 0),
            "relationships_created": int(memory.metadata.get("relationships_created", 0) or 0),
            "chunks_processed": int(memory.metadata.get("chunks_processed", 0) or 0),
            "validation_errors": list(memory.metadata.get("validation_errors", []) or []),
            "write_errors": list(memory.metadata.get("write_errors", []) or []),
            "ok": memory.status == "active",
            "mode": "pipeline",
            "degraded": False,
            "fallback_from": "",
            "fallback_reason": "",
            "ontology_context": dict(memory.metadata.get("ontology_context", {}) or {}),
            "extracted_nodes": extracted_nodes,
            "extracted_relationships": extracted_rels,
        }

    def _ask_via_pipeline(self, question: str, database: str, reasoning_mode: bool) -> Dict[str, Any]:
        """Direct pipeline fallback for querying."""
        pipeline = self._get_pipeline_engine()
        answer = pipeline.ask(
            question,
            database=database,
            reasoning_mode=reasoning_mode,
        )
        return {
            "answer": answer,
            "mode": "pipeline",
            "degraded": False,
            "fallback_from": "",
            "fallback_reason": "",
            "ontology_context": self._ontology_context.metadata(usage="pipeline_query"),
        }

    def _parse_indexing_result(self, agent_output: str, original_text: str) -> Dict[str, Any]:
        """Parse the agent's final output into a structured result."""
        import re

        result = {
            "source_id": str(uuid.uuid4()),
            "nodes_created": 0,
            "relationships_created": 0,
            "ok": True,
            "mode": "agent",
            "degraded": False,
            "fallback_from": "",
            "fallback_reason": "",
            "agent_response": agent_output,
        }

        if not agent_output:
            return result

        # Try to find JSON in the agent output (tool results often contain it)
        json_patterns = re.findall(r'\{[^{}]*"nodes_written"\s*:\s*(\d+)[^{}]*\}', agent_output)
        if json_patterns:
            result["nodes_created"] = int(json_patterns[-1])

        json_rels = re.findall(r'\{[^{}]*"relationships_written"\s*:\s*(\d+)[^{}]*\}', agent_output)
        if json_rels:
            result["relationships_created"] = int(json_rels[-1])

        # Fallback: look for natural language mentions
        if result["nodes_created"] == 0:
            nodes_match = re.search(r"(\d+)\s*node", agent_output, re.IGNORECASE)
            if nodes_match:
                result["nodes_created"] = int(nodes_match.group(1))

        if result["relationships_created"] == 0:
            rels_match = re.search(r"(\d+)\s*(?:relationship|edge|rel)", agent_output, re.IGNORECASE)
            if rels_match:
                result["relationships_created"] = int(rels_match.group(1))

        # Check for error indicators
        if "error" in agent_output.lower() and result["nodes_created"] == 0:
            result["ok"] = False

        return result

    def traces(self) -> List[Dict[str, Any]]:
        """Return all trace spans from this session."""
        if self._trace:
            return self._trace.spans
        return []

    def ask_stream(
        self,
        question: str,
        *,
        database: Optional[str] = None,
    ):
        """Stream a query response token by token.

        Requires ``execution_mode="agent"`` or ``"supervisor"``.
        Yields partial text chunks as the agent generates them.

        Usage::

            for chunk in sess.ask_stream("Who is Samsung CEO?"):
                print(chunk, end="", flush=True)
        """
        if self._closed:
            raise RuntimeError("Session is closed")
        if self._execution_mode == "pipeline":
            # Pipeline mode: no streaming, yield full answer
            answer = self.ask(question, database=database)
            yield answer
            return

        db = database or self.database
        agent_ctx = self.context.to_agent_context(ontology=self.ontology)
        context_block = f"\n\n{agent_ctx}" if agent_ctx else ""
        full_msg = f"{question}{context_block}\n[Target database: {db}]"

        try:
            from .agents_runtime import get_agents_runtime
            agent = self._get_query_agent()

            def _make_stream():
                async def _agen():
                    result = get_agents_runtime().run_streamed(agent=agent, input=full_msg)
                    async for event in result.stream_events():
                        if hasattr(event, "data") and hasattr(event.data, "delta"):
                            yield event.data.delta

                return _agen()

            # Drive the async stream from a worker thread that owns its own loop,
            # so ask_stream is safe to call inside an already-running loop
            # (Jupyter/FastAPI) instead of crashing on a nested run_until_complete.
            # Chunks still stream in real time through the queue.
            yield from _stream_async_in_thread(_make_stream)
        except Exception as exc:
            logger.warning("Streaming failed, falling back: %s", exc)
            answer = self.ask(question, database=database)
            yield answer

    # -- operating-layer surface ------------------------------------------
    # These make one Session the coherent OS object: every subsystem is a
    # method here, not a free function taking the session as its first arg.
    # They require the handles attached by ``Seocho.session()`` (local mode).

    def _require_os(self) -> None:
        if self._os is None or self._os_session is None:
            from .exceptions import SeochoError

            raise SeochoError(
                "operating-layer methods need a session created by "
                "Seocho.session() in local mode (ontology + graph_store).")

    def query(self, cypher: str, **params: Any) -> List[Dict[str, Any]]:
        """Governed graph read — the scheduling + isolation + memory-read path.

        Runs through the shared admission gate (scheduling), pins this
        session's workspace server-side (isolation), and executes fail-closed
        (``enforce_workspace_filter``). Named parameters pass through as
        ``$name``. Returns the row list; raises on a structured error so
        callers see admission rejection / query failure rather than a silent
        empty result.
        """
        import json as _json

        self._require_os()
        payload = self._os.execute_query(
            self._os_session, cypher, _json.dumps(params, default=str))
        result = _json.loads(payload)
        if "error" in result:
            from .exceptions import SeochoError

            raise SeochoError(
                f"query failed [{result['error']}]: {result.get('message', '')}")
        return result.get("rows", [])

    def resolve(self, mention: str, *, label: Optional[str] = None,
                **identity_props: Any) -> Optional[Dict[str, Any]]:
        """Resolve a surface mention to the one canonical node it denotes.

        Read-time interning: this reuses the exact write-time identity
        function (``seocho.index.identity.compute_node_identity``), so the
        resolution recall/precision are the interning collapse/collision
        measured in ADR-0160/0161/0162 — guaranteed-precision, model-free,
        O(1) address lookup, scoped to this session's workspace.

        Give a ``label`` (and any disambiguating identity properties) to use
        the composite key — the precise path. With no label it falls back to a
        normalized-name match, whose miss on un-normalized surface forms
        (e.g. legal suffixes) is the documented recall ceiling a semantic
        fallback would close (seocho-6l8). Returns the node dict, or ``None``.
        """
        self._require_os()
        from .index.identity import _normalize_segment, compute_node_identity

        nodes = getattr(self.ontology, "nodes", {}) or {}
        if label and label in nodes:
            node_def = nodes[label]
            keys = list(getattr(node_def, "effective_identity_keys", [])
                        or getattr(node_def, "identity_keys", []) or ["name"])
            props = dict(identity_props)
            props.setdefault("name", mention)
            addr = compute_node_identity(label, props, keys)
            if addr:
                # label is validated by membership in the ontology above.
                rows = self.query(
                    f"MATCH (n:`{label}`) WHERE n.id = $addr "
                    "AND n._workspace_id = $workspace_id RETURN n LIMIT 1",
                    addr=addr)
                if rows:
                    node = rows[0].get("n", rows[0])
                    return {"node": node, "address": addr, "method": "intern"}
        # Fallback: normalized-name equality (best-effort; recall-ceiling path).
        norm = _normalize_segment(mention)
        rows = self.query(
            "MATCH (n) WHERE n.name IS NOT NULL "
            "AND n._workspace_id = $workspace_id "
            "AND toLower(trim(n.name)) = $norm RETURN n LIMIT 5",
            norm=norm)
        if rows:
            node = rows[0].get("n", rows[0])
            return {"node": node, "address": None, "method": "normalized_name",
                    "candidates": len(rows)}
        return None

    def agent(self, *, name: str = "seocho_agent", model: Any = None,
              extra_tools: Sequence[Any] = ()) -> Any:
        """An openai-agents Agent whose only graph access is this governed
        session — the execution subsystem. Hand it to ``Runner.run(agent,
        msg, session=sess.sdk_session, hooks=sess.hooks)`` so memory,
        budget, and admission all ride along."""
        self._require_os()
        return self._os.build_agent(
            self._os_session, name=name, model=model, extra_tools=extra_tools)

    def os_stats(self) -> Dict[str, Any]:
        """Operating-layer observability: shared pool + this session's budget."""
        self._require_os()
        stats = dict(self._os.stats())
        stats["priority"] = self.priority
        if self.budget is not None:
            stats["budget"] = getattr(self.budget, "budget", 0)
        return stats

    def close(self) -> Dict[str, Any]:
        """Close the session and finalize traces.

        Returns a summary of the session.
        """
        if self._closed:
            return {"status": "already_closed"}

        self._closed = True
        summary = {
            "session_id": self.session_id,
            "name": self.name,
            "indexed_documents": len(self.context.indexed_sources),
            "total_nodes": self.context.total_nodes,
            "total_relationships": self.context.total_relationships,
            "queries_answered": len(self.context.queries),
            "degraded_operations": sum(
                1
                for record in [*self.context.indexed_sources, *self.context.queries]
                if bool(record.get("degraded", False))
            ),
            "context_summary": self.context.summary(),
        }

        if self._trace:
            trace_summary = self._trace.end()
            summary["trace"] = trace_summary

        return summary

    def __enter__(self) -> "Session":
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self.close()

    def __repr__(self) -> str:
        status = "closed" if self._closed else "active"
        return (
            f"Session(name={self.name!r}, id={self.session_id!r}, "
            f"status={status}, docs={len(self.context.indexed_sources)}, "
            f"queries={len(self.context.queries)})"
        )
