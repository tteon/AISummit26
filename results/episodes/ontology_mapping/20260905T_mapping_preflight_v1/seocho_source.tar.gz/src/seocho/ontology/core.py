"""
Ontology — first-class primitive of the SEOCHO SDK.

An Ontology defines the schema that governs both knowledge-graph construction
(extraction/indexing) and querying.  It is the single source of truth that
feeds into system prompts, dynamic prompts, Cypher constraint generation,
and post-extraction validation.

Quick start::

    from seocho import Ontology, NodeDef, RelDef, P

    onto = Ontology(
        name="company_graph",
        nodes={
            "Company": NodeDef(
                description="A registered business entity",
                properties={"name": P(str, unique=True), "ticker": P(str, index=True)},
            ),
            "Person": NodeDef(
                description="An individual",
                properties={"name": P(str, unique=True), "role": P(str)},
            ),
        },
        relationships={
            "WORKS_AT": RelDef(source="Person", target="Company", cardinality="MANY_TO_ONE"),
        },
    )

Or load from YAML / JSON-LD::

    onto = Ontology.from_yaml("schema.yaml")
    onto = Ontology.from_jsonld("schema.jsonld")

Canonical storage is **JSON-LD**; SHACL shapes are derived for validation::

    onto.to_jsonld("schema.jsonld")   # persist
    shacl = onto.to_shacl()           # derive validation shapes
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Set, Tuple, Union

import yaml

from seocho.cypher_ident import IDENT_RE as _LABEL_RE  # canonical identifier regex

# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

_PY_TO_GRAPH_TYPE: Dict[type, str] = {
    str: "STRING",
    int: "INTEGER",
    float: "FLOAT",
    bool: "BOOLEAN",
}


class PropertyType(Enum):
    STRING = "STRING"
    INTEGER = "INTEGER"
    FLOAT = "FLOAT"
    BOOLEAN = "BOOLEAN"
    DATETIME = "DATETIME"
    DATE = "DATE"
    POINT = "POINT"
    LIST = "LIST"


class ConstraintType(Enum):
    UNIQUE = "UNIQUE"
    NODE_KEY = "NODE_KEY"
    EXISTS = "EXISTS"


class Cardinality(Enum):
    ONE_TO_ONE = "ONE_TO_ONE"
    ONE_TO_MANY = "ONE_TO_MANY"
    MANY_TO_ONE = "MANY_TO_ONE"
    MANY_TO_MANY = "MANY_TO_MANY"


# ---------------------------------------------------------------------------
# Property shorthand — ``P(str, unique=True)``
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class Property:
    """Property definition for a node or relationship.

    Parameters
    ----------
    type:
        Python type (``str``, ``int``, ``float``, ``bool``) or a
        :class:`PropertyType` enum value.
    unique:
        Whether this property carries a UNIQUE constraint.
    index:
        Whether this property should have a standalone index.
    required:
        Whether the property is mandatory (maps to EXISTS constraint).
    description:
        Human-readable description shown in prompts.
    aliases:
        Alternative names an LLM might use for this property.
    enum:
        Optional allowed value set. An extracted value outside it is a
        validation error, emitted as ``sh:in`` and enforced by
        :meth:`validate_with_shacl`.
    value_range:
        Optional inclusive numeric ``(min, max)`` bound, emitted as
        ``sh:minInclusive`` / ``sh:maxInclusive``.

    Example::

        from seocho import Property

        name = Property(str, unique=True)
        age = Property(int, required=True, description="Age in years")
        rating = Property(str, enum=["buy", "hold", "sell"])
        score = Property(float, value_range=(0.0, 1.0))
    """

    type: Union[type, PropertyType, str] = str
    unique: bool = False
    index: bool = False
    required: bool = False
    description: str = ""
    aliases: List[str] = field(default_factory=list)
    enum: Optional[List[Any]] = None
    value_range: Optional[Tuple[float, float]] = None

    @property
    def property_type(self) -> PropertyType:
        if isinstance(self.type, PropertyType):
            return self.type
        if isinstance(self.type, builtins_type) and self.type in _PY_TO_GRAPH_TYPE:
            return PropertyType[_PY_TO_GRAPH_TYPE[self.type]]
        if isinstance(self.type, str):
            return PropertyType[self.type.upper()]
        return PropertyType.STRING

    @property
    def constraint(self) -> Optional[ConstraintType]:
        if self.unique:
            return ConstraintType.UNIQUE
        if self.required:
            return ConstraintType.EXISTS
        return None


# Backward-compatible short alias. New code should prefer ``Property``.
P = Property


# cache builtin ``type`` before it gets shadowed
builtins_type = type


# ---------------------------------------------------------------------------
# Node / Relationship definitions
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class NodeDef:
    """Definition of a node (entity) type in the ontology.

    Also available under the longer alias ``NodeDefinition``.
    """

    description: str = ""
    properties: Dict[str, P] = field(default_factory=dict)
    aliases: List[str] = field(default_factory=list)
    broader: List[str] = field(default_factory=list)
    same_as: Optional[str] = None  # e.g. "schema:Organization"
    # seocho-uxs: ordered property names that TOGETHER identify one
    # real-world entity. When set, identity is the tuple — not the first
    # ``unique=True`` property. This is the "distinguishing point" for
    # dimension-bearing entities: two documents that both mention a
    # "Total revenue" FinancialMetric are the same node only when their
    # (name, company, year) match, instead of collapsing on name alone.
    # Empty == legacy behavior (single unique property / id is the key).
    identity_keys: List[str] = field(default_factory=list)
    # seocho-zfe D2-2: when True, this type's entities are the SAME real entity
    # across sources when their name matches — so the SAME name written from two
    # sources (with different labels: company|acme vs organization|acme) converges
    # to ONE canonical id / one physical node, enabling cross-source joins. Opt-in
    # (default False): the modeler declares which types are globally name-unique,
    # so name-merge never fuses genuinely-distinct types (Apple the company vs the
    # fruit) or homonym-prone metrics (which use identity_keys instead).
    cross_source_unique: bool = False

    # --- introspection helpers ------------------------------------------------

    @property
    def unique_properties(self) -> List[str]:
        return [name for name, p in self.properties.items() if p.unique]

    @property
    def effective_identity_keys(self) -> List[str]:
        """Ordered identity properties: explicit ``identity_keys`` when
        declared, else the single first ``unique=True`` property, else empty."""
        if self.identity_keys:
            return list(self.identity_keys)
        unique = self.unique_properties
        return unique[:1]

    @property
    def indexed_properties(self) -> List[str]:
        return [name for name, p in self.properties.items() if p.index]

    @property
    def required_properties(self) -> List[str]:
        return [name for name, p in self.properties.items() if p.required or p.unique]


@dataclass(slots=True)
class RelDef:
    """Definition of a relationship type in the ontology.

    Also available under the longer alias ``RelationshipDefinition``.
    """

    source: str = "Any"
    target: str = "Any"
    description: str = ""
    cardinality: str = "MANY_TO_MANY"
    properties: Dict[str, P] = field(default_factory=dict)
    aliases: List[str] = field(default_factory=list)
    same_as: Optional[str] = None  # e.g. "schema:worksFor"

    # Directional roles. ``source``/``target`` say which *types* an edge connects,
    # which is enough to orient ``Account -> Channel`` but says nothing at all when
    # both ends carry the same label. For ``TRANSFER: Account -> Account`` the
    # endpoints are indistinguishable by type, so "which accounts did X send to" and
    # "which accounts sent to X" are the same query as far as the schema is concerned —
    # and query construction silently picked one. Measured on a power-law graph, that
    # produced systematically direction-reversed answers (in-degree returned for every
    # out-degree question) with the orientation guardrail reporting nothing to repair.
    #
    # Naming the roles makes the distinction expressible: the phrasing of a question
    # can be matched against the role a node plays, rather than against its label.
    source_role: str = ""       # e.g. "sender"
    target_role: str = ""       # e.g. "beneficiary"
    # Phrases that indicate the anchor is the *source* / *target* of the edge. Kept on
    # the relationship rather than in a prompt because the prompt can only convey what
    # the ontology holds, and because these are domain facts ("wired to", "credited by")
    # that belong with the schema they describe.
    source_phrases: List[str] = field(default_factory=list)
    target_phrases: List[str] = field(default_factory=list)

    # Measured degree facts for this relationship, e.g.
    # ``{"median_out": 6, "p99_out": 73, "max_out": 158315, "heavy_tailed": true}``.
    #
    # The same argument that motivated roles applies here. A prompt can only convey what
    # the schema holds, and nothing in a schema of labels, property names and endpoint
    # types says that one account carries 158,315 transfer edges while the median carries
    # six. So a model has no basis for preferring a bounded shape, and the measured
    # consequence is not subtle: on a power-law graph an aggregate anchored on a hub does
    # not return at all, while the same question on a median node costs 45 ms.
    #
    # Intended to be *derived from the data* rather than asserted — the values above come
    # from ``scripts/finbench/graph_properties.py``, which is the same role FinBench's
    # factor tables play. An ontology that states a distribution it did not measure is
    # worse than one that stays silent.
    degree_hint: Dict[str, Any] = field(default_factory=dict)


# Explicit long-form aliases for users who prefer self-documenting names.
# ``NodeDef`` / ``RelDef`` remain the canonical in-code names for brevity in
# dict literals; these aliases are fully equivalent.
NodeDefinition = NodeDef
RelationshipDefinition = RelDef


# ---------------------------------------------------------------------------
# Ontology
# ---------------------------------------------------------------------------


class Ontology:
    """Schema definition that drives extraction prompts, query prompts,
    graph constraints, and post-extraction validation.

    Parameters
    ----------
    name:
        Human-readable ontology name (appears in LLM prompts).
    package_id:
        Stable governance identifier for the ontology package lineage.
    version:
        Semantic version string.
    description:
        One-liner shown at the top of generated prompts.
    nodes:
        Mapping of label -> :class:`NodeDef`.
    relationships:
        Mapping of rel_type -> :class:`RelDef`.
    """

    def __init__(
        self,
        name: str,
        *,
        package_id: str = "",
        version: str = "1.0.0",
        description: str = "",
        graph_model: str = "lpg",  # "lpg", "rdf", "hybrid"
        namespace: str = "",  # RDF namespace URI (e.g. "https://schema.org/")
        nodes: Optional[Dict[str, NodeDef]] = None,
        relationships: Optional[Dict[str, RelDef]] = None,
    ) -> None:
        self.name = name
        self.package_id = package_id.strip() or name
        self.version = version
        self.description = description
        self.graph_model = graph_model
        self.namespace = namespace
        self.nodes: Dict[str, NodeDef] = dict(nodes or {})
        self.relationships: Dict[str, RelDef] = dict(relationships or {})
        self._allowed_labels: Set[str] = set(self.nodes.keys())

    # ------------------------------------------------------------------
    # Loaders
    # ------------------------------------------------------------------

    @classmethod
    def load(cls, path: Union[str, Path]) -> "Ontology":
        """Load an ontology from a path by file extension.

        Supported suffixes:

        - ``.jsonld`` / ``.json`` → :meth:`from_jsonld`
        - ``.yaml`` / ``.yml`` → :meth:`from_yaml`
        - ``.ttl`` → :meth:`from_ttl`
        - ``.owl`` → :meth:`from_owl`
        """
        suffix = Path(path).suffix.lower()
        if suffix in {".yaml", ".yml"}:
            return cls.from_yaml(path)
        if suffix in {".jsonld", ".json"}:
            return cls.from_jsonld(path)
        if suffix == ".ttl":
            return cls.from_ttl(path)
        if suffix == ".owl":
            return cls.from_owl(path)
        raise ValueError(
            "Unsupported ontology file extension. Use .jsonld/.json, .yaml/.yml, .ttl, or .owl "
            "or call the explicit loader directly."
        )

    @classmethod
    def from_yaml(cls, path: Union[str, Path]) -> "Ontology":
        """Load an ontology from a YAML file.

        Expected YAML structure::

            graph_type: financial
            version: "1.0.0"
            description: "Financial entity schema"
            nodes:
              Company:
                description: "A registered business"
                aliases: [Firm, Corp]
                properties:
                  name:
                    type: STRING
                    constraint: UNIQUE
                  ticker:
                    type: STRING
                    index: true
            relationships:
              WORKS_AT:
                source: Person
                target: Company
                cardinality: MANY_TO_ONE
                description: "Employment"
        """
        with open(path, "r") as fh:
            data = yaml.safe_load(fh)
        return cls._from_dict(data)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Ontology":
        """Build from a plain dict (e.g. JSON payload)."""
        return cls._from_dict(data)

    @classmethod
    def _from_dict(cls, data: Dict[str, Any]) -> "Ontology":
        nodes: Dict[str, NodeDef] = {}
        for label, nd in (data.get("nodes") or {}).items():
            props: Dict[str, P] = {}
            for pname, pd in (nd.get("properties") or {}).items():
                ptype = PropertyType[pd.get("type", "STRING").upper()] if isinstance(pd, dict) else PropertyType.STRING
                constraint_str = pd.get("constraint", "").upper() if isinstance(pd, dict) else ""
                enum_vals = pd.get("enum") if isinstance(pd, dict) else None
                range_vals = pd.get("range") if isinstance(pd, dict) else None
                props[pname] = P(
                    type=ptype,
                    unique=constraint_str == "UNIQUE",
                    index=pd.get("index", False) if isinstance(pd, dict) else False,
                    required=pd.get("required", False) if isinstance(pd, dict) else False,
                    description=pd.get("description", "") if isinstance(pd, dict) else "",
                    aliases=pd.get("aliases", []) if isinstance(pd, dict) else [],
                    enum=list(enum_vals) if enum_vals is not None else None,
                    value_range=(float(range_vals[0]), float(range_vals[1]))
                    if range_vals and len(range_vals) == 2 else None,
                )
            nodes[label] = NodeDef(
                description=nd.get("description", ""),
                properties=props,
                aliases=nd.get("aliases", []),
                broader=nd.get("broader", []),
                same_as=nd.get("sameAs") or nd.get("same_as"),
                identity_keys=list(nd.get("identity_keys", []) or nd.get("identityKeys", [])),
                cross_source_unique=bool(
                    nd.get("cross_source_unique", nd.get("crossSourceUnique", False))
                ),
            )

        rels: Dict[str, RelDef] = {}
        for rtype, rd in (data.get("relationships") or {}).items():
            rprops: Dict[str, P] = {}
            for pname, pd in (rd.get("properties") or {}).items():
                ptype = PropertyType[pd.get("type", "STRING").upper()] if isinstance(pd, dict) else PropertyType.STRING
                rprops[pname] = P(
                    type=ptype,
                    description=pd.get("description", "") if isinstance(pd, dict) else "",
                )
            rels[rtype] = RelDef(
                source=rd.get("source", "Any"),
                target=rd.get("target", "Any"),
                description=rd.get("description", ""),
                cardinality=rd.get("cardinality", "MANY_TO_MANY"),
                properties=rprops,
                aliases=rd.get("aliases", []),
                same_as=rd.get("sameAs") or rd.get("same_as"),
                source_role=rd.get("sourceRole") or rd.get("source_role") or "",
                target_role=rd.get("targetRole") or rd.get("target_role") or "",
                source_phrases=list(
                    rd.get("sourcePhrases") or rd.get("source_phrases") or []),
                target_phrases=list(
                    rd.get("targetPhrases") or rd.get("target_phrases") or []),
                degree_hint=dict(
                    rd.get("degreeHint") or rd.get("degree_hint") or {}),
            )

        return cls(
            name=data.get("graph_type") or data.get("name") or "Unnamed",
            package_id=data.get("package_id", "") or data.get("packageId", "") or data.get("graph_type") or data.get("name") or "Unnamed",
            version=data.get("version", "1.0.0"),
            description=data.get("description", ""),
            graph_model=data.get("graph_model", "lpg"),
            namespace=data.get("namespace", ""),
            nodes=nodes,
            relationships=rels,
        )

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to a plain dict suitable for YAML/JSON export."""
        nodes_out: Dict[str, Any] = {}
        for label, nd in self.nodes.items():
            props_out: Dict[str, Any] = {}
            for pname, p in nd.properties.items():
                entry: Dict[str, Any] = {"type": p.property_type.value}
                if p.constraint:
                    entry["constraint"] = p.constraint.value
                if p.index:
                    entry["index"] = True
                if p.required:
                    entry["required"] = True
                if p.description:
                    entry["description"] = p.description
                if p.aliases:
                    entry["aliases"] = list(p.aliases)
                if p.enum is not None:
                    entry["enum"] = list(p.enum)
                if p.value_range is not None:
                    entry["range"] = [p.value_range[0], p.value_range[1]]
                props_out[pname] = entry
            node_entry: Dict[str, Any] = {"description": nd.description, "properties": props_out}
            if nd.same_as:
                node_entry["sameAs"] = nd.same_as
            if nd.aliases:
                node_entry["aliases"] = list(nd.aliases)
            if nd.broader:
                node_entry["broader"] = list(nd.broader)
            if nd.identity_keys:
                node_entry["identity_keys"] = list(nd.identity_keys)
            if getattr(nd, "cross_source_unique", False):
                node_entry["cross_source_unique"] = True
            nodes_out[label] = node_entry

        rels_out: Dict[str, Any] = {}
        for rtype, rd in self.relationships.items():
            rel_entry: Dict[str, Any] = {
                "source": rd.source,
                "target": rd.target,
                "description": rd.description,
                "cardinality": rd.cardinality,
            }
            if rd.same_as:
                rel_entry["sameAs"] = rd.same_as
            if rd.aliases:
                rel_entry["aliases"] = list(rd.aliases)
            if rd.source_role:
                rel_entry["sourceRole"] = rd.source_role
            if rd.target_role:
                rel_entry["targetRole"] = rd.target_role
            if rd.source_phrases:
                rel_entry["sourcePhrases"] = list(rd.source_phrases)
            if rd.target_phrases:
                rel_entry["targetPhrases"] = list(rd.target_phrases)
            if rd.degree_hint:
                rel_entry["degreeHint"] = dict(rd.degree_hint)
            if rd.properties:
                rp: Dict[str, Any] = {}
                for pname, p in rd.properties.items():
                    rp[pname] = {"type": p.property_type.value}
                    if p.description:
                        rp[pname]["description"] = p.description
                rel_entry["properties"] = rp
            rels_out[rtype] = rel_entry

        result: Dict[str, Any] = {
            "graph_type": self.name,
            "package_id": self.package_id,
            "version": self.version,
            "description": self.description,
            "graph_model": self.graph_model,
        }
        if self.namespace:
            result["namespace"] = self.namespace
        result["nodes"] = nodes_out
        result["relationships"] = rels_out
        return result

    def to_yaml(self, path: Union[str, Path]) -> None:
        """Export ontology to a YAML file."""
        with open(path, "w") as fh:
            yaml.dump(self.to_dict(), fh, sort_keys=False, default_flow_style=False)

    # ------------------------------------------------------------------
    # JSON-LD — canonical storage format
    # ------------------------------------------------------------------

    #: Default JSON-LD @context for SEOCHO ontologies.
    JSONLD_CONTEXT: Dict[str, str] = {
        "schema": "https://schema.org/",
        "skos": "http://www.w3.org/2004/02/skos/core#",
        "sh": "http://www.w3.org/ns/shacl#",
        "xsd": "http://www.w3.org/2001/XMLSchema#",
        "seocho": "https://seocho.dev/ontology/",
    }

    @classmethod
    def from_jsonld(cls, path: Union[str, Path]) -> "Ontology":
        """Load an ontology from a JSON-LD file.

        This is the **canonical** persistence format.  The JSON-LD
        ``@context`` connects node labels to standard vocabularies
        (schema.org, SKOS) while keeping the file human-editable.

        Example file::

            {
              "@context": { ... },
              "@id": "seocho:financial",
              "@type": "seocho:Ontology",
              "name": "financial",
              "version": "1.0.0",
              "nodes": {
                "Company": {
                  "description": "기업",
                  "sameAs": "schema:Organization",
                  "aliases": ["기업", "회사"],
                  "properties": {
                    "name": {"type": "string", "unique": true}
                  }
                }
              },
              "relationships": { ... }
            }
        """
        from .serialization import ontology_from_jsonld_path

        return ontology_from_jsonld_path(cls, path)

    @classmethod
    def from_jsonld_dict(cls, data: Dict[str, Any]) -> "Ontology":
        """Build from a parsed JSON-LD dict."""
        from .serialization import ontology_from_jsonld_dict

        return ontology_from_jsonld_dict(cls, data)

    # ------------------------------------------------------------------
    # Turtle (TTL / OWL)
    # ------------------------------------------------------------------
    #
    # ``from_ttl`` is defined further down with an inline rdflib
    # implementation (seocho-aom8 removed an earlier delegate to
    # ``ontology_serialization.ontology_from_ttl`` that was unreachable —
    # Python class body uses the last definition, and no caller passed
    # the delegate's ``name=`` / ``namespace=`` kwargs). The inline
    # version handles ``skos:altLabel`` and a wider ``owl:versionInfo``
    # / version-IRI fallback that the delegate did not.

    def to_ttl(self, path: Union[str, Path]) -> Path:
        """Write this ontology out as Turtle. Inverse of :meth:`from_ttl`."""
        from .serialization import ontology_to_ttl

        return ontology_to_ttl(self, path)

    @classmethod
    def _from_jsonld_dict(cls, data: Dict[str, Any]) -> "Ontology":
        from .serialization import ontology_from_jsonld_dict

        return ontology_from_jsonld_dict(cls, data)
    @classmethod
    def from_owl(cls, path: Union[str, Path]) -> "Ontology":
        """Load an OWL/RDF ontology file.

        SEOCHO materialises the same structural subset as :meth:`from_ttl`:
        classes, object properties with domain/range, datatype properties, and
        common labels/descriptions/aliases. RDF/XML is the common ``.owl``
        serialization, but rdflib may also infer other RDF serializations from
        the file content.

        Requires :mod:`rdflib` (``pip install rdflib``).
        """
        try:
            import rdflib
        except ImportError as exc:
            raise ImportError(
                "Ontology.from_owl requires rdflib. Install it via "
                "`pip install rdflib`."
            ) from exc

        import tempfile

        graph = rdflib.Graph()
        graph.parse(str(path))
        with tempfile.NamedTemporaryFile("w", suffix=".ttl", encoding="utf-8") as fh:
            fh.write(graph.serialize(format="turtle"))
            fh.flush()
            return cls.from_ttl(fh.name)

    @classmethod
    def from_ttl(cls, path: Union[str, Path]) -> "Ontology":
        """Load an ontology from an OWL/SKOS Turtle (.ttl) file.

        Only the structural pieces useful for ontology-aware extraction
        are read: ``owl:Class`` declarations, ``owl:ObjectProperty``
        relations with ``rdfs:domain`` / ``rdfs:range``, plus
        ``rdfs:label`` / ``rdfs:comment`` / ``skos:definition`` for
        descriptions. Subclass hierarchies and most annotations are not
        materialised — callers needing a faithful OWL round-trip should
        use a dedicated triplestore instead.

        Requires :mod:`rdflib` (``pip install rdflib``).
        """
        try:
            import rdflib
        except ImportError as exc:
            raise ImportError(
                "Ontology.from_ttl requires rdflib. Install it via "
                "`pip install rdflib`."
            ) from exc

        from rdflib.namespace import RDF, RDFS, OWL, XSD

        SKOS = rdflib.Namespace("http://www.w3.org/2004/02/skos/core#")
        g = rdflib.Graph()
        g.parse(str(path), format="turtle")

        def _local(uri: Any) -> str:
            s = str(uri)
            return s.rsplit("#", 1)[-1].rsplit("/", 1)[-1]

        def _label(uri: Any) -> str:
            for lit in g.objects(uri, RDFS.label):
                return str(lit)
            return _local(uri)

        def _description(uri: Any) -> str:
            for lit in g.objects(uri, SKOS.definition):
                return str(lit)
            for lit in g.objects(uri, RDFS.comment):
                return str(lit)
            return ""

        def _aliases(uri: Any, canonical_name: str) -> List[str]:
            aliases: List[str] = []
            # skos:altLabel is the canonical alias predicate; rdfs:label is
            # secondary (used when authors didn't separate primary vs alt).
            # Reading both keeps to_ttl / from_ttl alias round-tripping intact
            # (seocho.ontology_serialization emits aliases as skos:altLabel).
            for predicate in (SKOS.altLabel, RDFS.label):
                for lit in g.objects(uri, predicate):
                    value = str(lit).strip()
                    if value and value != canonical_name and value not in aliases:
                        aliases.append(value)
            return aliases

        def _namespace(uri: Any) -> str:
            text = str(uri).strip()
            if not text:
                return ""
            if "#" in text:
                return text.rsplit("#", 1)[0] + "#"
            if "/" in text:
                return text.rsplit("/", 1)[0] + "/"
            return ""

        def _normalize_semver(raw: str) -> str:
            text = str(raw).strip()
            if not text:
                return "1.0.0"
            if re.fullmatch(r"\d+", text):
                return f"{text}.0.0"
            if re.fullmatch(r"\d+\.\d+", text):
                return f"{text}.0"
            return text

        def _ontology_version(uri: Any) -> str:
            for predicate in (OWL.versionInfo,):
                for value in g.objects(uri, predicate):
                    normalized = _normalize_semver(str(value))
                    if normalized:
                        return normalized
            for version_iri in g.objects(uri, OWL.versionIRI):
                text = str(version_iri).strip()
                if not text:
                    continue
                match = re.search(r"(\d+\.\d+\.\d+|\d+\.\d+|\d+)", text)
                if match:
                    return _normalize_semver(match.group(1))
            return "1.0.0"

        def _property_type(range_uri: Any) -> str:
            text = str(range_uri)
            mapping = {
                str(XSD.string): "STRING",
                str(XSD.normalizedString): "STRING",
                str(XSD.token): "STRING",
                str(XSD.integer): "INTEGER",
                str(XSD.int): "INTEGER",
                str(XSD.long): "INTEGER",
                str(XSD.short): "INTEGER",
                str(XSD.decimal): "FLOAT",
                str(XSD.float): "FLOAT",
                str(XSD.double): "FLOAT",
                str(XSD.boolean): "BOOLEAN",
                str(XSD.date): "DATE",
                str(XSD.dateTime): "DATETIME",
            }
            return mapping.get(text, "STRING")

        ontology_uris = [
            uri for uri in g.subjects(RDF.type, OWL.Ontology)
            if not isinstance(uri, rdflib.BNode)
        ]
        ontology_uri = ontology_uris[0] if ontology_uris else None

        nodes: Dict[str, Dict[str, Any]] = {}
        # local-name -> list of local-names of named superclasses (rdfs:subClassOf).
        # External / blank supers are dropped after the full class set is known.
        subclass_of: Dict[str, List[str]] = {}
        for cls_uri in (
            set(g.subjects(RDF.type, OWL.Class))
            | set(g.subjects(RDF.type, RDFS.Class))
        ):
            if isinstance(cls_uri, rdflib.BNode):
                continue
            name = _local(cls_uri)
            label = _label(cls_uri)
            nodes.setdefault(
                name,
                {
                    "description": _description(cls_uri),
                    "properties": {},
                    "aliases": _aliases(cls_uri, name) or ([label] if label != name else []),
                    "sameAs": str(cls_uri),
                },
            )
            parents = [
                _local(parent)
                for parent in g.objects(cls_uri, RDFS.subClassOf)
                if isinstance(parent, rdflib.URIRef)
            ]
            if parents:
                subclass_of.setdefault(name, [])
                for parent in parents:
                    if parent != name and parent not in subclass_of[name]:
                        subclass_of[name].append(parent)

        relationships: Dict[str, Dict[str, Any]] = {}
        for prop in set(g.subjects(RDF.type, OWL.ObjectProperty)):
            domains = [
                _local(d)
                for d in g.objects(prop, RDFS.domain)
                if not isinstance(d, rdflib.BNode)
            ]
            ranges = [
                _local(r)
                for r in g.objects(prop, RDFS.range)
                if not isinstance(r, rdflib.BNode)
            ]
            if not (domains and ranges):
                continue
            rname = _local(prop)
            relationships.setdefault(
                rname,
                {
                    "source": domains[0],
                    "target": ranges[0],
                    "description": _description(prop),
                    "aliases": _aliases(prop, rname),
                    "sameAs": str(prop),
                },
            )
            for endpoint in (domains[0], ranges[0]):
                nodes.setdefault(
                    endpoint,
                    {"description": "", "properties": {}, "aliases": [], "sameAs": ""},
                )

        datatype_props = {
            prop
            for prop in g.subjects(RDF.type, OWL.DatatypeProperty)
            if not isinstance(prop, rdflib.BNode)
        }
        for prop in set(g.subjects(RDFS.range, None)):
            if isinstance(prop, rdflib.BNode):
                continue
            ranges = [rng for rng in g.objects(prop, RDFS.range) if not isinstance(rng, rdflib.BNode)]
            if any(str(rng).startswith(str(XSD)) for rng in ranges):
                datatype_props.add(prop)

        for prop in datatype_props:
            pname = _local(prop)
            domains = [
                _local(domain)
                for domain in g.objects(prop, RDFS.domain)
                if not isinstance(domain, rdflib.BNode)
            ]
            ranges = [
                rng
                for rng in g.objects(prop, RDFS.range)
                if not isinstance(rng, rdflib.BNode)
            ]
            if not domains:
                continue

            prop_payload: Dict[str, Any] = {
                "type": _property_type(ranges[0]) if ranges else "STRING",
                "description": _description(prop),
            }
            aliases = _aliases(prop, pname)
            if aliases:
                prop_payload["aliases"] = aliases

            for domain_name in domains:
                node_payload = nodes.setdefault(
                    domain_name,
                    {"description": "", "properties": {}, "aliases": [], "sameAs": ""},
                )
                node_payload.setdefault("properties", {})
                node_payload["properties"].setdefault(pname, dict(prop_payload))

        default_name = Path(path).stem
        ontology_name = _label(ontology_uri) if ontology_uri is not None else default_name
        ontology_namespace = (
            _namespace(ontology_uri)
            if ontology_uri is not None
            else next(
                (
                    _namespace(uri)
                    for uri in list(g.subjects(RDF.type, OWL.Class)) + list(g.subjects(RDF.type, OWL.ObjectProperty))
                    if not isinstance(uri, rdflib.BNode) and _namespace(uri)
                ),
                "",
            )
        )
        package_id = _local(ontology_uri) if ontology_uri is not None else default_name
        ontology_version = _ontology_version(ontology_uri) if ontology_uri is not None else "1.0.0"
        ontology_description = _description(ontology_uri) if ontology_uri is not None else ""

        # Resolve rdfs:subClassOf into NodeDef.broader, keeping only parents that
        # are themselves classes in this ontology (external/imported supers are
        # dropped — this loader is not a faithful OWL round-trip, see docstring).
        for child, parents in subclass_of.items():
            if child not in nodes:
                continue
            resolved = [p for p in parents if p in nodes]
            if resolved:
                nodes[child]["broader"] = resolved

        return cls.from_dict(
            {
                "name": ontology_name or default_name,
                "package_id": package_id or default_name,
                "version": ontology_version,
                "description": ontology_description,
                "namespace": ontology_namespace,
                "nodes": nodes,
                "relationships": relationships,
            }
        )


    @classmethod
    def from_artifact(
        cls,
        artifact: Any,
        *,
        version: str = "1.0.0",
        graph_model: str = "lpg",
    ) -> "Ontology":
        """Build an Ontology from a semantic artifact or draft input.

        Accepts a :class:`~seocho.semantic.SemanticArtifact`,
        :class:`~seocho.semantic.SemanticArtifactDraftInput`, or a plain
        dict with ``ontology_candidate`` and ``shacl_candidate`` keys.

        This is the reverse of :meth:`to_semantic_artifact_draft` — it
        promotes an approved (or draft) artifact into a full Ontology
        instance that can be used for extraction and querying.

        Args:
            artifact: Artifact object or dict.
            version: Ontology version string (overrides artifact metadata).
            graph_model: ``'lpg'`` or ``'rdf'``.

        Returns:
            A new :class:`Ontology` instance.

        Example::

            approved = seocho.get_artifact("art_abc123")
            onto = Ontology.from_artifact(approved, version="2.0")
            seocho.register_ontology("mydb", onto)
        """
        _DATATYPE_MAP: Dict[str, PropertyType] = {
            "string": PropertyType.STRING,
            "integer": PropertyType.INTEGER,
            "float": PropertyType.FLOAT,
            "number": PropertyType.FLOAT,
            "boolean": PropertyType.BOOLEAN,
            "datetime": PropertyType.DATETIME,
            "date": PropertyType.DATE,
            "point": PropertyType.POINT,
            "list": PropertyType.LIST,
        }

        # Normalize to dict if needed
        if hasattr(artifact, "to_dict"):
            data = artifact.to_dict()
        elif isinstance(artifact, dict):
            data = artifact
        else:
            raise TypeError(
                f"Expected SemanticArtifact, SemanticArtifactDraftInput, or dict; "
                f"got {type(artifact).__name__}"
            )

        onto_cand = data.get("ontology_candidate", {})
        if hasattr(onto_cand, "to_dict"):
            onto_cand = onto_cand.to_dict()

        shacl_cand = data.get("shacl_candidate", {})
        if hasattr(shacl_cand, "to_dict"):
            shacl_cand = shacl_cand.to_dict()

        ontology_name = str(onto_cand.get("ontology_name", "")).strip() or "Unnamed"

        # Extract SHACL constraints for enrichment
        shacl_required: Dict[str, set] = {}  # label -> set of required property names
        shacl_unique: Dict[str, set] = {}
        for shape in shacl_cand.get("shapes", []):
            tc = str(shape.get("target_class", "")).strip()
            if not tc:
                continue
            for constraint in shape.get("constraints", []):
                path = str(constraint.get("path", "")).strip()
                ctype = str(constraint.get("constraint", "")).strip()
                if ctype == "minCount" and constraint.get("params", {}).get("value", 0) >= 1:
                    shacl_required.setdefault(tc, set()).add(path)
                elif ctype == "uniqueLang":
                    shacl_unique.setdefault(tc, set()).add(path)

        # Build NodeDefs from ontology_candidate classes
        nodes: Dict[str, NodeDef] = {}
        for cls_data in onto_cand.get("classes", []):
            if isinstance(cls_data, dict):
                label = str(cls_data.get("name", "")).strip()
            else:
                label = str(getattr(cls_data, "name", "")).strip()
                cls_data = cls_data.to_dict() if hasattr(cls_data, "to_dict") else {}
            if not label:
                continue

            props: Dict[str, P] = {}
            req_props = shacl_required.get(label, set())
            for prop_data in cls_data.get("properties", []):
                if isinstance(prop_data, dict):
                    pname = str(prop_data.get("name", "")).strip()
                    datatype_str = str(prop_data.get("datatype", "string")).strip().lower()
                    pdesc = str(prop_data.get("description", "")).strip()
                    paliases = prop_data.get("aliases", [])
                else:
                    pname = str(getattr(prop_data, "name", "")).strip()
                    datatype_str = str(getattr(prop_data, "datatype", "string")).strip().lower()
                    pdesc = str(getattr(prop_data, "description", "")).strip()
                    paliases = getattr(prop_data, "aliases", [])
                if not pname:
                    continue
                ptype = _DATATYPE_MAP.get(datatype_str, PropertyType.STRING)
                props[pname] = P(
                    type=ptype,
                    required=pname in req_props,
                    description=pdesc,
                    aliases=list(paliases) if paliases else [],
                )

            nodes[label] = NodeDef(
                description=str(cls_data.get("description", "")).strip(),
                properties=props,
                aliases=list(cls_data.get("aliases", [])),
                broader=list(cls_data.get("broader", [])),
            )

        # Build RelDefs from ontology_candidate relationships
        rels: Dict[str, RelDef] = {}
        for rel_data in onto_cand.get("relationships", []):
            if isinstance(rel_data, dict):
                rtype = str(rel_data.get("type", "")).strip()
                source = str(rel_data.get("source", "Any")).strip() or "Any"
                target = str(rel_data.get("target", "Any")).strip() or "Any"
                rdesc = str(rel_data.get("description", "")).strip()
                raliases = rel_data.get("aliases", [])
            else:
                rtype = str(getattr(rel_data, "type", "")).strip()
                source = str(getattr(rel_data, "source", "Any")).strip() or "Any"
                target = str(getattr(rel_data, "target", "Any")).strip() or "Any"
                rdesc = str(getattr(rel_data, "description", "")).strip()
                raliases = getattr(rel_data, "aliases", [])
            if not rtype:
                continue
            rels[rtype] = RelDef(
                source=source,
                target=target,
                description=rdesc,
                aliases=list(raliases) if raliases else [],
            )

        # Extract metadata from source_summary if present
        source_summary = data.get("source_summary", {})
        resolved_version = (
            version
            or str(source_summary.get("version", "")).strip()
            or "1.0.0"
        )
        package_id = (
            str(source_summary.get("package_id", "")).strip()
            or ontology_name
        )
        namespace = str(source_summary.get("namespace", "")).strip()
        resolved_graph_model = (
            graph_model
            or str(source_summary.get("graph_model", "")).strip()
            or "lpg"
        )

        return cls(
            name=ontology_name,
            package_id=package_id,
            version=resolved_version,
            graph_model=resolved_graph_model,
            namespace=namespace,
            nodes=nodes,
            relationships=rels,
        )

    def to_jsonld(self, path: Optional[Union[str, Path]] = None) -> Dict[str, Any]:
        """Export ontology as a JSON-LD document.

        If *path* is given the document is also written to disk.  The
        dict is always returned.

        This is the **canonical** persistence format for SEOCHO
        ontologies.
        """
        from .serialization import ontology_to_jsonld

        return ontology_to_jsonld(self, path)

    # ------------------------------------------------------------------
    # SHACL — derived validation shapes
    # ------------------------------------------------------------------

    _XSD_MAP: Dict[str, str] = {
        "STRING": "xsd:string",
        "INTEGER": "xsd:integer",
        "FLOAT": "xsd:float",
        "BOOLEAN": "xsd:boolean",
        "DATETIME": "xsd:dateTime",
        "DATE": "xsd:date",
    }

    def to_shacl(self) -> Dict[str, Any]:
        """Derive SHACL shapes from the ontology definition.

        Returns a JSON-LD-style dict that describes one
        ``sh:NodeShape`` per node type and one ``sh:PropertyShape`` per
        property with constraints.

        The shapes can be used for:

        - Post-extraction validation (does the extracted data conform?)
        - DozerDB constraint generation (via ``to_cypher_constraints()``)
        - Human review (readable constraint summary)

        The returned dict is structured as::

            {
              "@context": { ... },
              "shapes": [
                {
                  "@type": "sh:NodeShape",
                  "targetClass": "seocho:Company",
                  "properties": [
                    {
                      "path": "seocho:name",
                      "datatype": "xsd:string",
                      "minCount": 1,
                      "maxCount": 1,
                      "unique": true
                    }
                  ]
                }
              ]
            }
        """
        shapes: List[Dict[str, Any]] = []

        for label, nd in self.nodes.items():
            prop_shapes: List[Dict[str, Any]] = []
            for pname, p in nd.properties.items():
                ps: Dict[str, Any] = {
                    "path": f"seocho:{pname}",
                }
                xsd = self._XSD_MAP.get(p.property_type.value)
                if xsd:
                    ps["datatype"] = xsd
                if p.unique:
                    ps["minCount"] = 1
                    ps["maxCount"] = 1
                    ps["unique"] = True
                    ps["message"] = f"Every {label} must have exactly one {pname}."
                elif p.required:
                    ps["minCount"] = 1
                    ps["message"] = f"Every {label} must have a {pname}."
                if p.enum is not None:
                    ps["in"] = list(p.enum)
                if p.value_range is not None:
                    ps["minInclusive"] = p.value_range[0]
                    ps["maxInclusive"] = p.value_range[1]
                if p.description:
                    ps["description"] = p.description
                prop_shapes.append(ps)

            shape: Dict[str, Any] = {
                "@type": "sh:NodeShape",
                "targetClass": f"seocho:{label}",
            }
            if nd.description:
                shape["description"] = nd.description
            if prop_shapes:
                shape["properties"] = prop_shapes
            shapes.append(shape)

        # Relationship cardinality as property shapes on the source node
        for rtype, rd in self.relationships.items():
            if rd.cardinality in ("ONE_TO_ONE", "MANY_TO_ONE"):
                # The source node should have at most one of this rel
                rel_shape: Dict[str, Any] = {
                    "path": f"seocho:{rtype}",
                    "maxCount": 1,
                    "description": f"{rd.source} -[:{rtype}]-> {rd.target} ({rd.cardinality})",
                    "message": f"A {rd.source} may have at most one {rtype} ({rd.target}).",
                }
                # Find or create the source shape
                for s in shapes:
                    if s.get("targetClass") == f"seocho:{rd.source}":
                        s.setdefault("properties", []).append(rel_shape)
                        break

        return {
            "@context": dict(self.JSONLD_CONTEXT),
            "@type": "seocho:ShaclDocument",
            "shapes": shapes,
        }

    def to_ontology_candidate(self) -> Any:
        """Convert this ontology into the typed runtime ontology artifact."""
        from .artifacts import ontology_to_ontology_candidate

        return ontology_to_ontology_candidate(self)

    def to_shacl_candidate(self) -> Any:
        """Convert derived SHACL output into the typed runtime artifact shape."""
        from .artifacts import ontology_to_shacl_candidate

        return ontology_to_shacl_candidate(self)

    def to_vocabulary_candidate(self, *, include_properties: bool = True) -> Any:
        """Convert ontology labels and aliases into a lightweight vocabulary."""
        from .artifacts import ontology_to_vocabulary_candidate

        return ontology_to_vocabulary_candidate(self, include_properties=include_properties)

    def to_approved_artifacts(
        self,
        *,
        include_vocabulary: bool = True,
        include_property_terms: bool = True,
    ) -> Any:
        """Build an ``ApprovedArtifacts`` payload from this ontology."""
        from .artifacts import ontology_to_approved_artifacts

        return ontology_to_approved_artifacts(
            self,
            include_vocabulary=include_vocabulary,
            include_property_terms=include_property_terms,
        )

    def to_semantic_prompt_context(
        self,
        *,
        instructions: Optional[Sequence[str]] = None,
        include_vocabulary: bool = True,
        include_property_terms: bool = True,
    ) -> Any:
        """Build a typed semantic prompt context from this ontology."""
        from .artifacts import ontology_to_semantic_prompt_context

        return ontology_to_semantic_prompt_context(
            self,
            instructions=instructions,
            include_vocabulary=include_vocabulary,
            include_property_terms=include_property_terms,
        )

    def to_semantic_artifact_draft(
        self,
        *,
        name: Optional[str] = None,
        include_vocabulary: bool = True,
        include_property_terms: bool = True,
        source_summary: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Build a draft semantic artifact payload from this ontology."""
        from .artifacts import ontology_to_semantic_artifact_draft

        return ontology_to_semantic_artifact_draft(
            self,
            name=name,
            include_vocabulary=include_vocabulary,
            include_property_terms=include_property_terms,
            source_summary=source_summary,
        )

    def validate_with_shacl(self, data: Dict[str, Any], *, closed: bool = False) -> List[str]:
        """Validate extracted data against SHACL shapes derived from
        this ontology.

        This combines :meth:`validate_extraction` with SHACL-level
        checks (datatype validation, cardinality).

        Parameters
        ----------
        data:
            Dict with ``"nodes"`` and ``"relationships"`` lists.
        closed:
            Forwarded to :meth:`validate_extraction` — closed-vocabulary
            admission (no ``Entity`` exemption, endpoint checks).

        Returns
        -------
        List of validation error strings (empty = valid).
        """
        errors = list(self.validate_extraction(data, closed=closed))
        shacl = self.to_shacl()

        # Build shape lookup: targetClass -> shape
        shape_map: Dict[str, Dict[str, Any]] = {}
        for shape in shacl.get("shapes", []):
            tc = shape.get("targetClass", "")
            if tc.startswith("seocho:"):
                shape_map[tc[len("seocho:"):]] = shape

        for node in data.get("nodes", []):
            nid = node.get("id", "")
            label = node.get("label", "")
            shape = shape_map.get(label)
            if shape is None:
                continue
            props = node.get("properties", {})
            for ps in shape.get("properties", []):
                path = ps.get("path", "")
                if path.startswith("seocho:"):
                    pname = path[len("seocho:"):]
                else:
                    continue
                # skip relationship paths
                if pname in self.relationships:
                    continue

                value = props.get(pname)
                min_count = ps.get("minCount", 0)
                if min_count >= 1 and (value is None or value == ""):
                    # already reported by validate_extraction, skip dup
                    continue

                # datatype check
                expected_xsd = ps.get("datatype")
                if expected_xsd and value is not None and value != "":
                    if expected_xsd == "xsd:integer" and not isinstance(value, int):
                        try:
                            int(value)
                        except (ValueError, TypeError):
                            errors.append(
                                f"Node '{nid}' ({label}).{pname}: "
                                f"expected integer, got {type(value).__name__}"
                            )
                    elif expected_xsd == "xsd:float" and not isinstance(value, (int, float)):
                        try:
                            float(value)
                        except (ValueError, TypeError):
                            errors.append(
                                f"Node '{nid}' ({label}).{pname}: "
                                f"expected float, got {type(value).__name__}"
                            )
                    elif expected_xsd == "xsd:boolean" and not isinstance(value, bool):
                        errors.append(
                            f"Node '{nid}' ({label}).{pname}: "
                            f"expected boolean, got {type(value).__name__}"
                        )

                # enum (sh:in) — the declared allowed value set. Without this,
                # a vocabulary could be declared and was never enforced: the
                # only channel that controlled extracted values was prose in
                # the prompt.
                allowed = ps.get("in")
                if allowed is not None and value is not None and value != "":
                    if value not in allowed:
                        errors.append(
                            f"Node '{nid}' ({label}).{pname}: value {value!r} "
                            f"not in allowed set {allowed}"
                        )

                # range (sh:minInclusive / sh:maxInclusive)
                if ("minInclusive" in ps or "maxInclusive" in ps) and value is not None and value != "":
                    try:
                        numeric = float(value)
                    except (ValueError, TypeError):
                        errors.append(
                            f"Node '{nid}' ({label}).{pname}: "
                            f"non-numeric value {value!r} for a ranged property"
                        )
                    else:
                        lo = ps.get("minInclusive")
                        hi = ps.get("maxInclusive")
                        if (lo is not None and numeric < lo) or (hi is not None and numeric > hi):
                            errors.append(
                                f"Node '{nid}' ({label}).{pname}: value {value!r} "
                                f"out of range [{lo}, {hi}]"
                            )

        # Relationship cardinality check
        source_rel_counts: Dict[str, Dict[str, int]] = {}  # node_id -> {rel_type -> count}
        for rel in data.get("relationships", []):
            src = rel.get("source", "")
            rtype = rel.get("type", "")
            source_rel_counts.setdefault(src, {})
            source_rel_counts[src][rtype] = source_rel_counts[src].get(rtype, 0) + 1

        for rtype, rd in self.relationships.items():
            if rd.cardinality in ("ONE_TO_ONE", "MANY_TO_ONE"):
                for node in data.get("nodes", []):
                    nid = node.get("id", "")
                    label = node.get("label", "")
                    if label == rd.source:
                        count = source_rel_counts.get(nid, {}).get(rtype, 0)
                        if count > 1:
                            errors.append(
                                f"Node '{nid}' ({label}) has {count} "
                                f"[:{rtype}] relationships but cardinality "
                                f"is {rd.cardinality} (max 1)"
                            )

        return errors

    # ------------------------------------------------------------------
    # Normalization / Denormalization — SHACL-guided graph transforms
    # ------------------------------------------------------------------

    def denormalization_plan(self) -> Dict[str, Any]:
        """Compute a SHACL-guided denormalization plan.

        Uses relationship cardinality to determine which target-node
        properties can be **safely embedded** into source nodes.

        Rules:

        - ``MANY_TO_ONE`` → embed target props into source (safe: at most 1 target)
        - ``ONE_TO_ONE``  → embed in both directions
        - ``ONE_TO_MANY`` → embed source props into each target
        - ``MANY_TO_MANY`` → **never embed** (must traverse)

        Returns
        -------
        Dict keyed by source node label::

            {
              "Person": {
                "embeds": [
                  {
                    "via": "CEO_OF",
                    "target": "Company",
                    "direction": "outgoing",
                    "cardinality": "MANY_TO_ONE",
                    "safe": True,
                    "fields": {"company_name": "name", "company_ticker": "ticker"},
                  }
                ]
              }
            }
        """
        plan: Dict[str, Any] = {}

        for rtype, rd in self.relationships.items():
            entries = self._denorm_entries_for(rtype, rd)
            for entry in entries:
                src_label = entry.pop("_source_label")
                plan.setdefault(src_label, {"embeds": []})
                plan[src_label]["embeds"].append(entry)

        return plan

    def _denorm_entries_for(
        self, rtype: str, rd: RelDef,
    ) -> List[Dict[str, Any]]:
        """Produce denorm entries for one relationship definition."""
        entries: List[Dict[str, Any]] = []

        # Self-referential relationships are never safe to embed —
        # they create ambiguous field names (e.g. person_name from which person?)
        if rd.source == rd.target:
            entries.append({
                "_source_label": rd.source,
                "via": rtype,
                "target": rd.target,
                "direction": "outgoing",
                "cardinality": rd.cardinality,
                "safe": False,
                "fields": {},
                "reason": f"Self-referential ({rd.source}->{rd.target}) — cannot embed",
            })
            return entries

        safe_outgoing = rd.cardinality in ("MANY_TO_ONE", "ONE_TO_ONE")
        safe_incoming = rd.cardinality in ("ONE_TO_MANY", "ONE_TO_ONE")

        if safe_outgoing and rd.target in self.nodes:
            target_nd = self.nodes[rd.target]
            prefix = rd.target.lower()
            field_map = {
                f"{prefix}_{pname}": pname
                for pname in target_nd.properties
            }
            entries.append({
                "_source_label": rd.source,
                "via": rtype,
                "target": rd.target,
                "direction": "outgoing",
                "cardinality": rd.cardinality,
                "safe": True,
                "fields": field_map,
            })

        if safe_incoming and rd.source in self.nodes:
            source_nd = self.nodes[rd.source]
            prefix = rd.source.lower()
            field_map = {
                f"{prefix}_{pname}": pname
                for pname in source_nd.properties
            }
            entries.append({
                "_source_label": rd.target,
                "via": rtype,
                "target": rd.source,
                "direction": "incoming",
                "cardinality": rd.cardinality,
                "safe": True,
                "fields": field_map,
            })

        if rd.cardinality == "MANY_TO_MANY":
            entries.append({
                "_source_label": rd.source,
                "via": rtype,
                "target": rd.target,
                "direction": "outgoing",
                "cardinality": rd.cardinality,
                "safe": False,
                "fields": {},
                "reason": "MANY_TO_MANY — must traverse, cannot embed",
            })

        return entries

    def to_denormalized_view(
        self,
        nodes: Sequence[Dict[str, Any]],
        relationships: Sequence[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """Produce denormalized node views by embedding related properties.

        Takes the normalized graph data (as returned by extraction) and
        produces flattened node dicts where safe-to-embed relationship
        targets have their properties inlined.

        This is useful for:

        - Building flat context for LLM answer synthesis
        - Vector-store document creation (richer per-node text)
        - Export to tabular formats

        Parameters
        ----------
        nodes:
            List of ``{"id", "label", "properties": {...}}`` dicts.
        relationships:
            List of ``{"source", "target", "type", "properties": {...}}``
            dicts.

        Returns
        -------
        List of denormalized node dicts with embedded fields.
        """
        plan = self.denormalization_plan()

        # Build lookup: node_id -> node dict
        node_map: Dict[str, Dict[str, Any]] = {}
        for n in nodes:
            node_map[n.get("id", "")] = n

        # Build adjacency: (source_id, rel_type) -> [target_id, ...]
        outgoing: Dict[str, Dict[str, List[str]]] = {}  # src -> {rtype -> [tgt]}
        incoming: Dict[str, Dict[str, List[str]]] = {}  # tgt -> {rtype -> [src]}
        for rel in relationships:
            src = rel.get("source", "")
            tgt = rel.get("target", "")
            rtype = rel.get("type", "")
            outgoing.setdefault(src, {}).setdefault(rtype, []).append(tgt)
            incoming.setdefault(tgt, {}).setdefault(rtype, []).append(src)

        result: List[Dict[str, Any]] = []
        for n in nodes:
            nid = n.get("id", "")
            label = n.get("label", "")
            props = dict(n.get("properties", {}))

            denorm_entry: Dict[str, Any] = {
                "id": nid,
                "label": label,
                "properties": dict(props),
                "_embedded": {},
            }

            label_plan = plan.get(label, {})
            for embed in label_plan.get("embeds", []):
                if not embed.get("safe", False):
                    continue

                rtype = embed["via"]
                direction = embed["direction"]
                field_map = embed["fields"]

                # Find the related node(s) — should be exactly 0 or 1
                if direction == "outgoing":
                    related_ids = outgoing.get(nid, {}).get(rtype, [])
                else:
                    related_ids = incoming.get(nid, {}).get(rtype, [])

                if not related_ids:
                    continue

                # Take the first (cardinality guarantees at most 1)
                related_node = node_map.get(related_ids[0])
                if related_node is None:
                    continue

                related_props = related_node.get("properties", {})
                embedded: Dict[str, Any] = {}
                for embed_key, source_key in field_map.items():
                    if source_key in related_props:
                        denorm_entry["properties"][embed_key] = related_props[source_key]
                        embedded[embed_key] = related_props[source_key]

                if embedded:
                    denorm_entry["_embedded"][rtype] = {
                        "from": related_ids[0],
                        "fields": embedded,
                    }

            result.append(denorm_entry)

        return result

    def normalize_view(
        self,
        denormalized_nodes: Sequence[Dict[str, Any]],
    ) -> tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
        """Reverse a denormalized view back into normalized nodes + relationships.

        Strips embedded fields (those present in the denormalization
        plan) from node properties, restoring the canonical normalized
        form.

        Parameters
        ----------
        denormalized_nodes:
            Output of :meth:`to_denormalized_view`.

        Returns
        -------
        Tuple of ``(clean_nodes, inferred_relationships)`` where
        ``clean_nodes`` have embedded fields removed and
        ``inferred_relationships`` are reconstructed from the
        ``_embedded`` metadata.
        """
        plan = self.denormalization_plan()

        # Collect all embed field names per label
        embed_fields_by_label: Dict[str, set] = {}
        for label, label_plan in plan.items():
            fields: set = set()
            for embed in label_plan.get("embeds", []):
                if embed.get("safe", False):
                    fields.update(embed["fields"].keys())
            embed_fields_by_label[label] = fields

        clean_nodes: List[Dict[str, Any]] = []
        inferred_rels: List[Dict[str, Any]] = []

        for dn in denormalized_nodes:
            nid = dn.get("id", "")
            label = dn.get("label", "")
            props = dict(dn.get("properties", {}))
            embedded_meta = dn.get("_embedded", {})

            # Strip embedded fields
            strip = embed_fields_by_label.get(label, set())
            clean_props = {k: v for k, v in props.items() if k not in strip}

            clean_nodes.append({
                "id": nid,
                "label": label,
                "properties": clean_props,
            })

            # Reconstruct relationships from _embedded metadata
            for rtype, meta in embedded_meta.items():
                related_id = meta.get("from", "")
                if related_id:
                    rd = self.relationships.get(rtype)
                    if rd is None:
                        continue
                    # Determine direction
                    label_plan = plan.get(label, {})
                    for embed in label_plan.get("embeds", []):
                        if embed["via"] == rtype:
                            if embed["direction"] == "outgoing":
                                inferred_rels.append({
                                    "source": nid,
                                    "target": related_id,
                                    "type": rtype,
                                    "properties": {},
                                })
                            else:
                                inferred_rels.append({
                                    "source": related_id,
                                    "target": nid,
                                    "type": rtype,
                                    "properties": {},
                                })
                            break

        # Deduplicate inferred relationships
        seen: set = set()
        unique_rels: List[Dict[str, Any]] = []
        for r in inferred_rels:
            key = (r["source"], r["type"], r["target"])
            if key not in seen:
                seen.add(key)
                unique_rels.append(r)

        return clean_nodes, unique_rels

    # ------------------------------------------------------------------
    # Prompt context generation (the key SDK feature)
    # ------------------------------------------------------------------

    def to_extraction_context(self) -> Dict[str, str]:
        """Build a context dict for **extraction/indexing** prompts.

        The returned dict is ready to be merged into a Jinja2 template
        context.  Keys:

        - ``ontology_name``
        - ``entity_types``  — human-readable list of node types + props
        - ``relationship_types`` — human-readable relationship listing
        - ``constraints_summary`` — property constraints for the LLM
        """
        return {
            "ontology_name": self.name,
            "entity_types": self._cached_render("entity_types", self._render_entity_types),
            "relationship_types": self._cached_render("relationship_types", self._render_relationship_types),
            "constraints_summary": self._cached_render("constraints_summary", self._render_constraints_summary),
        }

    def to_query_context(self) -> Dict[str, str]:
        """Build a context dict for **query-time** prompts.

        This is the key missing piece in the current codebase — the LLM
        generating Cypher (or answering questions) now receives full
        schema awareness including cardinality and constraints.

        Keys:

        - ``ontology_name``
        - ``graph_schema`` — full schema block for system prompt
        - ``node_types`` — concise node listing for quick reference
        - ``relationship_types`` — concise relationship listing
        - ``query_hints`` — constraint-derived hints (e.g. use exact
          match on UNIQUE properties)
        """
        return {
            "ontology_name": self.name,
            "ontology_profile": self._cached_render("ontology_profile", self._render_query_profile_summary),
            "graph_schema": self._cached_render("graph_schema", self._render_graph_schema),
            "node_types": self._cached_render("node_types", self._render_node_types_compact),
            "relationship_types": self._cached_render("rel_types_compact", self._render_relationship_types_compact),
            "query_hints": self._cached_render("query_hints", self._render_query_hints),
        }

    def to_query_profile(self) -> Dict[str, Any]:
        """Return structured ontology profile metadata for query planning."""
        deterministic_intents = [
            "entity_lookup",
            "relationship_lookup",
            "neighbors",
            "path",
            "count",
            "list_all",
        ]
        if self._supports_financial_metric_queries():
            deterministic_intents.extend(["financial_metric_lookup", "financial_metric_delta"])
        return {
            "ontology_name": self.name,
            "package_id": self.package_id,
            "version": self.version,
            "graph_model": self.graph_model,
            "version_valid": self.version_is_valid(),
            "schema_fingerprint": self.schema_fingerprint(),
            "node_labels": sorted(self.nodes.keys()),
            "relationship_types": sorted(self.relationships.keys()),
            "deterministic_intents": deterministic_intents,
        }

    def schema_fingerprint(self) -> str:
        """Stable schema hash used for ontology versioning and cache keys."""
        from .versioning import ontology_schema_fingerprint

        return ontology_schema_fingerprint(self)

    def version_is_valid(self) -> bool:
        """Return True when ``version`` follows semantic versioning."""
        from .versioning import is_valid_semver

        return is_valid_semver(self.version)

    def version_identity(self) -> Any:
        """Return version identity metadata for governance and runtime traces."""
        from .versioning import ontology_version_identity

        return ontology_version_identity(self)

    def upgrade_plan(self, next_ontology: "Ontology") -> Any:
        """Return indexing/query impact guidance for a proposed ontology update."""
        from .versioning import build_ontology_upgrade_plan

        return build_ontology_upgrade_plan(self, next_ontology)

    def to_linking_context(self) -> Dict[str, str]:
        """Build a context dict for **entity linking** prompts."""
        return {
            "ontology_name": self.name,
            "relationship_types": self._cached_render("relationship_types", self._render_relationship_types),
            "entity_types": self._cached_render("entity_types", self._render_entity_types),
        }

    # ------------------------------------------------------------------
    # Cypher constraint generation
    # ------------------------------------------------------------------

    def to_cypher_constraints(self, *, workspace_scoped: bool = False) -> List[str]:
        """Generate Cypher CREATE CONSTRAINT / CREATE INDEX statements."""
        stmts: List[str] = []
        for label, nd in self.nodes.items():
            # seocho-uxs: when a composite identity is declared, the identity
            # is the TUPLE — a per-property UNIQUE on a member (e.g. name)
            # would wrongly reject two distinct entities that share that
            # member (PTC's vs Tesla's "Total revenue"). Emit one composite
            # uniqueness constraint over the identity members instead, and
            # skip the per-member UNIQUE.
            identity = set(nd.identity_keys)
            if len(nd.identity_keys) == 1:
                # A single identity key IS the identity, so it takes a plain
                # UNIQUE. Previously the composite branch needed >1 key and the
                # per-property branch skipped anything in `identity`, so a class
                # with exactly one identity key got no constraint at all --
                # silently, and precisely for the property the writer dedupes on.
                (only,) = nd.identity_keys
                if only in nd.properties:
                    if workspace_scoped:
                        stmts.append(f"CREATE CONSTRAINT constraint_{label}_identity_workspace_unique IF NOT EXISTS FOR (n:{label}) REQUIRE (n._workspace_id, n.{only}) IS UNIQUE")
                    else:
                        stmts.append(f"CREATE CONSTRAINT constraint_{label}_identity_unique IF NOT EXISTS FOR (n:{label}) REQUIRE n.{only} IS UNIQUE")
            if len(nd.identity_keys) > 1:
                props = ", ".join(["n._workspace_id", *[f"n.{k}" for k in nd.identity_keys]]) if workspace_scoped else ", ".join(f"n.{k}" for k in nd.identity_keys)
                cname = f"constraint_{label}_identity_workspace_unique" if workspace_scoped else f"constraint_{label}_identity_unique"
                stmts.append(
                    f"CREATE CONSTRAINT {cname} IF NOT EXISTS "
                    f"FOR (n:{label}) REQUIRE ({props}) IS UNIQUE"
                )
            for pname, p in nd.properties.items():
                if p.unique and pname not in identity:
                    cname = f"constraint_{label}_{pname}_workspace_unique" if workspace_scoped else f"constraint_{label}_{pname}_unique"
                    props = f"(n._workspace_id, n.{pname})" if workspace_scoped else f"n.{pname}"
                    stmts.append(
                        f"CREATE CONSTRAINT {cname} IF NOT EXISTS "
                        f"FOR (n:{label}) REQUIRE {props} IS UNIQUE"
                    )
            for pname, p in nd.properties.items():
                if p.index and not p.unique:
                    iname = f"index_{label}_{pname}"
                    stmts.append(
                        f"CREATE INDEX {iname} IF NOT EXISTS "
                        f"FOR (n:{label}) ON (n.{pname})"
                    )

            # The three indexes below cover the properties the WRITE and READ
            # paths actually use, which were disjoint from the properties this
            # method indexed. Measured before adding them: the ontology indexed
            # whatever was declared `unique`/`index`; the writer MERGEs on `id`;
            # the retriever filters on the display property and `_workspace_id`.
            # Three disjoint sets, so no index served any predicate a correct
            # query would use — and a plan grader then reads that as "the LLM
            # writes unsargable Cypher" when the truth is "no index exists".

            # 1. The MERGE key. Every node write is `MERGE (n:L {id: ...})`, so
            #    without this each write is a label scan plus a property filter,
            #    and relationship writes do two. Ingest is quadratic.
            stmts.append(
                f"CREATE INDEX index_{label}_id IF NOT EXISTS "
                f"FOR (n:{label}) ON (n.id)"
            )

            # 2. Tenancy first, then the anchor. `_workspace_id` alone is the
            #    lowest-cardinality property in the store, so a seek on it
            #    returns most of the label; composite with the identity key it
            #    becomes O(this tenant's matching entities) instead of
            #    O(all tenants' data) on every query in the system.
            anchor = (nd.effective_identity_keys or [None])[0]
            if anchor:
                stmts.append(
                    f"CREATE INDEX index_{label}_workspace_{anchor} IF NOT EXISTS "
                    f"FOR (n:{label}) ON (n._workspace_id, n.{anchor})"
                )

        # 3. Entity-name resolution is a fuzzy substring match, which a RANGE
        #    index (what CREATE INDEX gives you) cannot serve. FULLTEXT is the
        #    only index type appropriate for it, and `graph_router.py` already
        #    calls db.index.fulltext.queryNodes against exactly this index name
        #    — nothing in the SDK created it, so that retrieval path failed and
        #    was swallowed by a bare except, degrading to a keyword heuristic
        #    with no signal.
        display_props = sorted({
            prop
            for nd in self.nodes.values()
            for prop in ((nd.effective_identity_keys or []) + ["name"])
            if prop in nd.properties or prop == "name"
        })
        if self.nodes and display_props:
            labels = "|".join(sorted(self.nodes))
            props = ", ".join(f"n.{p}" for p in display_props)
            stmts.append(
                f"CREATE FULLTEXT INDEX entity_fulltext IF NOT EXISTS "
                f"FOR (n:{labels}) ON EACH [{props}]"
            )

        return stmts

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def validate(self) -> List[str]:
        """Validate ontology consistency.  Returns a list of error strings
        (empty means valid)."""
        errors: List[str] = []
        for rtype, rd in self.relationships.items():
            if rd.source != "Any" and rd.source not in self.nodes:
                errors.append(f"Relationship '{rtype}' references unknown source '{rd.source}'")
            if rd.target != "Any" and rd.target not in self.nodes:
                errors.append(f"Relationship '{rtype}' references unknown target '{rd.target}'")
        for label, nd in self.nodes.items():
            if not nd.unique_properties:
                errors.append(f"Node '{label}' has no UNIQUE property — consider adding one")
            if not _LABEL_RE.match(label):
                errors.append(f"Node label '{label}' contains invalid characters")
        for rtype in self.relationships:
            if not _LABEL_RE.match(rtype):
                errors.append(f"Relationship type '{rtype}' contains invalid characters")
        # Subclass (broader) integrity: every parent must be a defined node, and
        # the broader graph must be acyclic. This keeps rdfs:subClassOf round-trips
        # and any constraint inheritance well-founded. (Author-time only; the lean
        # extraction projection never reads `broader`.)
        for label, nd in self.nodes.items():
            for parent in nd.broader:
                if parent not in self.nodes:
                    errors.append(
                        f"Node '{label}' broader references unknown node '{parent}'"
                    )
        for label in self.nodes:
            seen: Set[str] = set()
            stack = [label]
            while stack:
                cur = stack.pop()
                if cur == label and seen:
                    errors.append(f"Node '{label}' has a circular broader (subclass) chain")
                    break
                if cur in seen:
                    continue
                seen.add(cur)
                cur_nd = self.nodes.get(cur)
                if cur_nd is not None:
                    stack.extend(p for p in cur_nd.broader if p in self.nodes)
        return errors

    def validate_extraction(self, data: Dict[str, Any], *, closed: bool = False) -> List[str]:
        """Validate extracted graph data against this ontology.

        Parameters
        ----------
        data:
            Dict with ``"nodes"`` and ``"relationships"`` lists as
            produced by the LLM extraction step.
        closed:
            Closed-vocabulary admission (seocho-snt). When True:

            - the generic ``Entity`` label loses its exemption unless the
              ontology actually declares it,
            - relationship endpoints must reference extracted nodes
              (dangling-endpoint check), and
            - endpoint labels must conform to the relationship's declared
              source/target (``Any`` wildcard, exact match, or subsumption
              via the ``broader`` chain — author-time richness belongs in
              validation, never in extraction prompts).

        Returns
        -------
        List of validation error strings (empty = valid).
        """
        errors: List[str] = []
        known_ids: Set[str] = set()
        label_by_id: Dict[str, str] = {}

        for node in data.get("nodes", []):
            nid = node.get("id", "")
            label = node.get("label", "")
            known_ids.add(nid)
            label_by_id[nid] = label

            if label not in self.nodes and (closed or label != "Entity"):
                errors.append(f"Node '{nid}' has unknown label '{label}'")
                continue

            nd = self.nodes.get(label)
            if nd is None:
                continue
            props = node.get("properties", {})
            for req in nd.required_properties:
                if req not in props or not props[req]:
                    errors.append(f"Node '{nid}' ({label}) missing required property '{req}'")

        for rel in data.get("relationships", []):
            rtype = rel.get("type", "")
            src = rel.get("source", "")
            tgt = rel.get("target", "")
            if rtype not in self.relationships:
                errors.append(f"Unknown relationship type '{rtype}'")
                continue
            if not closed:
                continue
            rd = self.relationships[rtype]
            for endpoint, endpoint_id in (("source", src), ("target", tgt)):
                if endpoint_id not in known_ids:
                    errors.append(
                        f"Relationship [{rtype}] {endpoint} '{endpoint_id}' "
                        "does not reference an extracted node"
                    )
                    continue
                declared = rd.source if endpoint == "source" else rd.target
                actual = label_by_id.get(endpoint_id, "")
                if not self._label_conforms(actual, declared):
                    errors.append(
                        f"Relationship [{rtype}] {endpoint} '{endpoint_id}' has label "
                        f"'{actual}' but the ontology declares {endpoint} '{declared}'"
                    )

        return errors

    def _label_conforms(self, label: str, declared: str) -> bool:
        """True when ``label`` satisfies a declared endpoint class.

        Conformance = ``Any`` wildcard, exact match, or ``declared`` being
        reachable through ``label``'s transitive ``broader`` chain
        (subsumption).
        """
        if declared in ("", "Any") or label == declared:
            return True
        seen: Set[str] = set()
        frontier = [label]
        while frontier:
            current = frontier.pop()
            if current in seen:
                continue
            seen.add(current)
            nd = self.nodes.get(current)
            if nd is None:
                continue
            for parent in nd.broader or []:
                if parent == declared:
                    return True
                frontier.append(parent)
        return False

    def score_extraction(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Score the quality of extracted graph data against this ontology.

        Returns a dict with per-node scores, per-relationship scores,
        and an overall confidence score (0.0–1.0).

        Scoring criteria:

        - **Label match**: Is the node label in the ontology? (0 or 1)
        - **Property completeness**: How many required/unique properties
          are filled? (0.0–1.0)
        - **Type correctness**: Do filled properties match expected types?
        - **Relationship validity**: Is the rel type known? Are source/target
          labels correct?

        Parameters
        ----------
        data:
            Dict with ``"nodes"`` and ``"relationships"`` lists.

        Returns
        -------
        Dict with ``"nodes"``, ``"relationships"``, ``"overall"`` scores::

            {
              "overall": 0.85,
              "nodes": [
                {"id": "p1", "label": "Person", "score": 0.9, "details": {...}},
              ],
              "relationships": [
                {"source": "p1", "target": "c1", "type": "WORKS_AT", "score": 1.0},
              ],
            }
        """
        node_scores: List[Dict[str, Any]] = []
        rel_scores: List[Dict[str, Any]] = []

        for node in data.get("nodes", []):
            if not isinstance(node, dict):
                continue
            nid = node.get("id", "")
            label = node.get("label", "")
            props = node.get("properties", {})

            score_parts: Dict[str, float] = {}

            # Label match
            if label in self.nodes:
                score_parts["label_match"] = 1.0
                nd = self.nodes[label]

                # Property completeness
                required = nd.required_properties
                if required:
                    filled = sum(1 for r in required if r in props and props[r])
                    score_parts["property_completeness"] = filled / len(required)
                else:
                    score_parts["property_completeness"] = 1.0

                # Type correctness
                type_checks = 0
                type_correct = 0
                for pname, p in nd.properties.items():
                    if pname in props and props[pname] is not None:
                        type_checks += 1
                        val = props[pname]
                        if p.property_type.value == "INTEGER" and isinstance(val, (int, float)):
                            type_correct += 1
                        elif p.property_type.value == "FLOAT" and isinstance(val, (int, float)):
                            type_correct += 1
                        elif p.property_type.value == "BOOLEAN" and isinstance(val, bool):
                            type_correct += 1
                        elif p.property_type.value == "STRING" and isinstance(val, str):
                            type_correct += 1
                        elif p.property_type.value in ("DATETIME", "DATE") and isinstance(val, str):
                            type_correct += 1
                        elif p.property_type.value == "LIST" and isinstance(val, (list, tuple)):
                            type_correct += 1
                        elif p.property_type.value == "POINT" and isinstance(val, (dict, list, tuple)):
                            type_correct += 1
                        else:
                            # A genuine type mismatch scores 0. The old +0.5
                            # kept malformed extractions above quality_threshold
                            # and so silently disabled the indexing quality-retry
                            # gate. LIST and POINT are handled above because they
                            # fell into this same branch: a correctly typed list
                            # was docked half a point, which is the other half of
                            # the same bug.
                            type_correct += 0
                score_parts["type_correctness"] = (
                    type_correct / type_checks if type_checks > 0 else 1.0
                )
            elif label == "Entity":
                score_parts["label_match"] = 0.5
                score_parts["property_completeness"] = 0.5
                score_parts["type_correctness"] = 0.5
            else:
                score_parts["label_match"] = 0.0
                score_parts["property_completeness"] = 0.0
                score_parts["type_correctness"] = 0.0

            node_score = sum(score_parts.values()) / len(score_parts) if score_parts else 0.0
            node_scores.append({
                "id": nid,
                "label": label,
                "score": round(node_score, 3),
                "details": score_parts,
            })

        for rel in data.get("relationships", []):
            rtype = rel.get("type", "")
            src = rel.get("source", "")
            tgt = rel.get("target", "")

            if rtype in self.relationships:
                rel_score = 1.0
            else:
                rel_score = 0.0

            rel_scores.append({
                "source": src,
                "target": tgt,
                "type": rtype,
                "score": rel_score,
            })

        all_scores = [n["score"] for n in node_scores] + [r["score"] for r in rel_scores]
        overall = sum(all_scores) / len(all_scores) if all_scores else 0.0

        return {
            "overall": round(overall, 3),
            "nodes": node_scores,
            "relationships": rel_scores,
        }

    # ------------------------------------------------------------------
    # Label safety
    # ------------------------------------------------------------------

    def is_valid_label(self, label: str, *, allow_entity_fallback: bool = True) -> bool:
        if label in self._allowed_labels:
            return True
        return allow_entity_fallback and label == "Entity"

    def sanitize_label(self, label: str, *, allow_entity_fallback: bool = True) -> str:
        if self.is_valid_label(label, allow_entity_fallback=allow_entity_fallback):
            return label
        if allow_entity_fallback:
            return "Entity"
        raise ValueError(
            f"Label '{label}' is not declared by ontology '{self.name}' "
            "and Entity fallback is disabled (strict enforcement)."
        )

    # ------------------------------------------------------------------
    # Render cache — avoids recomputing identical string outputs
    # ------------------------------------------------------------------

    def _cached_render(self, key: str, fn: Any) -> str:
        """Return a cached render result, computing it on first access."""
        if not hasattr(self, "_render_cache"):
            object.__setattr__(self, "_render_cache", {})
        cache = self._render_cache  # type: ignore[attr-defined]
        if key not in cache:
            cache[key] = fn()
        return cache[key]

    def invalidate_render_cache(self) -> None:
        """Clear all cached render outputs.

        Call this after programmatically mutating nodes or relationships
        on an existing Ontology instance (rare — ontologies are normally
        immutable after construction).
        """
        if hasattr(self, "_render_cache"):
            self._render_cache.clear()  # type: ignore[attr-defined]

    # ------------------------------------------------------------------
    # Private renderers — extraction
    # ------------------------------------------------------------------

    def _render_entity_types(self) -> str:
        lines: List[str] = []
        for label, nd in self.nodes.items():
            parts: List[str] = []
            for pname, p in nd.properties.items():
                tag = f"{pname}[{p.constraint.value}]" if p.constraint else pname
                parts.append(tag)
            props_str = ", ".join(parts) if parts else "none"
            desc = nd.description or label
            alias_str = f" (aliases: {', '.join(nd.aliases)})" if nd.aliases else ""
            lines.append(f"- {label}: {desc}{alias_str} (properties: {props_str})")
        return "\n".join(lines)

    def _render_relationship_types(self) -> str:
        lines: List[str] = []
        for rtype, rd in self.relationships.items():
            desc = rd.description or rtype
            card = rd.cardinality.replace("_", "-").lower()
            alias_str = f" (aliases: {', '.join(rd.aliases)})" if rd.aliases else ""
            lines.append(f"- {rtype}: {rd.source} -> {rd.target} [{card}] ({desc}){alias_str}")
        return "\n".join(lines)

    def _render_constraints_summary(self) -> str:
        lines: List[str] = []
        for label, nd in self.nodes.items():
            for pname, p in nd.properties.items():
                if p.constraint:
                    lines.append(f"- {label}.{pname}: {p.constraint.value}")
                if p.property_type != PropertyType.STRING:
                    lines.append(f"- {label}.{pname}: datatype={p.property_type.value}")
                # A declared vocabulary that never reaches the extractor is a
                # constraint the model cannot honour: it can only be rejected
                # after the fact, for a rule it was never told. ADR-0181's own
                # finding was that what has a declarative home in the prompt is
                # obeyed (Step.position, 175/175) and what does not is invented
                # (Decision.status, 8 values across 51 documents) -- so the enum
                # has to be rendered, not only validated.
                if p.enum:
                    allowed = ", ".join(str(v) for v in p.enum)
                    lines.append(
                        f"- {label}.{pname}: MUST be exactly one of [{allowed}]"
                    )
                if p.value_range:
                    low, high = p.value_range
                    lines.append(
                        f"- {label}.{pname}: numeric, between {low} and {high} inclusive"
                    )
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Private renderers — query
    # ------------------------------------------------------------------

    def _render_graph_schema(self) -> str:
        """Full schema block for query-time system prompts."""
        sections: List[str] = []

        sections.append(f'Ontology: "{self.name}"')
        if self.description:
            sections.append(f"Description: {self.description}")
        sections.append("")

        # Nodes
        sections.append("Node types:")
        for label, nd in self.nodes.items():
            desc = f" — {nd.description}" if nd.description else ""
            sections.append(f"  ({label}){desc}")
            for pname, p in nd.properties.items():
                dtype = p.property_type.value
                flags: List[str] = []
                if p.unique:
                    flags.append("UNIQUE")
                if p.required:
                    flags.append("REQUIRED")
                if p.index:
                    flags.append("INDEXED")
                flag_str = f" [{', '.join(flags)}]" if flags else ""
                sections.append(f"    .{pname}: {dtype}{flag_str}")
        sections.append("")

        # Relationships
        sections.append("Relationship types:")
        for rtype, rd in self.relationships.items():
            card = rd.cardinality.replace("_", "-").lower()
            desc = f" — {rd.description}" if rd.description else ""
            sections.append(f"  [:{rtype}] ({rd.source})->({rd.target}) [{card}]{desc}")
            for pname, p in rd.properties.items():
                sections.append(f"    .{pname}: {p.property_type.value}")

        return "\n".join(sections)

    def _render_node_types_compact(self) -> str:
        return ", ".join(self.nodes.keys())

    def _render_relationship_types_compact(self) -> str:
        parts: List[str] = []
        for rtype, rd in self.relationships.items():
            parts.append(f"{rtype}({rd.source}->{rd.target})")
        return ", ".join(parts)

    def _render_query_hints(self) -> str:
        """Generate query-time hints derived from constraints."""
        hints: List[str] = []
        for label, nd in self.nodes.items():
            for pname, p in nd.properties.items():
                if p.unique:
                    hints.append(f"- {label}.{pname} is UNIQUE — use exact MATCH for lookups")
                if p.property_type in (PropertyType.INTEGER, PropertyType.FLOAT):
                    hints.append(f"- {label}.{pname} is numeric ({p.property_type.value}) — comparison operators are valid")
                if p.property_type in (PropertyType.DATETIME, PropertyType.DATE):
                    hints.append(f"- {label}.{pname} is temporal ({p.property_type.value}) — use datetime functions")
        for rtype, rd in self.relationships.items():
            if rd.cardinality == "ONE_TO_ONE":
                hints.append(f"- [{rtype}] is ONE-TO-ONE — expect at most 1 result per direction")
            elif rd.cardinality == "MANY_TO_ONE":
                hints.append(f"- [{rtype}] is MANY-TO-ONE — each {rd.source} has at most one {rd.target}")
        return "\n".join(hints)

    def _render_query_profile_summary(self) -> str:
        profile = self.to_query_profile()
        deterministic_intents = ", ".join(profile["deterministic_intents"])
        return (
            f"package_id={profile['package_id']}, "
            f"version={profile['version']}, "
            f"graph_model={profile['graph_model']}, "
            f"deterministic_intents=[{deterministic_intents}]"
        )

    def _supports_financial_metric_queries(self) -> bool:
        if "Company" not in self.nodes or "FinancialMetric" not in self.nodes:
            return False
        for rel in self.relationships.values():
            if rel.source == "Company" and rel.target == "FinancialMetric":
                return True
        return False

    # ------------------------------------------------------------------
    # Merge
    # ------------------------------------------------------------------

    def merge(
        self,
        other: "Ontology",
        *,
        strategy: str = "union",
        name: Optional[str] = None,
    ) -> "Ontology":
        """Merge another ontology into this one.

        Combines nodes, relationships, and their properties. When both
        ontologies define the same label or relationship type, the
        ``strategy`` determines how conflicts are resolved.

        Parameters
        ----------
        other:
            The ontology to merge in.
        strategy:
            Conflict resolution for overlapping definitions:
            - ``"union"`` — combine properties from both (default)
            - ``"left_wins"`` — keep this ontology's definition
            - ``"right_wins"`` — keep other ontology's definition
            - ``"strict"`` — raise on any conflict
        name:
            Name for the merged ontology (defaults to "left+right").

        Returns
        -------
        A new :class:`Ontology` containing definitions from both.

        Example::

            finance = Ontology.from_jsonld("finance.jsonld")
            legal = Ontology.from_jsonld("legal.jsonld")
            combined = finance.merge(legal)
            combined.to_jsonld("combined.jsonld")
        """
        merged_name = name or f"{self.name}+{other.name}"
        merged_nodes: Dict[str, NodeDef] = {}
        merged_rels: Dict[str, RelDef] = {}
        conflicts: List[str] = []

        # --- Merge nodes ---
        all_labels = set(self.nodes.keys()) | set(other.nodes.keys())
        for label in sorted(all_labels):
            left = self.nodes.get(label)
            right = other.nodes.get(label)

            if left and not right:
                merged_nodes[label] = left
            elif right and not left:
                merged_nodes[label] = right
            else:
                # Both define this label — apply strategy
                merged_nodes[label] = self._merge_node_def(
                    label, left, right, strategy, conflicts
                )

        # --- Merge relationships ---
        all_rels = set(self.relationships.keys()) | set(other.relationships.keys())
        for rtype in sorted(all_rels):
            left = self.relationships.get(rtype)
            right = other.relationships.get(rtype)

            if left and not right:
                merged_rels[rtype] = left
            elif right and not left:
                merged_rels[rtype] = right
            else:
                merged_rels[rtype] = self._merge_rel_def(
                    rtype, left, right, strategy, conflicts
                )

        if conflicts and strategy == "strict":
            raise ValueError(
                "Merge conflicts in strict mode:\n" +
                "\n".join(f"  - {c}" for c in conflicts)
            )

        return Ontology(
            name=merged_name,
            version=self.version,
            description=f"Merged: {self.name} + {other.name}",
            graph_model=self.graph_model,
            namespace=self.namespace or other.namespace,
            nodes=merged_nodes,
            relationships=merged_rels,
        )

    def subtract(self, other: "Ontology") -> "Ontology":
        """Return a copy of this ontology with everything declared in ``other`` removed.

        Removes:
        - any node label present in ``other.nodes``
        - any relationship type present in ``other.relationships``
        - any relationship whose ``source`` or ``target`` references a removed node

        Mirrors :meth:`merge` but in the opposite direction.

        Example::

            base       = Ontology.from_ttl("fibo_base.ttl")
            extension  = Ontology.from_ttl("fibo_fbc.ttl")
            restricted = Ontology.from_ttl("restricted.ttl")
            composed = base.merge(extension).subtract(restricted)
            # or use the operator form:
            composed = base + extension - restricted
        """
        from .serialization import ontology_subtract

        return ontology_subtract(self, other)

    def __add__(self, other: "Ontology") -> "Ontology":
        """``a + b`` is shorthand for ``a.merge(b)`` (union strategy)."""
        return self.merge(other)

    def __sub__(self, other: "Ontology") -> "Ontology":
        """``a - b`` is shorthand for ``a.subtract(b)``."""
        return self.subtract(other)

    @staticmethod
    def _merge_node_def(
        label: str,
        left: NodeDef,
        right: NodeDef,
        strategy: str,
        conflicts: List[str],
    ) -> NodeDef:
        if strategy == "left_wins":
            return left
        if strategy == "right_wins":
            return right

        # Union: combine properties
        merged_props = dict(left.properties)
        for pname, p in right.properties.items():
            if pname in merged_props:
                existing = merged_props[pname]
                if existing.property_type != p.property_type:
                    conflicts.append(
                        f"Node '{label}' property '{pname}': "
                        f"type {existing.property_type.value} vs {p.property_type.value}"
                    )
                    if strategy == "strict":
                        continue
                # Union: more restrictive wins
                merged_props[pname] = P(
                    type=existing.property_type,
                    index=existing.index or p.index,
                    required=existing.required or p.required,
                    unique=existing.unique or p.unique,
                    description=existing.description or p.description,
                    aliases=list(set(existing.aliases + p.aliases)),
                )
            else:
                merged_props[pname] = p

        return NodeDef(
            description=left.description or right.description,
            properties=merged_props,
            aliases=list(set(left.aliases + right.aliases)),
            broader=list(set(left.broader + right.broader)),
            same_as=left.same_as or right.same_as,
            # Identity is a contract, not a set union: keep the left side's
            # declared identity when present (deterministic order matters),
            # else adopt the right side's.
            identity_keys=list(left.identity_keys or right.identity_keys),
        )

    @staticmethod
    def _merge_rel_def(
        rtype: str,
        left: RelDef,
        right: RelDef,
        strategy: str,
        conflicts: List[str],
    ) -> RelDef:
        if strategy == "left_wins":
            return left
        if strategy == "right_wins":
            return right

        # Record every conflicting definition. merge() raises on the accumulated
        # list afterwards in strict mode, so returning early on the first one
        # meant a cardinality mismatch was never compared: two ontologies
        # declaring the same relationship ONE_TO_MANY and MANY_TO_MANY merged
        # silently to the left side's cardinality.
        if left.source != right.source or left.target != right.target:
            conflicts.append(
                f"Relationship '{rtype}': "
                f"{left.source}->{left.target} vs {right.source}->{right.target}"
            )
        if str(left.cardinality).strip().upper() != str(right.cardinality).strip().upper():
            conflicts.append(
                f"Relationship '{rtype}': cardinality "
                f"{left.cardinality} vs {right.cardinality}"
            )

        merged_props = dict(left.properties)
        merged_props.update(right.properties)

        return RelDef(
            source=left.source,
            target=left.target,
            description=left.description or right.description,
            cardinality=left.cardinality,
            properties=merged_props,
            aliases=list(set(left.aliases + right.aliases)),
            same_as=left.same_as or right.same_as,
        )

    # ------------------------------------------------------------------
    # Migration
    # ------------------------------------------------------------------

    def migration_plan(self, new_ontology: "Ontology", *, soft_delete: bool = True) -> Dict[str, Any]:
        """Compute a migration plan from this ontology to a new version.

        Returns Cypher statements needed to transform existing graph
        data to match the new ontology schema.

        Parameters
        ----------
        new_ontology:
            The target ontology to migrate to.
        soft_delete:
            When True (default, seocho-ia4.5) a removed label/relationship is
            **soft-deleted** (``SET ... _ontology_soft_deleted_at``, hidden from new
            reads) rather than destructively deleted — physical deletion becomes a
            later GC decision on a retention clock (gated by the RCU epoch, ia4.3),
            not a migration side effect. A removed property is kept (deprecated),
            not dropped. Pass ``soft_delete=False`` for the legacy destructive (hard-delete) plan.
            Every statement carries a ``data_loss`` flag.

        Returns
        -------
        Dict with ``renames``, ``additions``, ``removals``, and
        ``cypher_statements`` (ready to execute).

        Example::

            plan = old_onto.migration_plan(new_onto)
            print(plan["summary"])
            for stmt in plan["cypher_statements"]:
                graph_store.query(stmt["cypher"])  # dry_run first!
        """
        plan: Dict[str, Any] = {
            "from_version": self.version,
            "to_version": new_ontology.version,
            "renames": [],
            "additions": [],
            "removals": [],
            "cypher_statements": [],
            "breaking": False,
        }

        old_labels = set(self.nodes.keys())
        new_labels = set(new_ontology.nodes.keys())

        # Added node types
        for label in sorted(new_labels - old_labels):
            plan["additions"].append({"type": "node", "label": label})

        # Removed node types (breaking). Soft-delete (default) instead of destroy.
        _ts = new_ontology.version
        for label in sorted(old_labels - new_labels):
            plan["removals"].append({"type": "node", "label": label})
            plan["breaking"] = True
            if soft_delete:
                plan["cypher_statements"].append({
                    "description": f"Soft-delete :{label} nodes (removed in {_ts})",
                    "cypher": (f"MATCH (n:{label}) SET n._ontology_soft_deleted_at = '{_ts}', "
                               f"n._soft_delete_reason = 'label removed'"),
                    "breaking": True, "data_loss": False,
                })
            else:
                plan["cypher_statements"].append({
                    "description": f"Remove all :{label} nodes",
                    "cypher": f"MATCH (n:{label}) DETACH DELETE n",
                    "breaking": True, "data_loss": True,
                })

        # Changed node types (property changes)
        for label in sorted(old_labels & new_labels):
            old_props = set(self.nodes[label].properties.keys())
            new_props = set(new_ontology.nodes[label].properties.keys())

            for prop in sorted(new_props - old_props):
                plan["additions"].append({"type": "property", "label": label, "property": prop})

            for prop in sorted(old_props - new_props):
                plan["removals"].append({"type": "property", "label": label, "property": prop})
                if soft_delete:
                    # keep the data; mark the property deprecated (no data loss)
                    plan["cypher_statements"].append({
                        "description": f"Deprecate property {prop} on :{label} (kept)",
                        "cypher": (f"MATCH (n:{label}) WHERE n.`{prop}` IS NOT NULL "
                                   f"SET n.`_deprecated_{prop}` = true"),
                        "breaking": False, "data_loss": False,
                    })
                else:
                    plan["cypher_statements"].append({
                        "description": f"Remove property {prop} from :{label}",
                        "cypher": f"MATCH (n:{label}) REMOVE n.`{prop}`",
                        "breaking": False, "data_loss": True,
                    })

        # Relationship changes
        old_rels = set(self.relationships.keys())
        new_rels = set(new_ontology.relationships.keys())

        for rtype in sorted(new_rels - old_rels):
            plan["additions"].append({"type": "relationship", "relationship": rtype})

        for rtype in sorted(old_rels - new_rels):
            plan["removals"].append({"type": "relationship", "relationship": rtype})
            plan["breaking"] = True
            if soft_delete:
                plan["cypher_statements"].append({
                    "description": f"Soft-delete [{rtype}] relationships (removed in {_ts})",
                    "cypher": (f"MATCH ()-[r:{rtype}]->() SET r._ontology_soft_deleted_at = '{_ts}', "
                               f"r._soft_delete_reason = 'rel type removed'"),
                    "breaking": True, "data_loss": False,
                })
            else:
                plan["cypher_statements"].append({
                    "description": f"Remove all [{rtype}] relationships",
                    "cypher": f"MATCH ()-[r:{rtype}]->() DELETE r",
                    "breaking": True, "data_loss": True,
                })

        plan["summary"] = (
            f"Migration {self.version} → {new_ontology.version}: "
            f"{len(plan['additions'])} additions, "
            f"{len(plan['removals'])} removals, "
            f"{len(plan['cypher_statements'])} Cypher statements"
            + (" (BREAKING)" if plan["breaking"] else "")
        )

        return plan

    def apply_migration(
        self,
        graph_store: Any,
        new_ontology: "Ontology",
        *,
        database: str = "neo4j",
        dry_run: bool = False,
    ) -> Dict[str, Any]:
        """Compute and optionally execute a migration to *new_ontology*.

        Parameters
        ----------
        graph_store:
            A :class:`~seocho.store.graph.GraphStore` instance (must support
            ``execute_write``).
        new_ontology:
            The target ontology.
        database:
            Target database name.
        dry_run:
            If ``True``, return the plan without executing any statements.

        Returns
        -------
        Dict with ``plan`` (full migration plan), ``executed`` (list of
        executed statement results), and ``errors`` (list of failures).
        When *dry_run* is ``True``, ``executed`` is empty.
        """
        plan = self.migration_plan(new_ontology)
        result: Dict[str, Any] = {
            "plan": plan,
            "executed": [],
            "errors": [],
            "dry_run": dry_run,
        }

        if dry_run or not plan["cypher_statements"]:
            return result

        for stmt in plan["cypher_statements"]:
            cypher = stmt["cypher"]
            try:
                write_result = graph_store.execute_write(
                    cypher, database=database,
                )
                result["executed"].append({
                    "description": stmt["description"],
                    "cypher": cypher,
                    "result": write_result,
                })
            except Exception as exc:
                result["errors"].append({
                    "description": stmt["description"],
                    "cypher": cypher,
                    "error": str(exc),
                })

        return result

    def coverage_stats(
        self,
        graph_store: Any,
        *,
        database: str = "neo4j",
    ) -> Dict[str, Any]:
        """Compute ontology coverage statistics against a live graph.

        Queries the graph to count how many nodes exist for each ontology-
        defined label and how many relationships exist for each type.
        Returns a coverage summary highlighting unused or under-populated
        schema elements.

        Args:
            graph_store: A :class:`~seocho.store.graph.GraphStore` instance.
            database: Target database to analyze.

        Returns:
            Dict with ``node_coverage``, ``relationship_coverage``,
            ``overall_score``, and ``unused`` lists.

        Example::

            stats = onto.coverage_stats(store, database="mydb")
            print(stats["overall_score"])        # 0.75
            print(stats["unused"]["node_types"]) # ["OldEntity"]
        """
        node_stats: List[Dict[str, Any]] = []
        total_defined_nodes = len(self.nodes)
        populated_nodes = 0
        chunk_size = 50

        nodes_list = list(self.nodes)
        for i in range(0, len(nodes_list), chunk_size):
            chunk = nodes_list[i:i + chunk_size]
            query = " UNION ALL ".join([
                f"MATCH (n:`{label}`) RETURN count(n) AS cnt, '{label}' AS element"
                for label in chunk
            ])
            try:
                results = graph_store.query(query, database=database)
                counts = {r["element"]: int(r["cnt"]) for r in results}
            except Exception:
                counts = {}

            for label in chunk:
                if label in counts:
                    count = counts[label]
                else:
                    try:
                        result = graph_store.query(
                            f"MATCH (n:`{label}`) RETURN count(n) AS cnt",
                            database=database,
                        )
                        count = int(result[0]["cnt"]) if result else 0
                    except Exception:
                        count = 0

                node_stats.append({"label": label, "count": count})
                if count > 0:
                    populated_nodes += 1

        rel_stats: List[Dict[str, Any]] = []
        total_defined_rels = len(self.relationships)
        populated_rels = 0

        rels_list = list(self.relationships)
        for i in range(0, len(rels_list), chunk_size):
            chunk = rels_list[i:i + chunk_size]
            query = " UNION ALL ".join([
                f"MATCH ()-[r:`{rtype}`]->() RETURN count(r) AS cnt, '{rtype}' AS element"
                for rtype in chunk
            ])
            try:
                results = graph_store.query(query, database=database)
                counts = {r["element"]: int(r["cnt"]) for r in results}
            except Exception:
                counts = {}

            for rtype in chunk:
                if rtype in counts:
                    count = counts[rtype]
                else:
                    try:
                        result = graph_store.query(
                            f"MATCH ()-[r:`{rtype}`]->() RETURN count(r) AS cnt",
                            database=database,
                        )
                        count = int(result[0]["cnt"]) if result else 0
                    except Exception:
                        count = 0

                rel_stats.append({"type": rtype, "count": count})
                if count > 0:
                    populated_rels += 1

        node_score = populated_nodes / total_defined_nodes if total_defined_nodes else 1.0
        rel_score = populated_rels / total_defined_rels if total_defined_rels else 1.0
        overall = (node_score + rel_score) / 2.0

        unused_nodes = [s["label"] for s in node_stats if s["count"] == 0]
        unused_rels = [s["type"] for s in rel_stats if s["count"] == 0]

        return {
            "database": database,
            "ontology_name": self.name,
            "ontology_version": self.version,
            "node_coverage": {
                "defined": total_defined_nodes,
                "populated": populated_nodes,
                "score": round(node_score, 3),
                "details": node_stats,
            },
            "relationship_coverage": {
                "defined": total_defined_rels,
                "populated": populated_rels,
                "score": round(rel_score, 3),
                "details": rel_stats,
            },
            "overall_score": round(overall, 3),
            "unused": {
                "node_types": unused_nodes,
                "relationship_types": unused_rels,
            },
        }

    # ------------------------------------------------------------------
    # Dunder
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return (
            f"Ontology(name={self.name!r}, package_id={self.package_id!r}, version={self.version!r}, "
            f"nodes={len(self.nodes)}, relationships={len(self.relationships)})"
        )

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Ontology):
            return NotImplemented
        return self.to_dict() == other.to_dict()
