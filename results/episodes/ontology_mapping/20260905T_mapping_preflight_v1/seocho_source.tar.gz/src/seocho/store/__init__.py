"""
seocho.store — Storage backend abstractions.

Where to look:
- ``graph``: Neo4j/DozerDB graph store
  (write nodes/rels, query Cypher)
- ``vector``: FAISS / LanceDB vector similarity search
- ``llm``: OpenAI-compatible LLM and embedding backends
"""

from .graph import (
    EnsureConstraintsError,
    GraphStore,
    Neo4jGraphStore,
    WorkspaceFilterMissingError,
)
from .llm import (
    DeepSeekBackend,
    EmbeddingBackend,
    GrokBackend,
    KimiBackend,
    LLMBackend,
    LLMResponse,
    OpenAIBackend,
    OpenAICompatibleBackend,
    OpenAICompatibleEmbeddingBackend,
    ProviderSpec,
    QwenBackend,
    MaraBackend,
    VLLMBackend,
    create_embedding_backend,
    create_llm_backend,
    get_provider_spec,
    list_provider_specs,
)
from .vector import (
    FAISSVectorStore,
    LanceDBVectorStore,
    VectorSearchResult,
    VectorStore,
    create_vector_store,
)

__all__ = [
    "GraphStore",
    "Neo4jGraphStore",
    "ProviderSpec",
    "LLMBackend",
    "EmbeddingBackend",
    "LLMResponse",
    "OpenAICompatibleBackend",
    "OpenAICompatibleEmbeddingBackend",
    "OpenAIBackend",
    "DeepSeekBackend",
    "KimiBackend",
    "GrokBackend",
    "QwenBackend",
    "MaraBackend",
    "VLLMBackend",
    "get_provider_spec",
    "list_provider_specs",
    "create_llm_backend",
    "create_embedding_backend",
    "VectorStore",
    "FAISSVectorStore",
    "LanceDBVectorStore",
    "create_vector_store",
    "VectorSearchResult",
]
