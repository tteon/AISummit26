"""
Vector backends for semantic similarity search in the public SEOCHO SDK.

The vector database and the embedding provider are intentionally decoupled:
FAISS/LanceDB handle storage and nearest-neighbor search, while embeddings are
generated through an embedding backend.
"""

from __future__ import annotations

import json
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence

from .llm import create_embedding_backend

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class VectorSearchResult:
    """A single similarity search result.

    ``score`` is always a similarity where higher means a better match, regardless
    of backend: FAISS inner-product and LanceDB L2 distance are normalized to the
    same higher-is-better convention so scores are comparable across stores.
    ``metric`` records the score semantic for callers.
    """

    id: str
    text: str
    score: float
    metadata: Dict[str, Any] = field(default_factory=dict)
    metric: str = "similarity"


class VectorStore(ABC):
    """Abstract interface for vector similarity search."""

    @abstractmethod
    def add(
        self,
        doc_id: str,
        text: str,
        *,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Add a document to the vector index."""

    @abstractmethod
    def add_batch(self, items: Sequence[Dict[str, Any]]) -> int:
        """Add multiple documents and return the count."""

    @abstractmethod
    def search(self, query: str, *, limit: int = 5) -> List[VectorSearchResult]:
        """Find documents similar to query text."""

    @abstractmethod
    def delete(self, doc_id: str) -> bool:
        """Remove a document from the index."""

    def delete_by_source(self, source_id: str) -> int:
        """Delete every vector belonging to ``source_id`` and return the count.

        The indexing pipeline keys vectors by ``{source_id}_chunk_{ordinal}``,
        so deleting a source's vectors keeps the vector store consistent with
        the graph on delete_source/reindex (issue #123). Default is a no-op for
        custom stores that don't track source provenance; the built-in backends
        override it.
        """
        return 0

    @abstractmethod
    def count(self) -> int:
        """Return the number of active documents in the index."""


def _normalize_vectors(vectors: Any) -> Any:
    import numpy as np

    matrix = np.array(vectors, dtype=np.float32)
    norms = np.linalg.norm(matrix, axis=1, keepdims=True)
    norms[norms == 0] = 1
    return matrix / norms


class FAISSVectorStore(VectorStore):
    """In-memory vector store using FAISS plus a pluggable embedding backend."""

    def __init__(
        self,
        *,
        embedding_backend: Optional[Any] = None,
        embedding_provider: str = "openai",
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        model: str = "text-embedding-3-small",
        dimension: int = 1536,
    ) -> None:
        try:
            import faiss
        except ImportError as exc:
            raise ImportError(
                "FAISSVectorStore requires 'faiss-cpu'. "
                "Install it with: pip install faiss-cpu"
            ) from exc

        self._faiss = faiss
        self._embedding_backend = embedding_backend or create_embedding_backend(
            provider=embedding_provider,
            api_key=api_key,
            base_url=base_url,
            model=model,
        )
        self._model = model
        self._dimension = dimension
        self._index = faiss.IndexFlatIP(dimension)
        self._docs: List[Dict[str, Any]] = []
        self._id_to_idx: Dict[str, int] = {}
        # IndexFlatIP cannot remove a single vector, so delete() tombstones the
        # doc and search() over-fetches by this count to still return `limit`
        # live results (issue #122).
        self._tombstones = 0

    def _embed(self, texts: Sequence[str]) -> Any:
        return _normalize_vectors(self._embedding_backend.embed(texts, model=self._model))

    def _ensure_dimension(self, vectors: Any) -> None:
        """Validate embedding width against the index, adopting the first
        embedding's dimension when the index is still empty.

        Without this, an embedding model with a non-default width (e.g.
        text-embedding-3-large at 3072) reached faiss as a size mismatch and
        raised an opaque assertion in native code (issue #121).
        """
        width = int(vectors.shape[1])
        if self._index.ntotal == 0 and width != self._dimension:
            self._dimension = width
            self._index = self._faiss.IndexFlatIP(width)
        elif width != self._dimension:
            raise ValueError(
                f"Embedding dimension mismatch: this FAISSVectorStore holds "
                f"{self._dimension}-dim vectors but received {width}-dim. All "
                f"vectors in a store must come from one embedding model."
            )

    def add(
        self,
        doc_id: str,
        text: str,
        *,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        if doc_id in self._id_to_idx:
            self.delete(doc_id)

        vectors = self._embed([text])
        self._ensure_dimension(vectors)
        idx = len(self._docs)
        self._index.add(vectors)
        self._docs.append({"id": doc_id, "text": text, "metadata": metadata or {}})
        self._id_to_idx[doc_id] = idx

    def add_batch(self, items: Sequence[Dict[str, Any]]) -> int:
        if not items:
            return 0

        for item in items:
            doc_id = str(item["id"])
            if doc_id in self._id_to_idx:
                self.delete(doc_id)

        texts = [str(item["text"]) for item in items]
        vectors = self._embed(texts)
        self._ensure_dimension(vectors)
        start_idx = len(self._docs)
        self._index.add(vectors)

        for offset, item in enumerate(items):
            doc_id = str(item["id"])
            self._docs.append(
                {
                    "id": doc_id,
                    "text": str(item["text"]),
                    "metadata": dict(item.get("metadata", {})),
                }
            )
            self._id_to_idx[doc_id] = start_idx + offset

        return len(items)

    def search(self, query: str, *, limit: int = 5) -> List[VectorSearchResult]:
        if self._index.ntotal == 0:
            return []

        query_vec = self._embed([query])
        # Over-fetch by the tombstone count: deleted vectors still occupy
        # top-k slots, so fetching only `limit` could drop live results behind
        # them. Bounded by ntotal (issue #122).
        k = min(limit + self._tombstones, self._index.ntotal)
        scores, indices = self._index.search(query_vec, k)

        results: List[VectorSearchResult] = []
        for score, idx in zip(scores[0], indices[0]):
            if idx < 0 or idx >= len(self._docs):
                continue
            doc = self._docs[idx]
            if doc.get("_deleted"):
                continue
            results.append(
                VectorSearchResult(
                    id=str(doc["id"]),
                    text=str(doc["text"]),
                    score=float(score),  # inner product on normalized vectors: higher = better
                    metadata=dict(doc.get("metadata", {})),
                    metric="similarity",
                )
            )
            if len(results) >= limit:
                break

        return results

    def delete(self, doc_id: str) -> bool:
        if doc_id not in self._id_to_idx:
            return False
        idx = self._id_to_idx.pop(doc_id)
        self._docs[idx] = {
            "id": "",
            "text": "",
            "metadata": {},
            "_deleted": True,
        }
        self._tombstones += 1
        return True

    def delete_by_source(self, source_id: str) -> int:
        prefix = f"{source_id}_chunk_"
        ids = [
            str(doc["id"])
            for doc in self._docs
            if not doc.get("_deleted")
            and (
                str(doc.get("metadata", {}).get("source_id", "")) == source_id
                or str(doc["id"]).startswith(prefix)
            )
        ]
        for doc_id in ids:
            self.delete(doc_id)
        return len(ids)

    def count(self) -> int:
        return len(self._id_to_idx)

    def __repr__(self) -> str:
        return f"FAISSVectorStore(model={self._model!r}, count={self.count()})"


class LanceDBVectorStore(VectorStore):
    """Persistent vector store using LanceDB."""

    def __init__(
        self,
        *,
        uri: str = "./.lancedb",
        table_name: str = "seocho_vectors",
        embedding_backend: Optional[Any] = None,
        embedding_provider: str = "openai",
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        model: str = "text-embedding-3-small",
        region: Optional[str] = None,
    ) -> None:
        try:
            import lancedb
        except ImportError as exc:
            raise ImportError(
                "LanceDBVectorStore requires 'lancedb'. "
                "Install it with: pip install lancedb"
            ) from exc

        connect_kwargs: Dict[str, Any] = {}
        if api_key:
            connect_kwargs["api_key"] = api_key
        if region:
            connect_kwargs["region"] = region

        self._lancedb = lancedb
        self._db = lancedb.connect(uri, **connect_kwargs)
        self._table_name = table_name
        self._embedding_backend = embedding_backend or create_embedding_backend(
            provider=embedding_provider,
            api_key=api_key,
            base_url=base_url,
            model=model,
        )
        self._model = model
        self._table = self._open_existing_table()

    def _open_existing_table(self) -> Any | None:
        try:
            return self._db.open_table(self._table_name)
        except Exception:
            return None

    def _embed(self, texts: Sequence[str]) -> List[List[float]]:
        return self._embedding_backend.embed(texts, model=self._model)

    def _serialize_rows(self, items: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
        vectors = self._embed([str(item["text"]) for item in items])
        rows: List[Dict[str, Any]] = []
        for item, vector in zip(items, vectors):
            rows.append(
                {
                    "id": str(item["id"]),
                    "text": str(item["text"]),
                    "vector": vector,
                    "metadata": json.dumps(item.get("metadata", {}), ensure_ascii=False),
                }
            )
        return rows

    def _ensure_table(self, rows: Sequence[Dict[str, Any]]) -> Any:
        if self._table is not None:
            return self._table, False
        self._table = self._db.create_table(self._table_name, data=list(rows))
        return self._table, True

    @staticmethod
    def _query_to_rows(query: Any) -> List[Dict[str, Any]]:
        if hasattr(query, "to_list"):
            return list(query.to_list())
        if hasattr(query, "to_arrow"):
            arrow_table = query.to_arrow()
            if hasattr(arrow_table, "to_pylist"):
                return list(arrow_table.to_pylist())
        if hasattr(query, "to_pandas"):
            frame = query.to_pandas()
            return frame.to_dict(orient="records")
        return []

    def add(
        self,
        doc_id: str,
        text: str,
        *,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.add_batch(
            [
                {
                    "id": doc_id,
                    "text": text,
                    "metadata": metadata or {},
                }
            ]
        )

    def add_batch(self, items: Sequence[Dict[str, Any]]) -> int:
        if not items:
            return 0

        if self._table is not None:
            for item in items:
                self.delete(str(item["id"]))

        rows = self._serialize_rows(items)
        table, created = self._ensure_table(rows)
        if not created:
            table.add(rows)
        return len(rows)

    def search(self, query: str, *, limit: int = 5) -> List[VectorSearchResult]:
        if self._table is None:
            return []

        query_vector = self._embed([query])[0]
        query_builder = self._table.search(query_vector).limit(limit)
        rows = self._query_to_rows(query_builder)

        results: List[VectorSearchResult] = []
        for row in rows:
            raw_metadata = row.get("metadata", {})
            if isinstance(raw_metadata, str):
                try:
                    metadata = json.loads(raw_metadata)
                except json.JSONDecodeError:
                    metadata = {"raw_metadata": raw_metadata}
            elif isinstance(raw_metadata, dict):
                metadata = raw_metadata
            else:
                metadata = {}
            # LanceDB returns L2 distance (lower = closer); convert to a similarity
            # (higher = better) so scores are comparable with the FAISS backend.
            raw_distance = float(row.get("_distance", row.get("score", 0.0)))
            score = 1.0 / (1.0 + raw_distance)
            results.append(
                VectorSearchResult(
                    id=str(row.get("id", "")),
                    text=str(row.get("text", "")),
                    score=score,
                    metadata=metadata,
                    metric="similarity",
                )
            )
        return results

    def delete(self, doc_id: str) -> bool:
        if self._table is None:
            return False
        safe_doc_id = str(doc_id).replace("'", "''")
        try:
            self._table.delete(f"id = '{safe_doc_id}'")
        except Exception:
            return False
        return True

    def delete_by_source(self, source_id: str) -> int:
        """Delete this source's vectors — by range, never by LIKE.

        Vectors are keyed ``{source_id}_chunk_{ordinal:04d}``, and matching that
        with ``id LIKE 'src_chunk_%'`` deletes other documents' vectors. In SQL
        LIKE, ``_`` matches any single character, so the pattern is
        ``src`` + any + ``chunk`` + any + anything, and a neighbouring source
        ``src_chunked_v2`` — whose ids are ``src_chunked_v2_chunk_0000`` —
        matches it. `reindex()` routes through here, so a routine re-index of
        one document silently destroyed another's retrieval surface, and the
        loss surfaced later as a retrieval or generation failure rather than as
        a delete bug. A source id containing ``%`` or ``_`` widened it further,
        since only quotes were escaped.

        A half-open range on the id prefix has none of that: it is exact, needs
        no escaping beyond quotes, and an ordered index can serve it.
        """
        if self._table is None:
            return 0
        before = self.count()

        def _quote(value: str) -> str:
            return str(value).replace("'", "''")

        prefix = f"{source_id}_chunk_"
        # chr(ord('_') + 1) == '`' — the successor of the prefix, so the range
        # is exactly the ids that start with it.
        upper = f"{source_id}_chunk`"
        try:
            self._table.delete(
                f"id >= '{_quote(prefix)}' AND id < '{_quote(upper)}'"
            )
        except Exception:
            return 0
        return max(0, before - self.count())

    def count(self) -> int:
        if self._table is None:
            return 0
        if hasattr(self._table, "count_rows"):
            return int(self._table.count_rows())
        if hasattr(self._table, "to_arrow"):
            arrow_table = self._table.to_arrow()
            return int(getattr(arrow_table, "num_rows", 0))
        return 0

    def __repr__(self) -> str:
        return (
            f"LanceDBVectorStore(table_name={self._table_name!r}, "
            f"model={self._model!r}, count={self.count()})"
        )


def create_vector_store(
    *,
    kind: str = "faiss",
    embedding_backend: Optional[Any] = None,
    embedding_provider: str = "openai",
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    model: str = "text-embedding-3-small",
    dimension: int = 1536,
    uri: str = "./.lancedb",
    table_name: str = "seocho_vectors",
    region: Optional[str] = None,
) -> VectorStore:
    """Create a vector store by kind."""

    kind_key = str(kind).strip().lower() or "faiss"
    if kind_key == "faiss":
        return FAISSVectorStore(
            embedding_backend=embedding_backend,
            embedding_provider=embedding_provider,
            api_key=api_key,
            base_url=base_url,
            model=model,
            dimension=dimension,
        )
    if kind_key == "lancedb":
        return LanceDBVectorStore(
            uri=uri,
            table_name=table_name,
            embedding_backend=embedding_backend,
            embedding_provider=embedding_provider,
            api_key=api_key,
            base_url=base_url,
            model=model,
            region=region,
        )
    raise ValueError(f"Unsupported vector store kind '{kind}'. Known kinds: faiss, lancedb")


# ======================================================================
# NL→Cypher example store (ADR-0090)
# ======================================================================


@dataclass(frozen=True)
class NLCypherExample:
    """A previously-validated (question, Cypher) pair for few-shot reuse.

    GOPTS G4 (ADR-0097) extends the schema with optional cost/oracle
    fields. Existing callers that don't pass them get None defaults —
    backward-compatible. The Layer-1 ranking-quality harness reads
    these fields when computing top-1 accuracy / NDCG / Kendall tau.
    """

    question: str
    cypher: str
    success: bool = True
    metadata: Optional[Dict[str, Any]] = None
    # G2 cost-ranking fields (predicted by cost_model)
    plan_cost_estimate: Optional[float] = None
    k_rank_position: Optional[int] = None       # 0 = top-1 from cost model
    selected_pattern_id: Optional[str] = None
    enumeration_latency_ms: Optional[float] = None
    # Execution fields (observed at run time)
    execution_row_count: Optional[int] = None
    total_latency_ms: Optional[float] = None
    # G4 Layer-1 PROFILE-oracle fields (observed via Cypher PROFILE)
    profile_db_hits: Optional[int] = None
    oracle_rank_position: Optional[int] = None  # 0 = top-1 by PROFILE


class NLCypherExampleStore:
    """Per-workspace store of validated (NL, Cypher) pairs.

    Thin slice: in-memory dict, no embeddings, no eviction. ADR-0090
    follow-up replaces this with a real per-workspace vector index keyed by
    question embedding and gated on ``success == True``.

    The Protocol is intentionally narrow:

    - ``add(workspace_id, question, cypher, success, metadata, ...)`` writes a
      new validated pair. No-op when ``success`` is False (the ADR-0090
      contract forbids poisoning the store with failed examples). G4
      optional kwargs record the cost-ranked prediction + PROFILE oracle
      so the Layer-1 ranking-quality harness has a regression target.
    - ``search(workspace_id, question, k)`` returns the top-k examples.
      Thin slice: returns up to ``k`` most-recent successful entries for
      this workspace; embedding-based ranking is a follow-up.
    """

    def __init__(self) -> None:
        self._by_workspace: Dict[str, List[NLCypherExample]] = {}

    def add(
        self,
        *,
        workspace_id: str,
        question: str,
        cypher: str,
        success: bool = True,
        metadata: Optional[Dict[str, Any]] = None,
        plan_cost_estimate: Optional[float] = None,
        k_rank_position: Optional[int] = None,
        selected_pattern_id: Optional[str] = None,
        enumeration_latency_ms: Optional[float] = None,
        execution_row_count: Optional[int] = None,
        total_latency_ms: Optional[float] = None,
        profile_db_hits: Optional[int] = None,
        oracle_rank_position: Optional[int] = None,
    ) -> None:
        if not success:
            return
        if not question or not cypher:
            return
        bucket = self._by_workspace.setdefault(workspace_id, [])
        bucket.append(
            NLCypherExample(
                question=question.strip(),
                cypher=cypher.strip(),
                success=True,
                metadata=dict(metadata or {}),
                plan_cost_estimate=plan_cost_estimate,
                k_rank_position=k_rank_position,
                selected_pattern_id=selected_pattern_id,
                enumeration_latency_ms=enumeration_latency_ms,
                execution_row_count=execution_row_count,
                total_latency_ms=total_latency_ms,
                profile_db_hits=profile_db_hits,
                oracle_rank_position=oracle_rank_position,
            )
        )

    def search(
        self,
        *,
        workspace_id: str,
        question: str,
        k: int = 5,
    ) -> List[NLCypherExample]:
        if k <= 0:
            return []
        bucket = self._by_workspace.get(workspace_id) or []
        return list(reversed(bucket))[:k]

    def __len__(self) -> int:
        return sum(len(v) for v in self._by_workspace.values())
