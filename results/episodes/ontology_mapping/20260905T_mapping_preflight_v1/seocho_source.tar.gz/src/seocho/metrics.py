"""Low-cardinality production metrics for SEOCHO runtime boundaries.

Metrics intentionally carry aggregate operational dimensions only. Exact
request causality belongs in traces and auditable receipts, never metric labels.
"""

from __future__ import annotations

import atexit
import logging
import os
import threading
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Any, Mapping, Protocol


logger = logging.getLogger(__name__)

METRICS_BACKEND_ENV = "SEOCHO_METRICS_BACKEND"
METRICS_OTLP_ENDPOINT_ENV = "SEOCHO_METRICS_OTLP_ENDPOINT"
_FORBIDDEN_ATTRIBUTE_FRAGMENTS = (
    "workspace",
    "user",
    "session",
    "conversation",
    "wallet",
    "account",
    "order",
    "transaction",
    "event_id",
    "memory_id",
    "trace_id",
    "prompt",
    "completion",
    "response_text",
    "query_text",
    "cypher",
    "sql",
    "arguments",
    "payload",
)

# Default OTel histogram boundaries are far too coarse for graph retrieval and
# agent hot paths (sub-second observations collapse into the first bucket and
# produce misleading multi-second p95 values in Prometheus).  Keep boundaries
# explicit and low-cardinality so dashboards reflect the latency actually seen
# by callers.
_DURATION_SECONDS_BUCKETS = (
    0.001,
    0.0025,
    0.005,
    0.01,
    0.025,
    0.05,
    0.1,
    0.25,
    0.5,
    1.0,
    2.5,
    5.0,
    10.0,
    30.0,
)
_LATENCY_MILLISECONDS_BUCKETS = (
    1.0,
    2.5,
    5.0,
    10.0,
    25.0,
    50.0,
    100.0,
    250.0,
    500.0,
    1000.0,
    2500.0,
    5000.0,
)
# Ratios and shares live in [0, 1] — except plan.speedup, which is a factor and
# runs past it. Default OTel boundaries start at 5, so every one of these landed
# in the first bucket and their percentiles were unreadable.
_RATIO_BUCKETS = (
    0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9,
    0.95, 0.99, 1.0, 2.0, 5.0, 10.0,
)
# Token counts (prompt, completion, context) span three orders of magnitude.
_TOKEN_COUNT_BUCKETS = (
    16.0, 64.0, 256.0, 512.0, 1024.0, 2048.0, 4096.0,
    8192.0, 16384.0, 32768.0, 131072.0,
)
_BYTE_SIZE_BUCKETS = (
    256.0, 1024.0, 4096.0, 16_384.0, 65_536.0, 262_144.0,
    1_048_576.0, 2_097_152.0, 8_388_608.0,
)
# Small cardinal counts: retrieval candidates, attempts, batch entries.
_ITEM_COUNT_BUCKETS = (1.0, 2.0, 3.0, 5.0, 8.0, 13.0, 21.0, 50.0, 100.0, 500.0)


@dataclass(frozen=True, slots=True)
class MetricSpec:
    name: str
    kind: str
    unit: str
    attributes: frozenset[str]
    description: str


def _spec(
    name: str,
    kind: str,
    unit: str,
    attributes: tuple[str, ...],
    description: str,
) -> MetricSpec:
    return MetricSpec(name, kind, unit, frozenset(attributes), description)


METRIC_SPECS: dict[str, MetricSpec] = {
    spec.name: spec
    for spec in (
        _spec("seocho.agent.request.duration", "histogram", "s", ("operation", "outcome", "error.type"), "Agent request duration."),
        _spec("seocho.agent.request.count", "counter", "{request}", ("operation", "outcome"), "Completed agent requests."),
        _spec("seocho.agent.request.inflight", "up_down_counter", "{request}", ("operation",), "In-flight agent requests."),
        _spec("seocho.agent.timeout.count", "counter", "{timeout}", ("operation", "stage"), "Agent stage timeouts."),
        _spec("seocho.agent.partial.count", "counter", "{request}", ("operation", "reason"), "Explicit partial answers."),
        _spec("seocho.agent.authorization.count", "counter", "{decision}", ("action", "outcome", "reason"), "Agent-principal authorization decisions."),
        _spec("seocho.agent.retrieval.attempts", "histogram", "{attempt}", ("outcome",), "Bounded retrieval-subagent attempts."),
        _spec("seocho.answer.freshness_violation.count", "counter", "{answer}", ("query.class",), "Answers blocked for freshness violations."),
        _spec("seocho.answer.provenance.coverage", "histogram", "1", ("query.class",), "Fraction of answer claims with provenance."),
        _spec("seocho.memory.commit.duration", "histogram", "s", ("outcome", "error.type"), "Authoritative memory commit duration."),
        _spec("seocho.memory.commit.phase.duration", "histogram", "ms", ("phase", "outcome"), "Bounded authoritative commit phase duration."),
        _spec("seocho.memory.commit.count", "counter", "{commit}", ("outcome",), "Authoritative memory commits."),
        _spec("seocho.memory.sequence", "gauge", "{event}", (), "Latest authoritative memory sequence."),
        _spec("seocho.memory.idempotency_replay.count", "counter", "{event}", ("outcome",), "Idempotent memory replays."),
        _spec("seocho.memory.transition_conflict.count", "counter", "{conflict}", ("event.type",), "Rejected memory transitions."),
        _spec("seocho.projection.watermark", "gauge", "{event}", ("projection",), "Latest applied projection sequence."),
        _spec("seocho.projection.outbox.pending", "gauge", "{entry}", ("projection",), "Pending projection outbox entries."),
        _spec("seocho.projection.outbox.oldest_age", "gauge", "s", ("projection",), "Age of oldest pending outbox entry."),
        _spec("seocho.projection.batch.duration", "histogram", "s", ("projection", "outcome"), "Projection batch duration."),
        _spec("seocho.projection.batch.entry_count", "histogram", "{entry}", ("projection",), "Entries processed per projection batch."),
        _spec("seocho.projection.replay.count", "counter", "{entry}", ("projection", "outcome"), "Projection replay results."),
        _spec("seocho.projection.fencing_rejection.count", "counter", "{rejection}", ("projection",), "Rejected stale projector owners."),
        _spec("seocho.projection.daemon.request.duration", "histogram", "s", ("outcome",), "Rust projection-daemon round-trip duration."),
        _spec("seocho.projection.daemon.request.count", "counter", "{request}", ("outcome",), "Rust projection-daemon requests."),
        _spec("seocho.projection.daemon.payload_bytes", "histogram", "By", (), "Rust projection-daemon request payload size."),
        _spec("seocho.governance.candidate.stage.duration", "histogram", "s", ("outcome",), "Candidate RDF staging and SHACL duration."),
        _spec("seocho.governance.candidate.stage.count", "counter", "{candidate}", ("outcome",), "Candidate RDF staging outcomes."),
        _spec("seocho.governance.candidate.payload_bytes", "histogram", "By", (), "Serialized candidate RDF size."),
        _spec("seocho.retrieval.duration", "histogram", "s", ("source", "outcome"), "Retrieval operation duration."),
        _spec("seocho.retrieval.inflight", "up_down_counter", "{query}", ("source",), "In-flight retrieval queries."),
        _spec("seocho.retrieval.admission_rejection.count", "counter", "{rejection}", ("source", "reason"), "Retrieval queries rejected before backend execution."),
        _spec("seocho.retrieval.admission.available_permits", "gauge", "{permit}", ("source",), "Remaining admission permits before load shedding begins."),
        _spec("seocho.retrieval.candidate_count", "histogram", "{item}", ("source",), "Retrieval candidates."),
        _spec("seocho.retrieval.selected_count", "histogram", "{item}", ("source",), "Selected retrieval results."),
        _spec("seocho.postgres.admission.count", "counter", "{request}", ("tier", "outcome"), "PostgreSQL workload-tier admission outcomes."),
        _spec("seocho.postgres.admission.wait", "histogram", "s", ("tier", "outcome"), "PostgreSQL workload-tier admission wait."),
        _spec("seocho.postgres.cache.request.count", "counter", "{request}", ("outcome",), "Single-flight cache request outcomes."),
        _spec("seocho.postgres.route.count", "counter", "{route}", ("role", "reason"), "Freshness-aware PostgreSQL read routes."),
        _spec("seocho.federation.target.duration", "histogram", "s", ("target", "outcome"), "Federated target duration."),
        _spec("seocho.federation.partial.count", "counter", "{request}", ("reason",), "Partial federation results."),
        _spec("seocho.text2cypher.duration", "histogram", "s", ("stage", "outcome"), "Text2Cypher stage duration."),
        _spec("seocho.text2cypher.validation_failure.count", "counter", "{failure}", ("reason",), "Rejected generated Cypher."),
        _spec("seocho.text2cypher.execution_failure.count", "counter", "{failure}", ("error.type",), "Cypher execution failures."),
        _spec("seocho.text2cypher.judge.count", "counter", "{judgement}", ("verdict", "outcome"), "Blinded Text2Cypher LLM-judge outcomes."),
        _spec("seocho.text2cypher.judge.score", "histogram", "1", (), "Blinded Text2Cypher LLM-judge score."),
        _spec("seocho.query.plan.count", "counter", "{plan}", ("sargable",), "Executed query plans by sargability."),
        _spec("seocho.query.db_hits.count", "counter", "{dbhit}", (), "Cumulative database hits across executed plans."),
        _spec("seocho.query.scan.count", "counter", "{scan}", ("operator",), "Full-scan plan operators observed."),
        _spec("seocho.query.plan_route.count", "counter", "{route}", ("route",), "Plan-quality routing decisions."),
        _spec("seocho.query.generation_declined.count", "counter", "{decline}", ("reason",), "Validated generation declines by exception class."),
        _spec("seocho.arbiter.route.count", "counter", "{route}", ("route",), "Arbiter routing decisions."),
        _spec("seocho.index.validation_errors.count", "counter", "{error}", ("mode", "ontology"), "Ontology validation errors during indexing."),
        # Indexing-stage quality. Attribute sets are deliberately bounded:
        # the offending LABEL and PROPERTY are model-controlled and unbounded
        # by definition (they are emitted precisely when they are NOT in the
        # ontology), so they are logged rather than carried as attributes.
        _spec("seocho.index.extraction.nodes", "histogram", "{item}", ("ontology", "source_type"), "Nodes extracted per document."),
        _spec("seocho.index.extraction.relationships", "histogram", "{item}", ("ontology", "source_type"), "Relationships extracted per document."),
        _spec("seocho.index.extraction.empty.count", "counter", "{document}", ("ontology", "source_type"), "Documents that yielded no nodes."),
        _spec("seocho.index.extraction.retry.count", "counter", "{attempt}", ("ontology", "reason"), "Extraction retries by reason."),
        _spec("seocho.index.off_ontology_label.count", "counter", "{node}", ("ontology",), "Extracted node labels the ontology does not declare."),
        _spec("seocho.index.off_vocabulary_value.count", "counter", "{value}", ("ontology",), "Property values outside a declared vocabulary."),
        _spec("seocho.index.relationship_survival.count", "histogram", "{item}", ("ontology", "stage"), "Domain relationships surviving each write-path stage."),
        _spec("seocho.index.observations_reified.count", "counter", "{observation}", ("ontology",), "Observation nodes reified during indexing."),
        _spec("seocho.query.plan.speedup", "histogram", "1", ("cohort",), "Baseline-to-candidate query-plan speedup after semantic parity."),
        _spec("seocho.query.plan.db_hits_reduction", "histogram", "1", ("cohort",), "Fractional DB-hit reduction for a semantically equivalent query plan."),
        _spec("seocho.query.plan.finding.count", "counter", "{finding}", ("variant", "finding"), "Execution-plan findings attributed by the GOpt-inspired audit."),
        _spec("seocho.context.assembly.duration", "histogram", "s", ("strategy", "outcome"), "Context assembly duration."),
        _spec("seocho.context.candidate_token_count", "histogram", "{token}", ("strategy",), "Candidate context tokens."),
        _spec("seocho.context.selected_token_count", "histogram", "{token}", ("strategy",), "Selected context tokens."),
        _spec("seocho.context.item_count", "histogram", "{item}", ("strategy", "state"), "Candidate or selected context items."),
        _spec("seocho.context.budget_exceeded.count", "counter", "{request}", ("strategy",), "Context budget exceedances."),
        _spec("seocho.context.policy_filtered.count", "counter", "{item}", ("reason",), "Context items removed by policy."),
        _spec("seocho.ontology.tool.call.count", "counter", "{call}", ("tool", "outcome"), "Bounded ontology-context tool calls."),
        _spec("seocho.ontology.tool.duration", "histogram", "s", ("tool", "outcome"), "Bounded ontology-context tool duration."),
        _spec("seocho.ontology.slice.size", "histogram", "By", ("kind",), "Ontology slice or evidence-pack size."),
        _spec("seocho.ontology.module.quality.decision.count", "counter", "{decision}", ("disposition",), "Module-quality policy decisions exposed to agents."),
        _spec("seocho.ontology.lock.operation.count", "counter", "{operation}", ("operation", "outcome"), "Ontology activation and lease lifecycle operations."),
        _spec("seocho.ontology.learning.candidate.count", "counter", "{candidate}", ("kind",), "Offline ontology-learning candidates by bounded kind."),
        _spec("seocho.ontology.learning.duration", "histogram", "s", ("outcome",), "Offline ontology-learning analysis duration."),
        _spec("seocho.ontology.learning.prompt_ablation.duration", "histogram", "s", ("arm", "outcome"), "Paired ontology-learning prompt-ablation duration."),
        _spec("seocho.ontology.learning.prompt_ablation.count", "counter", "{request}", ("arm", "outcome"), "Paired ontology-learning prompt-ablation outcomes."),
        _spec("seocho.ontology.learning.prompt_ablation.evidence_coverage", "histogram", "1", ("arm",), "Candidate items carrying source evidence in prompt ablation."),
        _spec("db.client.operation.duration", "histogram", "s", ("db.system", "operation", "outcome"), "Graph client operation duration, wall time at the driver."),
        _spec("db.client.operation.server_share", "histogram", "1", ("db.system", "operation"), "Server fraction of a graph operation; the remainder is client hydration (ADR-0111)."),
        _spec("gen_ai.client.operation.duration", "histogram", "s", ("gen_ai.provider.name", "gen_ai.request.model", "gen_ai.operation.name", "error.type"), "GenAI client operation duration."),
        _spec("gen_ai.client.token.usage", "histogram", "{token}", ("gen_ai.provider.name", "gen_ai.request.model", "gen_ai.token.type"), "Provider-reported token usage."),
        _spec("seocho.gen_ai.time_to_first_token", "histogram", "s", ("gen_ai.provider.name", "gen_ai.request.model"), "Streaming time to first token."),
        _spec("seocho.gen_ai.prompt_cache.request.count", "counter", "{request}", ("gen_ai.provider.name", "gen_ai.request.model", "outcome"), "Provider-reported prompt-cache request outcomes."),
        _spec("seocho.gen_ai.retry.count", "counter", "{retry}", ("gen_ai.provider.name", "gen_ai.request.model", "reason"), "GenAI retries."),
        _spec("seocho.gen_ai.structured_output_repair.count", "counter", "{repair}", ("gen_ai.provider.name", "gen_ai.request.model", "reason"), "Structured-output repairs."),
        _spec("seocho.governance.disclosure_violation.count", "counter", "{violation}", ("stage", "policy.disposition"), "Disclosure violations."),
        _spec("seocho.governance.policy_decision.count", "counter", "{decision}", ("policy.version", "policy.disposition"), "Policy decisions."),
        _spec("seocho.governance.policy_version_mismatch.count", "counter", "{mismatch}", ("stage",), "Policy version mismatches."),
        _spec("seocho.governance.ontology_version_mismatch.count", "counter", "{mismatch}", ("stage",), "Ontology version mismatches."),
        _spec("seocho.observability.export_failure.count", "counter", "{failure}", ("signal", "exporter"), "Telemetry export failures."),
        _spec("seocho.observability.trace_complete.count", "counter", "{trace}", ("workflow", "outcome"), "Experiment traces with complete required stages."),
        _spec("seocho.experiment.run.duration", "histogram", "s", ("runtime", "outcome"), "End-to-end experiment-run duration."),
        _spec("seocho.experiment.run.count", "counter", "{run}", ("runtime", "outcome"), "Completed experiment runs."),
        _spec("seocho.benchmark.dataset.prepare.duration", "histogram", "s", ("benchmark", "outcome"), "Benchmark dataset preparation duration."),
        _spec("seocho.benchmark.dataset.prepare.count", "counter", "{run}", ("benchmark", "outcome"), "Benchmark dataset preparation outcomes."),
        _spec("seocho.benchmark.dataset.case.count", "counter", "{case}", ("benchmark", "question_type"), "Prepared benchmark cases by bounded question type."),
        _spec("seocho.critical.scenario.runs", "counter", "{run}", ("scenario_id", "support_status"), "Critical evaluation scenario runs."),
        _spec("seocho.critical.scenario.passed", "counter", "{run}", ("scenario_id",), "Passed critical evaluation scenarios."),
        _spec("seocho.critical.silent_stale", "counter", "{answer}", ("scenario_id",), "Silent stale answers in evaluation."),
        _spec("seocho.critical.disclosure_violations", "counter", "{violation}", ("scenario_id",), "Disclosure violations in evaluation."),
        _spec("seocho.critical.memory_sequence", "gauge", "{event}", ("scenario_id",), "Evaluation authoritative sequence."),
        _spec("seocho.critical.projection_watermark", "gauge", "{event}", ("scenario_id",), "Evaluation projection watermark."),
        _spec("seocho.critical.projection_lag", "gauge", "{event}", ("scenario_id",), "Evaluation projection lag."),
        _spec("seocho.critical.scenario.info", "gauge", "1", ("scenario_id", "support_status"), "Evaluation scenario support state."),
        _spec("seocho.critical.latency", "histogram", "ms", ("scenario_id", "stage"), "Evaluation stage latency."),
        _spec("seocho.evaluation.scenario.status", "gauge", "1", ("scenario_id", "status"), "Latest scenario evaluation status."),
        _spec("seocho.evaluation.query.count", "counter", "{query}", ("cohort", "outcome"), "Evaluated customer queries."),
        _spec("seocho.evaluation.query.accuracy", "gauge", "1", ("cohort",), "Latest customer-query accuracy."),
        _spec("seocho.evaluation.context.reduction", "gauge", "1", ("strategy",), "Input-context reduction ratio."),
        _spec("seocho.evaluation.text2cypher.attempts", "histogram", "{attempt}", ("outcome",), "Validated Text2Cypher attempts."),
        _spec("seocho.evaluation.capability.status", "gauge", "1", ("capability", "status"), "Capability-gated evaluation status."),
        _spec("seocho.customer.query.count", "counter", "{query}", ("query.class", "outcome", "traffic.type"), "Customer query outcomes."),
        _spec("seocho.customer.query.duration", "histogram", "s", ("query.class", "outcome", "traffic.type"), "Customer query pipeline duration."),
        _spec("seocho.customer.evidence.coverage", "histogram", "1", ("query.class",), "Required source evidence coverage."),
        _spec("seocho.customer.source.freshness", "histogram", "s", ("source",), "Age of live source snapshot."),
        _spec("seocho.customer.source.failure.count", "counter", "{failure}", ("source", "reason"), "Customer evidence source failures."),
        _spec("seocho.evaluation.answer.accuracy", "gauge", "1", ("cohort", "dimension"), "Latest answer evaluation accuracy."),
        _spec("seocho.evaluation.answer.latency", "histogram", "ms", ("cohort",), "Answer evaluation latency."),
        _spec("seocho.evaluation.answer.leakage", "counter", "{case}", ("cohort",), "Answer evaluation leakage cases."),
        _spec("seocho.evaluation.customer.outcome_ratio", "gauge", "1", ("outcome",), "Latest customer-query outcome ratio."),
        _spec("seocho.evaluation.customer.evidence_coverage", "gauge", "1", ("query.class",), "Latest evidence coverage by customer query class."),
        _spec("seocho.evaluation.dataset.ratio", "gauge", "1", ("cohort", "dimension"), "Dataset quality ratio."),
        _spec("seocho.evaluation.intent.accuracy", "gauge", "1", ("cohort", "group", "dimension"), "Intent routing and boundary accuracy."),
        _spec("seocho.evaluation.answer.progress", "gauge", "1", ("cohort",), "Long-running answer evaluation completion ratio."),
        _spec("seocho.evaluation.answer.completed", "gauge", "{query}", ("cohort",), "Durably checkpointed answer evaluations."),
        _spec("seocho.evaluation.answer.failures", "gauge", "{case}", ("cohort",), "Checkpointed answer contract failures."),
    )
}


class _Instrument(Protocol):
    def add(self, amount: int | float, attributes: Mapping[str, Any] | None = None) -> None: ...
    def record(self, amount: int | float, attributes: Mapping[str, Any] | None = None) -> None: ...
    def set(self, amount: int | float, attributes: Mapping[str, Any] | None = None) -> None: ...


class _NoopInstrument:
    def add(self, amount: int | float, attributes: Mapping[str, Any] | None = None) -> None:
        return None

    record = add
    set = add


class ProductionMetrics:
    """Validated instrument registry backed by an OpenTelemetry meter."""

    def __init__(self, meter: Any | None = None) -> None:
        self._instruments: dict[str, _Instrument] = {}
        for spec in METRIC_SPECS.values():
            if meter is None:
                instrument: _Instrument = _NoopInstrument()
            elif spec.kind == "counter":
                instrument = meter.create_counter(spec.name, unit=spec.unit, description=spec.description)
            elif spec.kind == "up_down_counter":
                instrument = meter.create_up_down_counter(spec.name, unit=spec.unit, description=spec.description)
            elif spec.kind == "gauge":
                instrument = meter.create_gauge(spec.name, unit=spec.unit, description=spec.description)
            else:
                instrument = meter.create_histogram(spec.name, unit=spec.unit, description=spec.description)
            self._instruments[spec.name] = instrument

    @staticmethod
    def _attributes(spec: MetricSpec, attributes: Mapping[str, Any] | None) -> dict[str, Any]:
        values = dict(attributes or {})
        unknown = set(values) - spec.attributes
        if unknown:
            raise ValueError(f"unsupported attributes for {spec.name}: {', '.join(sorted(unknown))}")
        for key, value in values.items():
            lowered = key.lower()
            if any(fragment in lowered for fragment in _FORBIDDEN_ATTRIBUTE_FRAGMENTS):
                raise ValueError(f"forbidden metric attribute: {key}")
            if not isinstance(value, (str, bool, int, float)):
                raise TypeError(f"metric attribute {key} must be scalar")
            if isinstance(value, str) and len(value) > 80:
                raise ValueError(f"metric attribute {key} exceeds 80 characters")
        return values

    #: When true, a validation failure raises instead of being swallowed. Tests
    #: and CI set it; production leaves it off. See _guard().
    strict: bool = False

    @contextmanager
    def _guard(self, name: str):
        """Never let telemetry fail the work it measures.

        The emit calls in `store/llm.py` sit inside the same `try` as the
        provider request, whose `except Exception` is the RETRY handler. So a
        malformed attribute on a SUCCESSFUL completion was reclassified as an
        LLM failure: it triggered a real retry at real cost, and recorded itself
        as `seocho.gen_ai.retry.count{reason: "ValueError"}`. The retry metric
        contained our own bugs, and the same shape in
        `runtime/agent_server.py`'s bare `finally` turned a telemetry error into
        a 500.

        A monitoring system that can take down the thing it monitors, and that
        misreports its own defects as vendor failures, fails the one job it has.
        Guarding here rather than at each call site means a new emitter cannot
        reintroduce it by forgetting to wrap.
        """
        try:
            yield
        except Exception as exc:  # noqa: BLE001 - telemetry must not escape
            if self.strict:
                raise
            logger.debug("metric %s dropped: %s", name, exc)

    def add(self, name: str, amount: int | float = 1, attributes: Mapping[str, Any] | None = None) -> None:
        with self._guard(name):
            spec = METRIC_SPECS[name]
            if spec.kind not in {"counter", "up_down_counter"}:
                raise TypeError(f"{name} is not an additive instrument")
            self._instruments[name].add(amount, self._attributes(spec, attributes))

    def record(self, name: str, value: int | float, attributes: Mapping[str, Any] | None = None) -> None:
        with self._guard(name):
            spec = METRIC_SPECS[name]
            if spec.kind != "histogram":
                raise TypeError(f"{name} is not a histogram")
            if value < 0:
                raise ValueError("histogram values must be non-negative")
            self._instruments[name].record(value, self._attributes(spec, attributes))

    def set(self, name: str, value: int | float, attributes: Mapping[str, Any] | None = None) -> None:
        with self._guard(name):
            spec = METRIC_SPECS[name]
            if spec.kind != "gauge":
                raise TypeError(f"{name} is not a gauge")
            self._instruments[name].set(value, self._attributes(spec, attributes))


_lock = threading.Lock()
_metrics = ProductionMetrics()
_provider: Any | None = None


def build_histogram_views() -> tuple:
    """Bucket boundaries per instrument unit.

    Extracted from enable_metrics so the boundaries can be asserted
    without standing up an exporter -- they were wrong for 18 of 30
    histograms and nothing could see it.
    """
    from opentelemetry.sdk.metrics.view import (
        ExplicitBucketHistogramAggregation,
        View,
    )

    # Matched on UNIT, not on a name suffix. The name-suffix form covered
    # 12 of 30 histograms: `seocho.gen_ai.time_to_first_token` is in
    # seconds and does not end in `.duration`, and
    # `seocho.memory.commit.phase.duration` does end in `.duration` but is
    # in milliseconds, so neither matched. Both fell back to OTel's default
    # boundaries, which run 0..10000 and are shaped for milliseconds — a
    # 0.8 s TTFT lands in the (0, 5] bucket and p95 reads ~5 s regardless of
    # reality. Ratios in [0, 1] collapsed into the first bucket entirely.
    #
    # Unit is the property that actually determines the right boundaries,
    # so a new instrument gets sensible buckets by declaring its unit
    # rather than by being named a particular way.
    views = (
        View(
            instrument_unit="s",
            instrument_name="*",
            aggregation=ExplicitBucketHistogramAggregation(
                _DURATION_SECONDS_BUCKETS
            ),
        ),
        View(
            instrument_unit="ms",
            instrument_name="*",
            aggregation=ExplicitBucketHistogramAggregation(
                _LATENCY_MILLISECONDS_BUCKETS
            ),
        ),
        View(
            instrument_unit="1",
            instrument_name="*",
            aggregation=ExplicitBucketHistogramAggregation(_RATIO_BUCKETS),
        ),
        View(
            instrument_unit="{token}",
            instrument_name="*",
            aggregation=ExplicitBucketHistogramAggregation(
                _TOKEN_COUNT_BUCKETS
            ),
        ),
        View(
            instrument_unit="By",
            instrument_name="*",
            aggregation=ExplicitBucketHistogramAggregation(_BYTE_SIZE_BUCKETS),
        ),
    ) + tuple(
        View(
            instrument_unit=unit,
            instrument_name="*",
            aggregation=ExplicitBucketHistogramAggregation(
                _ITEM_COUNT_BUCKETS
            ),
        )
        for unit in ("{item}", "{attempt}", "{entry}")
    )
    return views


def enable_metrics(
    *,
    backend: str | None = None,
    endpoint: str | None = None,
    reader: Any = None,
) -> ProductionMetrics:
    """Enable the process-wide production metrics registry.

    ``reader`` substitutes the exporting reader, so a test can pass an
    ``InMemoryMetricReader`` and assert what was actually emitted. Without it
    the only way to check a metric was to grep for its name in the source --
    which is how a module full of instruments that nothing ever calls passed
    the observability contract test.
    """

    global _metrics, _provider
    selected = (backend or os.getenv(METRICS_BACKEND_ENV, "none")).strip().lower()
    with _lock:
        if _provider is not None:
            _provider.shutdown()
            _provider = None
        if selected == "none":
            _metrics = ProductionMetrics()
            return _metrics
        if selected != "otlp":
            raise ValueError("metrics backend must be 'none' or 'otlp'")
        try:
            from opentelemetry.sdk.metrics import MeterProvider
            from opentelemetry.sdk.resources import Resource
        except ImportError as exc:
            raise ImportError("OTLP metrics require the seocho[otel] extra") from exc
        if reader is None:
            target = (endpoint or os.getenv(METRICS_OTLP_ENDPOINT_ENV, "")).strip()
            if not target:
                raise ValueError("OTLP metrics endpoint is required")
            try:
                from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import (
                    OTLPMetricExporter,
                )
                from opentelemetry.sdk.metrics.export import (
                    PeriodicExportingMetricReader,
                )
            except ImportError as exc:
                raise ImportError("OTLP metrics require the seocho[otel] extra") from exc
            exporter = OTLPMetricExporter(
                endpoint=target, insecure=target.startswith("http://")
            )
            reader = PeriodicExportingMetricReader(exporter, export_interval_millis=5000)
        resource_attributes = {"service.name": os.getenv("OTEL_SERVICE_NAME", "seocho")}
        if instance_id := os.getenv("OTEL_SERVICE_INSTANCE_ID"):
            resource_attributes["service.instance.id"] = instance_id
        resource = Resource.create(resource_attributes)
        views = build_histogram_views()
        _provider = MeterProvider(
            resource=resource,
            metric_readers=(reader,),
            views=views,
        )
        _metrics = ProductionMetrics(_provider.get_meter("seocho", "1"))
        return _metrics


def get_metrics() -> ProductionMetrics:
    return _metrics


def shutdown_metrics() -> None:
    global _provider
    with _lock:
        if _provider is not None:
            _provider.shutdown()
            _provider = None


atexit.register(shutdown_metrics)


__all__ = ["METRIC_SPECS", "MetricSpec", "ProductionMetrics", "enable_metrics", "get_metrics", "shutdown_metrics"]
